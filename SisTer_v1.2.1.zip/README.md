# SisTer

Sistema de gestão para empresa de transporte e turismo: clientes, funcionários, frota (com a situação de cada veículo e os
lançamentos de campo pelo celular), agenda de viagens (faturas), estoque, financeiro (caixa e cheques), rentabilidade e
relatórios. Servidor em **Delphi 12 + Horse + SQLite criptografado (AES-256)**, com front-end web em HTML/CSS/JS puro servido
pelo próprio servidor (um processo, uma porta). Em produção roda como **serviço do Windows** (`SisTerAPI`) e se atualiza
pela própria tela **Atualização**.

Acesso: `http://<ip-do-servidor>:9000`

## Módulos

| Módulo | O que faz |
|---|---|
| **Início** | Painel com indicadores (saídas do dia, faturamento, ocupação da frota, saldo do caixa), card **Situação da frota hoje** (prontos, em viagem, com pendência e em manutenção), próximas saídas, pontos de atenção (documentos e CNH vencendo, viagens sem motorista/veículo, cheques, veículos parados ou sujos com saída chegando) e gráficos. Atualiza sozinho a cada 5 minutos; cada bloco só aparece se o perfil tem acesso ao módulo |
| **Clientes** | Cadastro com busca. CPF/CNPJ único (opcional). Exclusão é lógica (`situacao = 'I'`) |
| **Funcionários** | Cadastro em 5 abas (Dados pessoais, Contato & família, Profissional, Habilitação & saúde, Histórico), com foto. A lista mostra alerta de vencimento de CNH e exame de saúde. Histórico: viagens (horas) e bonificações |
| **Frota** | Cadastro de veículos, painel de documentos vencidos/a vencer (18 tipos), equipamentos e carroceria. Histórico: abastecimento (km rodados e média km/l), acidentes, manutenção, multas e preventiva |
| **Agenda de viagens** | Calendário mensal, painel do dia e ficha completa da fatura (com passageiros, despesas e impressão). Campo **Localizar** busca em todas as datas por cliente, origem, destino, placa, nº da fatura ou duplicata. Ao escolher o veículo, a ficha bloqueia conflito de período e **avisa** quando ele está parado para manutenção sem volta antes da saída |
| **Estoque** | Itens com saldo calculado a partir de um livro de movimentações (entrada, saída e ajuste de inventário). Indicadores (para repor, sem saldo, valor a custo médio), barra de nível por item, entrada/saída em 2 cliques, contagem de inventário que lança só a diferença, saldo inicial no cadastro. Nunca deixa o saldo ficar negativo. Relatório **Lista de reposição** agrupada por fornecedor |
| **Fornecedores** | Cadastro com CNPJ/CPF validado e único, categoria livre, endereço, vários contatos por fornecedor (com links de telefone/e-mail) e aba **Compras** (entradas de estoque, total comprado, itens que ele fornece). Exclusão é lógica |
| **Financeiro** | Lançamentos do caixa, contas com limite mensal e resumo do período (fluxo de caixa, saldo, previsto) |
| **Cheques** | Controle de cheques da agência e de terceiros, com totais |
| **Vencimentos** | Painel único com os documentos dos veículos ativos (18 tipos) e dos funcionários ativos (CNH, CNH internacional, exame de saúde, SENAC) vencidos ou vencendo em 7 a 180 dias, mais as **preventivas por km** que estão perto da troca. Mostra quantas **viagens agendadas saem depois do vencimento** com aquele veículo/motorista. Módulo próprio da matriz de permissões ("Vencimentos"); cada parte só aparece se o perfil também vê Frota / Funcionários. `GET /api/vencimentos` |
| **Situação da frota** | Painel do gestor com cada veículo em uma de quatro situações calculadas (**pronto**, **em viagem**, **com pendência de limpeza**, **em manutenção**), consulta por data para montar a escala, alerta **Atenção na escala** (veículo parado ou sujo com saída confirmada chegando), aba **Lançamentos** (com desfazer e motivo) e aba **Lançar pelo celular** (endereço e passo a passo). Detalhes na seção *Situação da frota e lançamentos de campo*. `GET /api/situacao-frota?data=` |
| **Lançamentos (celular)** | Tela `lancamentos.html` para quem está no pátio: limpeza concluída, abastecimento, parada e liberação para manutenção, em três toques. Perfis de partida **Limpeza** e **Garagem**; quem só lança entra direto nesta tela. Sem sinal, guarda no aparelho e envia depois (sem duplicar). Abastecimento e manutenção também alimentam o histórico do veículo em Frota. Desfazer nunca apaga: o lançamento fica cancelado com o motivo. Módulos de permissão `situacao_frota`, `lanc_limpeza`, `lanc_abastecimento`, `lanc_manutencao` (migração 003). `/api/lancamentos` |
| **Rentabilidade** | Receita líquida, custos, lucro e margem por viagem, cliente, veículo ou mês (período pela data de saída, só confirmadas por padrão). Receita = valor da nota (ou da viagem, sem nota) − impostos/retenção; custos = valor p/ terceiros + acerto da viagem. Viagem sem acerto aparece como lucro provisório. Módulo próprio da matriz de permissões ("Rentabilidade"). `GET /api/rentabilidade` |
| **Atualização** | **Só o usuário `admin` (suporte) acessa**: além da permissão do módulo (Ver = a tela, Editar = origem e download, Incluir = instalar; a migração 002 libera o Administrador), o servidor recusa (403) qualquer outro usuário, mesmo Administrador, e registra a tentativa em `Logs\`. Assim o cliente não atualiza sozinho: quem atualiza é o suporte, inclusive pelo túnel Cloudflare. Configura a URL (HTTPS) do pacote `.zip` (gravada em `[Atualizacao] Url` do `sister.ini`), baixa e confere (SHA-256 opcional) **com o sistema no ar**, e instala: um atualizador separado (`scripts\atualizar.ps1`) para o serviço, guarda cópia dos arquivos e do banco, troca só o programa/telas/migrações, liga o serviço e confere `/api/saude`; se não subir, **reverte sozinho**. Pede a senha do administrador para instalar, fica na Auditoria e exige o SisTer rodando como serviço do Windows. Pacote: `scripts\gerar_pacote.ps1`. Rotas: `/api/atualizacao` |
| **Administração** | Usuários, perfis e matriz de permissões (só o perfil Administrador). O usuário `admin` (suporte, criado na instalação) é **protegido**: só ele mesmo pode alterar, inativar, reativar ou resetar a senha dele; nenhum outro usuário, nem outro Administrador |
| **Relatórios** | Páginas HTML imprimíveis (imprimir ou salvar PDF pelo navegador): lista de passageiros, etiquetas de embarque, controle de viagem (aba "Imprimir" da viagem), aniversariantes (em Funcionários) e lista de reposição (em Estoque) |

## Requisitos

- **Delphi 12** com FireDAC e driver SQLite (já vêm no Delphi). O banco é criptografado com o **SQLite embutido no
  FireDAC** (AES-256); por isso o servidor **não usa `sqlite3.dll`**
- **Horse** e **Horse.Jhonson**: `boss install horse` e `boss install jhonson` (ou baixe do GitHub e
  adicione a pasta `src` de cada um em *Project > Options > Resource Compiler > Include file search path*)
- **SQLite 3.27 ou superior** (o embutido no FireDAC do Delphi 12 é a 3.31). O backup usa `VACUUM INTO` (3.27); as
  migrações **não** dependem de `DROP COLUMN`. O servidor confere a versão ao iniciar. **Não deixe uma `sqlite3.dll`
  ao lado do `.exe`** (uma DLL comum não criptografa e o servidor não a usa). A DLL da pasta `migrador\` só serve ao
  migrador: ele grava um banco sem criptografia e o servidor o criptografa sozinho na primeira inicialização
- **Windows** com **PowerShell 5.1** ou superior no servidor (os scripts `servico\` e `scripts\` e a atualização automática dependem dele)
- Navegador atual (Chrome, Edge ou Firefox); no celular, Chrome (Android) ou Safari (iPhone)

## Estrutura

```
backend/
  SisTerAPI.dpr              projeto único: roda como serviço do Windows ou em modo console (testes)
  sister.ini                 criado sozinho na 1ª execução (configurações e chave dos tokens)
  sister.ini.example         modelo sem chave (o único que vai para o repositório)
  boss.json, boss-lock.json  dependências (Horse e Jhonson)
  Database/
    sister.db                criado sozinho, aplicando as migrações (CRIPTOGRAFADO)
    sister.key               chave do banco, protegida pelo Windows (DPAPI); nunca versionar
    pre_criptografia/        cópia temporária ao criptografar um banco antigo (apagada após conferir)
    migrations/              001_schema_atual.sql (schema completo), 002_permissoes_novos_modulos.sql,
                             003_situacao_frota.sql e as próximas, aplicadas em ordem, uma única vez cada
    pre_migracao/            cópia automática do banco antes de aplicar migrações novas (VACUUM INTO)
    schema.sql, seed.sql     restos da fase 1; NÃO são usados (vale só a pasta migrations)
  src/
    App/          Startup (middlewares e rotas), ServicoWindows (serviço sem VCL), ArquivosEstaticos, Configuracao (sister.ini),
                  Backup, Atualizacao (baixar/validar/aplicar pacote), TrialControl (período de teste de 30 dias; compilado, mas hoje
                  não é chamado pelo SisTerAPI.dpr, veja ajuste_versao_trial.txt)
    Common/       JwtHelper, PasswordHelper, Logger, LimitadorTaxa, JsonHelper, Validacao, Auditoria, Versao e as regras puras
                  testáveis: BackupRegras, EstoqueRegras, AtualizacaoRegras, ChaveBancoRegras
    Data/         Conexao (FireDAC + SQLite, pool de conexões), ChaveBanco (chave AES do banco, DPAPI)
    Middlewares/  AuthMiddleware (JWT + permissões), SegurancaHttp (IP real, limites, cabeçalhos)
    Models/       Cliente, Funcionario
    Repository/   acesso a dados (SQL puro); CrudGenerico = CRUD dirigido por lista de colunas
    Controllers/  rotas HTTP sob /api: Auth, Clientes, Funcionarios, Frota, Faturas (agenda), Financeiro, Fornecedores,
                  Estoque, Usuarios, Auditoria, Vencimentos, Rentabilidade, Atualizacao e Lancamentos (situação da frota e
                  lançamentos de campo)
  public/                    front-end: uma página por módulo (HTML) + assets/css, assets/js, assets/img + relatorios/
                             lancamentos.html é a tela do celular; manifest.json permite adicioná-la à tela inicial
  servico/                   instalar_servico.bat e desinstalar_servico.bat
  scripts/                   definir_versao.ps1, gerar_pacote.ps1, atualizar.ps1 (usado pela tela Atualização) e smoke_test.ps1
  migrador/                  MigradorDados (Delphi 2006 + BDE): leva os dados do sistema antigo (Paradox) para o SQLite; tem README próprio
  tests/                     SisTerTests.dpr (DUnitX): Validacao, PasswordHelper, JwtHelper, LimitadorTaxa, BackupRegras,
                             EstoqueRegras, AtualizacaoRegras, ChaveBancoRegras
  Logs/, backup/             criadas sozinhas ao lado do .exe
  Atualizacao/               criada pela tela Atualização (pacote baixado, andamento e resultado)
  dist/                      saída do gerar_pacote.ps1 (SisTer_v<versão>.zip e .sha256)
```

## Compilar e rodar

1. Abra `backend/SisTerAPI.dpr` no Delphi 12.
2. As pastas `Database\` e `public\` precisam ficar ao lado do `.exe`. O mais simples é apontar
   *Project > Options > Building > Delphi Compiler > Output directory* para `.\` (raiz do projeto).
3. Compile e rode. Na primeira execução o servidor cria o banco, aplica as migrações, cria o `sister.ini`
   e o usuário inicial. Nas seguintes só aplica as migrações novas (controladas pela tabela `_migracoes`),
   então atualizar o sistema nunca apaga nem duplica dados.
4. Para uso no dia a dia, instale como serviço (seção *Rodar como serviço do Windows*).
5. Abra `http://localhost:9000`. Login inicial: **`admin`**. A senha inicial é **aleatória e aparece uma única vez
   no console** na primeira execução (anote-a); para definir a sua, use a variável de ambiente
   `SISTER_ADMIN_INITIAL_PASSWORD` (mín. 10 caracteres) antes de iniciar. A troca é obrigatória no primeiro acesso.
   Senhas de usuários precisam de pelo menos 10 caracteres.

A `001_schema_atual.sql` cria o **schema completo** e os dados iniciais (perfis, permissões, caixa geral e catálogo de
equipamentos): ela consolida as antigas 001 a 015, então um banco novo já nasce no schema final e sem `DROP COLUMN`.
Depois dela: a `002_permissoes_novos_modulos.sql` (módulos Auditoria, Atualização, Rentabilidade e Vencimentos) e a
`003_situacao_frota.sql` (tabela `frota_ocorrencias`, módulos da situação da frota e perfis Limpeza e Garagem).
**Bancos criados com o histórico antigo (001–015 separadas) não são compatíveis**: o servidor avisa na partida e pede para
renomear/apagar `Database\sister.db` e criar um novo.

Para novas tabelas ou colunas, crie a próxima migração (`002_...sql`) em `Database/migrations/`; nunca edite
uma já aplicada. Cada migração roda **dentro de uma transação** junto com o seu registro em `_migracoes` (se falhar,
nada fica pela metade), e, em banco que já tinha dados, o servidor grava antes uma cópia em
`Database\pre_migracao\`. Evite `;` dentro de textos ou triggers: o executor separa os comandos por `;` no fim de linha.

## Configuração (sister.ini)

Fica ao lado do `.exe`. Reinicie o servidor depois de editar.

| Seção / chave | Padrão | Função |
|---|---|---|
| `[Servidor] Porta` | `9000` | Porta do servidor |
| `[Servidor] ApenasLocalhost` | `0` | `0` aceita a rede interna; `1` escuta só em `127.0.0.1` (use com o túnel Cloudflare) |
| `[Seguranca] JwtSecret` | gerada sozinha | Chave que assina os tokens (mín. 32 caracteres). Também aceita a variável de ambiente `SISTER_JWT_SECRET`. Trocar desconecta todos |
| `LimiteRequisicoesPorMinuto` | `600` | Limite por IP em toda a `/api` |
| `LoginMaxFalhas` | `5` | Senhas erradas (mesmo usuário e IP) em 15 min antes do bloqueio |
| `LoginMaxFalhasPorIp` | `30` | Senhas erradas por IP em 15 min antes do bloqueio |
| `LoginBloqueioMinutos` | `15` | Duração do bloqueio (resposta 429 com `Retry-After`) |
| `MaxCorpoKB` | `4096` | Tamanho máximo do corpo de uma requisição (acima disso, erro 413) |
| `ProxiesConfiaveis` | `127.0.0.1,::1` | De onde se aceita o cabeçalho `CF-Connecting-IP` |
| `[Atualizacao] Url` | vazio | Endereço (HTTPS) do pacote de atualização; gravado pela tela Atualização |
| `[Backup] Ativo` | `1` | Liga/desliga o backup automático |
| `[Backup] Hora` | `02:00` | Hora do backup diário |
| `[Backup] Pasta` | `backup` | Pasta de destino (relativa ao `.exe` ou caminho completo) |
| `[Backup] ManterDias` | `30` | Dias de backups guardados (os 3 mais recentes nunca são apagados) |
| `[Backup] Compactar` | `1` | `1` gera `.zip`; `0` gera `.db` puro |

**Trate o `sister.ini` como uma senha**: a `JwtSecret` permite forjar login. Ele **não pode ser versionado**
(está no `.gitignore`); o repositório traz só o `sister.ini.example`, sem chave. Se um `sister.ini` real já foi
para o repositório, apague o valor de `JwtSecret` no servidor (uma nova é gerada) e remova o arquivo do Git.

## Usuários e permissões

- Cada perfil tem, por módulo, as permissões **ver, incluir, editar e excluir**. Módulos: `clientes`, `funcionarios`, `frota`,
  `faturas` (agenda), `caixa`, `cheques`, `estoque`, `fornecedores`, `usuarios`, `auditoria`, `atualizacao`, `rentabilidade`,
  `vencimentos`, `situacao_frota` e os de lançamento pelo celular (`lanc_limpeza`, `lanc_abastecimento`, `lanc_manutencao`).
  No módulo `atualizacao` Ver, Editar e Incluir não seguem GET/PUT/POST: o servidor confere cada ação. O módulo `salarios` controla quem vê/altera o salário do
  funcionário (só o Administrador por padrão); sem ele o campo nem sai da API e o valor gravado é preservado.
- Perfis de partida (editáveis): **Administrador** (sistema, acesso total), **Operacional**, **Financeiro**, **Limpeza** e
  **Garagem**. Limpeza e Garagem só lançam pelo celular e, ao entrar, vão direto para `lancamentos.html`. O servidor confere em toda rota; o front usa
  `GET /api/minhas-permissoes` para esconder o que o usuário não pode fazer (item de menu sem "ver", botões
  Novo/Salvar/Excluir, formulários somente leitura).
- Em HTML, a visibilidade é declarada com `data-perm="incluir|editar|excluir|salvar|salvar-sub"` nos botões e
  `data-perm-form="principal|sub|<ação>"` nos formulários (ver `Permissoes` em `assets/js/api.js`).
- Administração: criar/editar/inativar usuários, resetar senha (gera uma senha temporária de 10 caracteres,
  exibida uma única vez, com troca obrigatória no próximo login), criar/renomear/excluir perfis. O sistema
  nunca deixa remover ou desativar o **último Administrador ativo**. O perfil de sistema (`perfis.sistema = 1`,
  o Administrador) não pode ser renomeado nem excluído, e precisa manter acesso total a Usuários.
- **Só o Administrador** cria/edita/exclui perfis, redefine permissões, e mexe em usuários Administradores
  (criar, editar, inativar, reativar, resetar senha). Quem tem "editar usuários" sem ser Administrador gerencia
  só os demais usuários, e não consegue se promover.
- Troca de senha obrigatória (primeiro acesso, senha resetada) vale **no servidor**: enquanto pendente, a API só
  atende a própria troca de senha. A tela de troca também está disponível voluntariamente na barra lateral.
- A sessão é conferida no banco a cada requisição: inativar o usuário, trocar ou resetar a senha, ou mudar o
  perfil dele vale imediatamente (coluna `usuarios.token_versao`).

## Segurança

- **Banco criptografado em repouso** (AES-256): ver a seção *Criptografia do banco de dados*.
- Senhas em PBKDF2-HMAC-SHA256 **padrão (RFC 8018)**, gravadas como `pbkdf2$<iterações>$<hash>`. Hashes do formato
  antigo continuam valendo e são regravados sozinhos no próximo login correto. Ao iniciar, o console mostra quanto
  tempo 1 hash leva neste computador; ajuste `TPasswordHelper.IteracoesAtuais` se passar de ~300 ms. Login por JWT, 12 h.
- Bloqueio de força bruta no login e limite de requisições por IP (o IP real vem de `CF-Connecting-IP`, aceito
  só de conexão local ou de `ProxiesConfiaveis`, então não pode ser forjado por outras máquinas).
- Cabeçalhos: `Content-Security-Policy` (sem script embutido), `X-Frame-Options: DENY`, `nosniff`,
  `Referrer-Policy`, `Cache-Control: no-store` na `/api` e HSTS quando o acesso chega por HTTPS pelo túnel.
- Login ok, falho e bloqueado, e as ações administrativas (usuários, perfis, permissões, reset de senha) ficam
  registrados em `Logs\` (linhas `SEGURANCA:`). A tentativa de login é contada **antes** de conferir a senha
  (requisições paralelas não furam o limite), e a troca de senha também limita chutes da senha atual.
- **Trilha de auditoria** (tabela `auditoria`): criação, alteração e exclusão de clientes, funcionários, veículos (e seus
  históricos), fornecedores, equipamentos, estoque, faturas e gastos, lançamentos do caixa, contas, cheques, lançamentos da
  frota, atualizações do sistema e mudanças de permissões, com o registro antes/depois em JSON, usuário e IP.
  Consulta (só Administrador): `GET /api/auditoria?entidade=fatura&id=12&limite=100`.
- `GET /api/saude` (sem login) responde `{"status":"ok"}` para monitoramento. O script `backend/scripts/smoke_test.ps1`
  confere as proteções básicas da API.

## Criptografia do banco de dados

O arquivo `Database\sister.db`, os backups e a cópia de `pre_migracao\` ficam **criptografados (AES-256)**, com a
criptografia nativa do FireDAC. Quem copiar o arquivo (pen drive, e-mail, suporte, notebook levado) não consegue ler.

**Por que sem `sqlite3.dll`:** o servidor cria um `TFDPhysSQLiteDriverLink` **sem `VendorLib`**, o que faz o FireDAC usar o
SQLite embutido (que tem a criptografia). Sem isso o FireDAC pode carregar qualquer `sqlite3.dll` do Windows, que não
criptografa e recusa a chave com o erro `-303 Capability is not supported`.

**A chave**
- É **aleatória** (256 bits, gerador criptográfico do Windows), criada **uma única vez** na primeira execução. Não deriva de
  data, senha ou nada previsível (a data de criação do banco, por exemplo, está no próprio arquivo e seria fácil de adivinhar).
- Fica em `Database\sister.key`, **protegida pelo DPAPI do Windows** (escopo do computador): o arquivo não abre em outro
  computador nem fora desta instalação do Windows. Serviço (LocalSystem) e modo console abrem a mesma chave.
- **Chave de recuperação**: `SisTerAPI.exe --exibir-chave` mostra a chave. **Anote e guarde FORA do servidor** (cofre de
  senhas ou papel no cofre; não envie por e-mail/chat). Sem ela, um backup não volta depois de reinstalar o Windows ou trocar
  o servidor, e os dados são irrecuperáveis. `SisTerAPI.exe --definir-chave` grava uma chave de recuperação em outro computador.

**O que protege e o que não protege**
- Protege: cópia do `sister.db`, de backups ou da pasta `Database\` levada para fora do servidor.
- Não protege contra quem já controla este Windows (administrador local, malware) nem contra quem leva o **disco inteiro** e
  lê o registro offline. Para isso, ligue o **BitLocker** no disco do servidor e restrinja a pasta `Database\` (só
  Administradores e SYSTEM).

**Conferências automáticas (o servidor se recusa a fingir segurança)**
- Depois das migrações, o servidor lê o cabeçalho do arquivo: se o banco estiver em texto aberto, **não sobe**.
- Cada backup e a cópia de `pre_migracao\` são conferidos igual: se uma cópia sair legível, é **apagada** e o backup falha
  (linha `BACKUP: FALHOU` no log).
- Banco antigo sem criptografia (ex.: saída do migrador) é **criptografado sozinho** na primeira inicialização, com cópia
  temporária em `Database\pre_criptografia\`, apagada após a conferência.

**Validar a criptografia (faça uma vez, no ambiente de desenvolvimento)**
1. Rode `SisTerAPI.exe --console` com a pasta `Database\` sem `sister.db` e `sister.key`. Deve imprimir "CHAVE DO BANCO CRIADA"
   e, ao final das migrações, **"Banco criptografado (AES-256): OK."**
2. Abra `Database\sister.db` num editor hexadecimal: o início **não** pode ser o texto `SQLite format 3`.
3. Abra o arquivo no DB Browser/DBeaver sem senha: deve falhar ("file is not a database").
4. Force um backup e confira que o `.db` dentro do `.zip` também não tem esse texto.
5. Rode `tests\SisTerTests.dpr` (inclui `Test.ChaveBancoRegras`).
Se aparecer "GRAVADO SEM CRIPTOGRAFIA" ou `-303`, o FireDAC não está usando o motor embutido: confira se o projeto
compila em **Win32** com o `DriverLink` sem `VendorLib` e envie a mensagem completa ao suporte.

**Restaurar um backup** (mesmo servidor): como na seção *Backup*. **Em outro computador**: antes de ligar o servidor, rode
`SisTerAPI.exe --definir-chave` e informe a chave de recuperação.

## Versão do sistema

A versão fica em **`src\Common\Versao.pas`** (`VERSAO_SISTEMA`, ex.: `1.0.0`), no formato `MAIOR.MENOR.CORREÇÃO`
(correção = conserto sem mudança visível; menor = função nova compatível, em geral com migração; maior = mudança grande).
Para lançar uma versão nova: `backend\scripts\definir_versao.ps1 -Versao 1.2.0` (atualiza `Versao.pas` e a versão do
`.exe` nos dois `.dproj`), compile os dois projetos e, se usar Git, `git tag v1.2.0`.

Para saber o que o cliente está usando, qualquer um destes:
- **Menu lateral das telas**: rodapé "SisTer v1.2.0"; passando o mouse mostra a data de compilação e a versão do banco.
- **`GET /api/versao`** (exige login): `{"versao","compilado_em","banco"}`. `banco` é a última migração aplicada (ex.: `001_schema_atual`).
- **Console / `Logs\servico_console.log`**: linha "Versao ..." no banner; **`Logs\servico.log`**: a cada início do serviço.
- **Propriedades do `.exe` > Detalhes**: versão do arquivo (sem precisar iniciar nada).

## Rodar como serviço do Windows

Há um único executável, `SisTerAPI.exe`, com dois modos:

| Como é iniciado | Modo |
|---|---|
| Duplo clique, prompt, F9 no Delphi ou `SisTerAPI.exe --console` | **Console**: logs na janela, Ctrl+C encerra. Use nos testes e na **primeira execução**. |
| Pelo Windows (serviço instalado) | **Serviço**: sobe com o Windows, reinicia sozinho se cair. |

Instalação (no servidor do cliente):
1. Rode `SisTerAPI.exe` (modo console) **uma vez**: cria o banco e mostra a senha inicial do `admin` (anote). Feche com Ctrl+C.
2. Compile `SisTerAPI.dproj` e deixe o `SisTerAPI.exe` na mesma pasta (junto de `public\`, `Database\` e `sister.ini`; **sem** `sqlite3.dll`).
3. Execute `servico\instalar_servico.bat` **como Administrador**. Ele cria o serviço `SisTerAPI` (início automático com atraso, reinício automático em falha) e o inicia.
4. Atualizar: pela tela **Atualização** (recomendado; baixa, confere, instala e reverte sozinho se falhar) ou à mão: `net stop SisTerAPI`, troque os arquivos, `net start SisTerAPI`. Remover: `servico\desinstalar_servico.bat` (não apaga banco, logs nem backups).

Em modo serviço não há janela: a "tela" do servidor vai para `Logs\servico_console.log` (migrações aplicadas, tempo do hash, banner) e o ciclo de vida (iniciou, parou, falhou e por quê) para `Logs\servico.log`. Se o serviço não sobe, comece por esses dois arquivos.
O serviço roda como `LocalSystem` por padrão (tem acesso à pasta). Para restringir, crie uma conta/serviço virtual e dê permissão de escrita só em `Database\`, `Logs\` e `backup\`.

## Publicação com túnel Cloudflare

1. Instale o `cloudflared` **no mesmo computador** do servidor, como serviço, apontando só para
   `http://localhost:9000` (com regra final `http_status:404`).
2. Teste pelo domínio; o IP real do visitante aparece nos logs.
3. Quando todos acessarem pelo túnel, defina `ApenasLocalhost=1` e reinicie (a rede interna deixa de acessar
   pelo IP do servidor).
4. Na Cloudflare, recomendado: **Access** (login na frente do sistema), rate limit em `/api/auth/login` e
   bloqueio de países que não usam o sistema.

**Checklist antes de publicar**
- [ ] Trocar a senha do `admin`
- [ ] Guardar o `sister.ini` com cuidado (não enviar por e-mail ou chat)
- [ ] `[Backup] Pasta` apontando para outro disco, pen drive ou pasta de rede
- [ ] Porta 9000 fechada no firewall para fora da rede interna
- [ ] Sem `sqlite3.dll` ao lado do `.exe`; chave de recuperação anotada (`SisTerAPI.exe --exibir-chave`) e guardada fora do servidor; BitLocker ligado no disco

## Backup

Uma vez por dia (e, se o servidor estava desligado na hora marcada, assim que for ligado) o servidor grava
uma cópia do `Database\sister.db`, com o sistema em uso e sem travar ninguém:

- Arquivo `sister_AAAA-MM-DD_HHMMSS.zip` (ou `.db`) na pasta configurada. A cópia é conferida
  (`PRAGMA quick_check`) antes de receber o nome final; enquanto está sendo feita termina em `.partial`
  e nunca conta como backup.
- Guarda `ManterDias` dias; os 3 mais recentes nunca são apagados. Em caso de falha, tenta de novo em 30 min.
- Tudo é registrado em `Logs\` (linhas `BACKUP:`). Se não houver um `BACKUP: OK` por dia, algo está errado.
- O backup guarda **só o banco** (criptografado: um `.zip` quase não encolhe). O `sister.ini` e a **chave de recuperação** devem ser guardados à parte.

**Restaurar:** (em outro computador, rode antes `SisTerAPI.exe --definir-chave`) pare o servidor, descompacte o backup, substitua `Database\sister.db` por ele (apague
`sister.db-wal` e `sister.db-shm`, se existirem) e ligue o servidor.

## Logs

`Logs\sister_AAAA-MM-DD.log`, um arquivo por dia. Erros, eventos de segurança e de backup são **sempre**
gravados. O rastro detalhado liga e desliga sem reiniciar, em `Logs\log.ini` (`[Log] Ativo=1`).

## Regras de negócio

**Agenda / faturas** (calculadas sempre no servidor)
- Valor líquido = nota − imposto − retenção previdenciária. Imposto: municipal 3% ou 12%; intermunicipal 12%
  sobre 20% da nota, ou 17%. Retenção: 11% sobre 30% da nota.
- Duplicata numerada automaticamente por ano, quando deixada em branco.
- Conflito de veículo (sobreposição real de período) bloqueia o salvamento; conflito de motorista é só aviso. Veículo parado para
  manutenção sem volta antes da saída também é só aviso (`GET /api/agenda/conflitos` devolve `conflitos` e `avisos`).
- Excluir viagem exige a permissão "excluir" do perfil.
- Despesas da viagem: `total = pedágio + hotel + refeição + combustível + outras` e `saldo = adiantamento − total`.
  *Fórmula adotada por convenção: o sistema antigo digitava esses campos à mão. Ajuste em `FaturasController.pas`
  se a regra da empresa for outra.*

**Situação da frota e lançamentos de campo**
- O livro `frota_ocorrencias` guarda fatos lançados no pátio: limpeza concluída, abastecimento, parou para manutenção e
  veículo liberado. A situação do veículo **não é gravada**: é calculada com esse livro e a Agenda (como o saldo do Estoque).
- **Em manutenção**: existe um "parou" sem o "liberado" depois. **Em viagem**: viagem *confirmada* em andamento (hoje, pelo
  horário; em outra data, pelo dia; viagem sem hora de volta conta até 23:59). **Com pendência**: voltou de viagem confirmada
  nos últimos 7 dias e ninguém lançou a limpeza depois (só vale para hoje). **Pronto**: nenhuma das anteriores.
- **Atenção na escala**: veículo em manutenção (sem previsão ou com volta depois da saída) com saída confirmada nos próximos
  7 dias, ou com limpeza pendente e saída confirmada nas próximas 24 h.
- Abastecimento: KM e litros obrigatórios; o KM não pode ser menor que o último registrado nem passar de 15 mil km acima dele;
  litros acima de 120% da capacidade do tanque são recusados. Grava também a linha de média km/l do cadastro do veículo.
- Liberar da manutenção grava a linha de manutenção do cadastro (com o serviço feito, o custo e o KM, se informados).
- Hora do lançamento: a do servidor. O celular só pode mandar a hora em que o lançamento foi feito (fila sem sinal) se for
  de até 72 h atrás e não estiver no futuro. Cada lançamento leva uma chave única, então reenviar não duplica.
- Desfazer nunca apaga: o lançamento fica cancelado (quem, quando e motivo) e some do histórico do veículo. Quem lançou
  desfaz o próprio em até 30 min; depois (ou de outra pessoa) é preciso `excluir` no módulo do tipo ou em `situacao_frota`, com
  motivo. Não dá para desfazer a parada se a liberação ainda existe: desfaz-se primeiro a liberação.
- O nome do cliente das viagens só aparece para quem vê `situacao_frota`.

**Financeiro**
- Entrada só entra no saldo depois de marcada como paga.
- Saída que estoura o limite mensal da conta retorna HTTP 409; a tela pergunta "Continua?" e, confirmando,
  reenvia com `?forcar=1`.
- O relatório antigo de Balancete não foi portado (regra de negócio não confirmada).

**Funcionários e frota**
- Foto do funcionário: redimensionada no navegador (máx. 320 px) e gravada em base64; só é lida ao abrir o
  cadastro, para não pesar listagens.
- Alertas de vencimento (CNH, exame de saúde, documentos do veículo) são calculados no navegador: vermelho
  vencido, âmbar em até 30 dias.

**Migração de dados do sistema antigo (Paradox)**: o programa `migrador\` (Delphi 2006 + BDE, README próprio) lê as tabelas
antigas e grava no SQLite. O motorista da fatura era `funtip = 'M'`; aqui o tipo é o texto `Motorista`, então a rotina
de migração precisa mapear `M` para `Motorista`.

## Convenções para desenvolvimento

- **Nada de script ou handler embutido no HTML** (`<script>...</script>`, `onclick="..."`): a CSP do servidor
  bloqueia. Todo JavaScript fica em arquivo `.js` (`assets/js/` ou `relatorios/`), inclusive em páginas novas.
- **Decimais em JSON** passam por `TJsonHelper.Numero` (`src\Common\JsonHelper.pas`): JSON usa ponto, e a
  configuração regional do Windows (pt-BR) usa vírgula, o que gera resposta inválida.
- **Data e hora gravadas explicitamente em horário local**: use `datetime('now','localtime')` e
  `date('now','localtime')` nos INSERT/UPDATE; o `DEFAULT (datetime('now'))` do SQLite grava em UTC.
- **Conexões**: `ConexaoGlobal` devolve uma conexão por thread, emprestada de um pool (até 25). Nunca
  compartilhe uma `TFDConnection` entre threads.
- **Textos da interface** (menus, títulos, rótulos, botões e este README) usam somente a primeira letra em maiúscula, exceto
  nomes próprios e siglas: "Agenda de viagens", "Situação da frota".
- **Páginas só para celular** (`lancamentos.html`) usam `assets/css/campo.css`; as de gestão usam `style.css` + um CSS próprio.
- **Texto vindo do banco** deve ser escapado antes de entrar em `innerHTML` no front.
- O front é servido por `ArquivosEstaticos.pas` (middleware próprio, sem libs de terceiros), o que evita um
  problema de acentuação visto na `horse-staticfiles`.

## Limitações conhecidas

- Valores em dinheiro continuam em `REAL` (os somatórios já são arredondados a 2 casas). Migrar para centavos
  inteiros é a evolução prevista.
- Exclusões no caixa e na agenda ainda são físicas; a trilha de auditoria guarda o registro apagado. Estorno
  lógico depende de decisão do financeiro.
- Dados antigos fora do padrão (data que não é AAAA-MM-DD, hora que não é HH:MM, CPF/CNPJ com dígito errado)
  continuam lendo normalmente, mas o servidor recusa **salvar** o registro até o campo ser corrigido (a mensagem
  cita o campo).
- `boss-lock.json` precisa ser regenerado com `boss install` na máquina de desenvolvimento.
- O modo serviço e a atualização automática só funcionam no Windows. Em modo console (testes) a tela Atualização não instala.
- A tela do celular não é um aplicativo offline completo: sem sinal ela guarda **lançamentos** para enviar depois, mas os dados
  dos veículos precisam ter sido carregados antes (e não há service worker).
- A situação da frota e o aviso de manutenção da Agenda são informativos: não impedem salvar uma viagem.
- `TrialControl.pas` (período de teste) está no projeto, mas não é chamado; ligue-o conforme `ajuste_versao_trial.txt` se precisar.
- A busca de viagens na Agenda não pesquisa por motorista.
- Não portados do sistema antigo: foto do veículo, envio de e-mail da tela de frota, botão de Nota Fiscal e
  baixa de estoque da fatura.

## Estoque e fornecedores

- **O saldo nunca é gravado**: é a soma das movimentações (view `v_estoque_saldo`). Tipos: `E` entrada, `S` saída,
  `A` ajuste de inventário (quantidade com sinal). Editar ou excluir uma movimentação também é checado: se o saldo ficasse
  negativo, a operação inteira (e a auditoria) é desfeita.
- `estoque_itens.id_item` é o **código** do item. O migrador deve gravar nele o código do sistema antigo, para manter o
  vínculo que `veiculo_manutencoes.id_estoque` já guarda.
- Item "para repor" = estoque mínimo informado (> 0) e saldo menor ou igual a ele. Valor em estoque = saldo x custo médio
  ponderado das entradas que têm valor unitário.
- Rotas: `/api/estoque`, `/api/estoque/:id/movimentos`, `/api/estoque/:id/inventario`, `/api/estoque-opcoes`,
  `/api/fornecedores`, `/api/fornecedores/:id/contatos`, `/api/fornecedores/:id/compras`.
- Permissões: `estoque` e `fornecedores` (Administrador total; Operacional sem excluir; Financeiro vê o estoque e cuida
  dos fornecedores). A aba Compras do fornecedor exige também `estoque: ver`.
