// Situação da frota: painel do gestor (GET /api/situacao-frota) + lista de lançamentos (GET /api/lancamentos).
exigirLogin();

const $ = (id) => document.getElementById(id);

const usuarioLogado = Api.usuario();
if (usuarioLogado) {
  $('nomeUsuario').textContent = usuarioLogado.nome;
  $('perfilUsuario').textContent = usuarioLogado.perfil;
  $('avatarUsuario').textContent = usuarioLogado.nome.charAt(0).toUpperCase();
  if (usuarioLogado.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML;
}
const esc = escaparHtml;
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3600);
}

// ------------------------------------------------------------------ datas e textos
const CATEGORIAS = {
  mecanica: 'Mecânica', eletrica: 'Elétrica', pneus: 'Pneus', freios: 'Freios',
  ar_condicionado: 'Ar-condicionado', lataria: 'Lataria e pintura', revisao: 'Revisão', outro: 'Outro',
};
const LIMPEZAS = { completa: 'Completa', interna: 'Interna', externa: 'Externa' };
const NOMES_TIPO = { limpeza: 'Limpeza', abastecimento: 'Abastecimento', manutencao_entrada: 'Parou para manutenção', manutencao_saida: 'Veículo liberado' };
const COLUNAS = [
  { id: 'pronto', titulo: 'Prontos' },
  { id: 'viagem', titulo: 'Em viagem' },
  { id: 'pendente', titulo: 'Com pendência' },
  { id: 'manutencao', titulo: 'Em manutenção' },
];

const dm = (iso) => (iso && iso.length >= 10 ? iso.slice(8, 10) + '/' + iso.slice(5, 7) : '');
const hhmm = (s) => (s || '').slice(11, 16);
const fmtNum = (n, d) => Number(n).toLocaleString('pt-BR', { maximumFractionDigits: d == null ? 1 : d });
const p2 = (n) => String(n).padStart(2, '0');
function isoLocal(d) { return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); }
function somaDias(iso, n) {
  const [a, m, d] = iso.split('-').map(Number);
  return isoLocal(new Date(a, m - 1, d + n));
}
function parseTS(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/.exec(s || '');
  return m ? new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]) : null;
}
function relativo(s) {
  const d = parseTS(s);
  if (!d) return '';
  const min = Math.round((Date.now() - d.getTime()) / 60000);
  if (min < 1) return 'agora';
  if (min < 60) return 'há ' + min + ' min';
  const base = new Date(); base.setHours(0, 0, 0, 0);
  const dias = Math.round((base - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 86400000);
  if (dias <= 0) return 'hoje ' + hhmm(s);
  if (dias === 1) return 'ontem ' + hhmm(s);
  return 'há ' + dias + ' dias';
}
// "hoje 18:00", "amanhã 06:00", "26/10 06:00"
function rotuloData(iso, hora) {
  if (!iso) return '';
  const ref = dados ? dados.hoje : isoLocal(new Date());
  let t;
  if (iso === ref) t = 'hoje';
  else if (iso === somaDias(ref, 1)) t = 'amanhã';
  else t = dm(iso);
  return t + (hora ? ' ' + hora : '');
}

// ------------------------------------------------------------------ estado da tela
let dados = null;
let dataSel = '';
let filtroEstado = '';
let busca = '';
let aba = 'painel';
let lanc = [];

// ------------------------------------------------------------------ painel
async function carregarPainel(silencioso) {
  try {
    const q = dataSel ? '?data=' + encodeURIComponent(dataSel) : '';
    dados = await Api.get('/situacao-frota' + q);
    dataSel = dados.data;
    $('dtSel').value = dataSel;
    renderPainel();
  } catch (e) {
    if (!silencioso) mostrarToast(e.message || 'Não foi possível carregar a situação da frota.');
  }
}

const ehHoje = () => dados && dados.data === dados.hoje;
const letreiro = (v) => '<span class="letreiro ' + esc(v.estado) + '"><b>' + esc(v.numero) + '</b></span>';

function textoRisco(v) {
  const r = v.risco;
  if (!r) return '';
  const saida = rotuloData(r.data_saida, r.hora_saida) + (r.destino ? ' para ' + r.destino : '') + (r.cliente ? ' (' + r.cliente + ')' : '');
  if (r.motivo === 'manutencao') {
    const prev = v.manut && v.manut.previsao ? 'previsão de volta ' + dm(v.manut.previsao) : 'sem previsão de volta';
    return 'Em manutenção (' + prev + ') e tem saída ' + saida + '.';
  }
  return 'Limpeza pendente e tem saída ' + saida + '.';
}

function renderPainel() {
  const r = dados.resumo;
  const hoje = ehHoje();
  $('kPronto').textContent = r.pronto;
  $('kViagem').textContent = r.viagem;
  $('kPendente').textContent = hoje ? r.pendente : '—';
  $('kManut').textContent = r.manutencao;
  $('rPronto').textContent = hoje ? 'PRONTOS' : 'LIVRES EM ' + dm(dados.data);
  document.querySelectorAll('#kpis .kpi').forEach((k) => k.classList.toggle('ativo', k.dataset.estado === filtroEstado));
  $('notaTopo').textContent = hoje
    ? 'Quem está pronto, em viagem, com pendência ou parado. Atualiza sozinho a cada minuto.'
    : 'Previsão para ' + dm(dados.data) + ': viagens confirmadas da Agenda e veículos parados. A limpeza só é cobrada para hoje.';

  // atenção na escala
  const risco = dados.veiculos.filter((v) => v.risco);
  const a = $('alertaEscala');
  if (risco.length) {
    a.hidden = false;
    a.innerHTML = '<h2>Atenção na escala · ' + risco.length + (risco.length === 1 ? ' veículo' : ' veículos') + '</h2><ul>' +
      risco.map((v) => '<li><button type="button" data-id="' + v.id_veiculo + '">' + letreiro(v) + '<span><b class="num">Veículo ' + esc(v.numero) + '</b> · ' + esc(v.placa) + ' — ' + esc(textoRisco(v)) + '</span></button></li>').join('') + '</ul>';
  } else {
    a.hidden = true;
  }

  // quadro
  const q = busca.trim().toUpperCase().replace(/[^A-Z0-9 ]/g, '');
  const bate = (v) => !q || String(v.numero) === q || (v.placa || '').toUpperCase().replace(/[^A-Z0-9]/g, '').indexOf(q.replace(/ /g, '')) >= 0 ||
    ((v.marca || '') + ' ' + (v.modelo || '')).toUpperCase().indexOf(q) >= 0;
  const cols = COLUNAS.filter((c) => (hoje || c.id !== 'pendente') && (!filtroEstado || c.id === filtroEstado));
  const quadro = $('quadro');
  quadro.className = 'quadro' + (filtroEstado ? ' um-grupo' : (cols.length === 3 ? ' tres' : ''));
  $('btnTodos').hidden = !filtroEstado;
  quadro.innerHTML = cols.map((c) => {
    let lista = dados.veiculos.filter((v) => v.estado === c.id && bate(v));
    if (c.id === 'viagem') lista.sort((x, y) => String(x.viagem && (x.viagem.data_volta + x.viagem.hora_volta)).localeCompare(String(y.viagem && (y.viagem.data_volta + y.viagem.hora_volta))));
    if (c.id === 'pendente' || c.id === 'manutencao') lista.sort((x, y) => (y.risco ? 1 : 0) - (x.risco ? 1 : 0) || x.numero - y.numero);
    const titulo = c.id === 'pronto' && !hoje ? 'Livres em ' + dm(dados.data) : c.titulo;
    return '<section class="col-' + c.id + '"><div class="coluna-cab"><h2>' + esc(titulo) + '</h2><span>' + lista.length + '</span></div>' +
      '<div class="lista-coluna">' + (lista.length ? lista.map(cartao).join('') : '<div class="coluna-vazia">Nenhum veículo</div>') + '</div></section>';
  }).join('');
}

function cartao(v) {
  const linhas = [], selos = [];
  if (v.viagem) {
    const vi = v.viagem;
    linhas.push('Volta <b>' + esc(rotuloData(vi.data_volta || vi.data_saida, vi.hora_volta)) + '</b> · ' + esc(vi.destino || '') + (vi.cliente ? ' · ' + esc(vi.cliente) : ''));
    if (vi.status !== 'C') selos.push('<span class="selo info">Reserva pendente</span>');
  }
  if (v.manut) {
    const m = v.manut;
    linhas.push('<b>' + esc(CATEGORIAS[m.subtipo] || 'Manutenção') + '</b> · desde ' + esc(dm(m.desde)) + ' · ' + (m.previsao ? 'previsão ' + esc(dm(m.previsao)) : 'sem previsão'));
    if (m.descricao) linhas.push(esc(m.descricao.length > 70 ? m.descricao.slice(0, 70) + '…' : m.descricao));
  }
  const prox = (v.proximas || [])[0];
  if (prox) linhas.push('Próxima saída <b>' + esc(rotuloData(prox.data_saida, prox.hora_saida)) + '</b> · ' + esc(prox.destino || '') + (prox.status !== 'C' ? ' (pendente)' : ''));

  if (ehHoje()) {
    if ((v.pendencias || []).indexOf('limpeza') >= 0) selos.push('<span class="selo alerta">Limpeza pendente</span>');
    else if (v.limpeza_em) selos.push('<span class="selo ok">Limpo ' + esc(relativo(v.limpeza_em)) + '</span>');
    else selos.push('<span class="selo">Sem registro de limpeza</span>');
    if (v.abast_em) selos.push('<span class="selo">Abastecido ' + esc(relativo(v.abast_em)) + '</span>');
  }
  const risco = v.risco ? '<div class="veic-risco">' + esc(textoRisco(v)) + '</div>' : '';
  return '<button type="button" class="veic" data-id="' + v.id_veiculo + '"><div class="veic-topo">' + letreiro(v) +
    '<div class="veic-id"><span class="placa">' + esc(v.placa) + '</span><div class="veic-modelo">' + esc([v.marca, v.modelo].filter(Boolean).join(' ')) + (v.lotacao ? ' · ' + v.lotacao + ' lug.' : '') + '</div></div></div>' +
    (linhas.length ? '<div class="veic-linhas">' + linhas.map((l) => '<div>' + l + '</div>').join('') + '</div>' : '') +
    (selos.length ? '<div class="veic-selos">' + selos.join('') + '</div>' : '') + risco + '</button>';
}

// ------------------------------------------------------------------ painel lateral do veículo
function detalheLanc(i) {
  if (i.tipo === 'limpeza') return LIMPEZAS[i.subtipo] || 'Completa';
  if (i.tipo === 'abastecimento') return [i.litros ? fmtNum(i.litros) + ' L' : '', i.km ? fmtNum(i.km, 0) + ' km' : '', i.valor ? 'R$ ' + fmtNum(i.valor, 2) : '', i.local].filter(Boolean).join(' · ');
  if (i.tipo === 'manutencao_entrada') return [CATEGORIAS[i.subtipo] || '', i.descricao, i.previsao_retorno ? 'previsão ' + dm(i.previsao_retorno) : ''].filter(Boolean).join(' · ');
  return [i.descricao, i.valor ? 'R$ ' + fmtNum(i.valor, 2) : '', i.km ? fmtNum(i.km, 0) + ' km' : ''].filter(Boolean).join(' · ');
}

async function abrirVeiculo(id) {
  const v = dados.veiculos.find((x) => x.id_veiculo === id);
  if (!v) return;
  const ESTADO = { pronto: 'Pronto', viagem: 'Em viagem', pendente: 'Com pendência', manutencao: 'Em manutenção' };
  $('pvCabecalho').innerHTML = letreiro(v) + '<div><h2>' + esc(v.placa) + '</h2><div class="sub">' + esc([v.marca, v.modelo].filter(Boolean).join(' ')) + (v.lotacao ? ' · ' + v.lotacao + ' lugares' : '') + '</div></div>';
  $('pvCadastro').href = 'frota.html';
  const linhas = [['Situação', ESTADO[v.estado]]];
  if (v.km_atual) linhas.push(['KM mais recente', fmtNum(v.km_atual, 0) + ' km']);
  linhas.push(['Última limpeza', v.limpeza_em ? relativo(v.limpeza_em) + (v.limpeza_por ? ' · ' + v.limpeza_por : '') : 'Sem registro']);
  linhas.push(['Último abastecimento', v.abast_em ? relativo(v.abast_em) + (v.abast_litros ? ' · ' + fmtNum(v.abast_litros) + ' L' : '') : 'Sem registro']);
  if (v.manut) linhas.push(['Parado desde', dm(v.manut.desde) + ' · ' + (CATEGORIAS[v.manut.subtipo] || '') + (v.manut.por ? ' (' + v.manut.por + ')' : '')]);
  const viagens = [];
  if (v.viagem) viagens.push(v.viagem);
  (v.proximas || []).forEach((p) => viagens.push(p));
  $('pvCorpo').innerHTML =
    '<div class="pv-bloco"><h3>Situação</h3>' + linhas.map((l) => '<div class="pv-linha"><span>' + esc(l[0]) + '</span><span>' + esc(l[1]) + '</span></div>').join('') + '</div>' +
    (v.risco ? '<div class="veic-risco" style="margin-bottom:18px;">' + esc(textoRisco(v)) + '</div>' : '') +
    '<div class="pv-bloco"><h3>Viagens na Agenda</h3>' + (viagens.length
      ? viagens.map((x) => '<div class="pv-linha"><span>' + esc(rotuloData(x.data_saida, x.hora_saida)) + (x.data_volta && x.data_volta !== x.data_saida ? ' → ' + esc(dm(x.data_volta)) : '') + '</span><span>' + esc(x.destino || '') + (x.cliente ? ' · ' + esc(x.cliente) : '') + (x.status !== 'C' ? ' (pendente)' : '') + '</span></div>').join('')
      : '<div class="nota">Nenhuma viagem nos próximos 30 dias.</div>') + '</div>' +
    '<div class="pv-bloco"><h3>Últimos lançamentos</h3><div id="pvHist" class="nota">Carregando…</div></div>';
  $('fundoVeiculo').classList.add('aberto');
  $('painelVeiculo').classList.add('aberto');
  try {
    const r = await Api.get('/lancamentos?id_veiculo=' + id + '&limite=15');
    const lista = r.dados || [];
    $('pvHist').outerHTML = lista.length
      ? '<ul class="pv-hist" id="pvHist">' + lista.map((i) => '<li class="' + (i.cancelado ? 'desfeito' : '') + '"><span class="quando">' + esc(dm(i.data_hora)) + ' ' + esc(hhmm(i.data_hora)) + '</span><span><b>' + esc(NOMES_TIPO[i.tipo] || i.tipo) + '</b>' + (detalheLanc(i) ? ' · ' + esc(detalheLanc(i)) : '') + '<br><span class="nota">' + esc(i.usuario_nome || '') + '</span></span></li>').join('') + '</ul>'
      : '<div class="nota" id="pvHist">Ainda não há lançamentos para este veículo.</div>';
  } catch (e) {
    $('pvHist').textContent = 'Não foi possível carregar o histórico.';
  }
}
function fecharVeiculo() {
  $('fundoVeiculo').classList.remove('aberto');
  $('painelVeiculo').classList.remove('aberto');
}

// ------------------------------------------------------------------ lançamentos
async function carregarLancamentos() {
  const p = new URLSearchParams({ limite: '300' });
  if ($('lTipo').value) p.set('tipo', $('lTipo').value);
  if ($('lDe').value) p.set('de', $('lDe').value);
  if ($('lAte').value) p.set('ate', $('lAte').value);
  try {
    const r = await Api.get('/lancamentos?' + p.toString());
    lanc = r.dados || [];
    renderLancamentos();
  } catch (e) {
    mostrarToast(e.message || 'Não foi possível carregar os lançamentos.');
  }
}

function renderLancamentos() {
  const q = $('lBusca').value.trim().toUpperCase();
  const mostrarDesfeitos = $('lDesfeitos').checked;
  const lista = lanc.filter((i) => (mostrarDesfeitos || !i.cancelado) &&
    (!q || String(i.numero) === q || (i.placa || '').toUpperCase().indexOf(q) >= 0 || (i.usuario_nome || '').toUpperCase().indexOf(q) >= 0));
  $('vazioLanc').style.display = lista.length ? 'none' : '';
  $('corpoLanc').innerHTML = lista.map((i) => {
    const det = detalheLanc(i);
    return '<tr class="sem-link' + (i.cancelado ? ' desfeito' : '') + '">' +
      '<td class="lanc-quando">' + esc(dm(i.data_hora)) + ' ' + esc(hhmm(i.data_hora)) + '<small>' + esc(relativo(i.data_hora)) + '</small></td>' +
      '<td><div class="lanc-veic"><span class="letreiro pronto"><b>' + esc(i.numero) + '</b></span><span class="placa">' + esc(i.placa) + '</span></div></td>' +
      '<td><span class="lanc-tipo">' + esc(NOMES_TIPO[i.tipo] || i.tipo) + '</span>' + (det ? '<span class="lanc-det">' + esc(det) + '</span>' : '') +
      (i.cancelado ? '<span class="lanc-det">Desfeito por ' + esc(i.cancelado_por || '?') + (i.motivo_cancelamento ? ': ' + esc(i.motivo_cancelamento) : '') + '</span>' : '') + '</td>' +
      '<td>' + esc(i.usuario_nome || '') + '</td>' +
      '<td>' + (i.pode_desfazer && !i.cancelado ? '<button type="button" class="btn-mini" data-desfazer="' + i.id_ocorrencia + '">Desfazer</button>' : '') + '</td></tr>';
  }).join('');
  $('notaLanc').textContent = lanc.length >= 300 ? 'Mostrando os 300 lançamentos mais recentes do período. Use os filtros para refinar.' : '';
}

// desfazer (pede o motivo)
let desfazendo = null;
function abrirDesfazer(id) {
  const i = lanc.find((x) => x.id_ocorrencia === id);
  if (!i) return;
  desfazendo = i;
  $('mdResumo').textContent = (NOMES_TIPO[i.tipo] || i.tipo) + ' · veículo ' + i.numero + ' · ' + dm(i.data_hora) + ' ' + hhmm(i.data_hora) + ' · ' + (i.usuario_nome || '');
  $('mdMotivo').value = '';
  $('mdErro').style.display = 'none';
  $('fundoDesfazer').classList.add('aberto');
  $('modalDesfazer').hidden = false;
  $('mdMotivo').focus();
}
function fecharDesfazer() {
  $('fundoDesfazer').classList.remove('aberto');
  $('modalDesfazer').hidden = true;
  desfazendo = null;
}
async function confirmarDesfazer() {
  const motivo = $('mdMotivo').value.trim();
  if (motivo.length < 3) {
    $('mdErro').textContent = 'Informe o motivo (pelo menos 3 letras).';
    $('mdErro').style.display = 'block';
    return;
  }
  const b = $('mdConfirmar');
  b.disabled = true;
  try {
    await Api.post('/lancamentos/' + desfazendo.id_ocorrencia + '/desfazer', { motivo });
    fecharDesfazer();
    mostrarToast('Lançamento desfeito.');
    await Promise.all([carregarLancamentos(), carregarPainel(true)]);
  } catch (e) {
    $('mdErro').textContent = e.message || 'Não foi possível desfazer.';
    $('mdErro').style.display = 'block';
  } finally {
    b.disabled = false;
  }
}

// ------------------------------------------------------------------ abas e eventos
function mudarAba(nome) {
  aba = nome;
  document.querySelectorAll('.abas-pagina .aba').forEach((b) => b.classList.toggle('ativa', b.dataset.aba === nome));
  $('abaPainel').hidden = nome !== 'painel';
  $('abaLancamentos').hidden = nome !== 'lancamentos';
  $('abaCelular').hidden = nome !== 'celular';
  document.getElementById('kpis').hidden = nome === 'celular';
  if (nome === 'lancamentos') carregarLancamentos();
}
document.querySelectorAll('.abas-pagina .aba').forEach((b) => b.addEventListener('click', () => mudarAba(b.dataset.aba)));

document.querySelectorAll('#kpis .kpi').forEach((k) => k.addEventListener('click', () => {
  filtroEstado = filtroEstado === k.dataset.estado ? '' : k.dataset.estado;
  if (aba !== 'painel') mudarAba('painel');
  if (dados) renderPainel();
}));
$('btnTodos').addEventListener('click', () => { filtroEstado = ''; renderPainel(); });
$('fBusca').addEventListener('input', () => { busca = $('fBusca').value; if (dados) renderPainel(); });

document.addEventListener('click', (ev) => {
  const c = ev.target.closest('[data-id]');
  if (c && dados && (c.classList.contains('veic') || c.closest('#alertaEscala'))) abrirVeiculo(Number(c.dataset.id));
  const d = ev.target.closest('[data-desfazer]');
  if (d) abrirDesfazer(Number(d.dataset.desfazer));
});
$('pvFechar').addEventListener('click', fecharVeiculo);
$('fundoVeiculo').addEventListener('click', fecharVeiculo);
$('fundoDesfazer').addEventListener('click', fecharDesfazer);
$('mdCancelar').addEventListener('click', fecharDesfazer);
$('mdConfirmar').addEventListener('click', confirmarDesfazer);
$('mdMotivo').addEventListener('keydown', (ev) => { if (ev.key === 'Enter') confirmarDesfazer(); });
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') { fecharVeiculo(); fecharDesfazer(); } });

$('dtSel').addEventListener('change', () => { if ($('dtSel').value) { dataSel = $('dtSel').value; carregarPainel(); } });
$('dtAnt').addEventListener('click', () => { dataSel = somaDias(dataSel || isoLocal(new Date()), -1); carregarPainel(); });
$('dtProx').addEventListener('click', () => { dataSel = somaDias(dataSel || isoLocal(new Date()), 1); carregarPainel(); });
$('dtHoje').addEventListener('click', () => { dataSel = ''; carregarPainel(); });
$('btnAtualizar').addEventListener('click', () => { carregarPainel(); if (aba === 'lancamentos') carregarLancamentos(); });

['lTipo', 'lDe', 'lAte'].forEach((id) => $(id).addEventListener('change', carregarLancamentos));
$('lBusca').addEventListener('input', renderLancamentos);
$('lDesfeitos').addEventListener('change', renderLancamentos);

// aba "Lançar pelo celular"
$('linkCelular').value = location.origin + '/lancamentos.html';
$('btnCopiar').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText($('linkCelular').value); mostrarToast('Endereço copiado.'); }
  catch (e) { $('linkCelular').select(); mostrarToast('Selecione e copie o endereço.'); }
});

// período padrão dos lançamentos: últimos 7 dias
$('lDe').value = somaDias(isoLocal(new Date()), -7);

carregarPainel();
setInterval(() => { if (!document.hidden && aba === 'painel' && ehHoje()) carregarPainel(true); }, 60000);
