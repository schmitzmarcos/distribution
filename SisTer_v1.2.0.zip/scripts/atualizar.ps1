<#
 atualizar.ps1 - Atualizador do SisTer.

 Quem chama: o servidor (tela "Atualizacao"), que copia este script para Atualizacao\atualizar_<id>.ps1 e o inicia
 DESLIGADO do servico (ele precisa sobreviver a parada do servico). Tambem pode ser rodado a mao, como Administrador,
 se a tela nao estiver disponivel:   powershell -ExecutionPolicy Bypass -File scripts\atualizar.ps1 -Pasta C:\SisTer

 Pre-requisito: o pacote ja foi baixado, conferido e descompactado em <Pasta>\Atualizacao\staging (a tela faz isso).

 O que faz, nesta ordem:
   1. confere o pacote e o servico                  (nada e parado se algo estiver errado)
   2. para o servico e espera o .exe ficar livre
   3. guarda copia dos arquivos atuais e do banco em Atualizacao\backup\<id>
   4. troca SO os arquivos permitidos: SisTerAPI.exe, public, Database\migrations, servico, scripts, README.md,
      sister.ini.example. NUNCA toca sister.ini, Database\sister.db/.key, Logs, backup.
   5. liga o servico e confere http://127.0.0.1:<porta>/api/saude
   6. se qualquer passo falhar: REVERTE os arquivos (e o banco, se a versao nova chegou a iniciar) e liga a versao antiga

 Andamento: Atualizacao\aplicacao.json   Resultado: Atualizacao\resultado.json   Log: Logs\atualizacao_<id>.log
 -Simular: so confere e mostra o que faria, sem parar nem alterar nada.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Pasta,
    [string]$Servico = 'SisTerAPI',
    [int]$Porta = 9000,
    [string]$Id = '',
    [string]$VersaoAntes = '',
    [string]$VersaoNova = '',
    [int]$EsperaInicialSeg = 4,
    [int]$TempoMaxSaudeSeg = 120,
    [switch]$Simular
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrEmpty($Id)) { $Id = (Get-Date).ToString('yyyyMMdd_HHmmss') }
$Pasta = $Pasta.TrimEnd('\')
$Base = Join-Path $Pasta 'Atualizacao'
$Staging = Join-Path $Base 'staging'
$PastaBackup = Join-Path (Join-Path $Base 'backup') $Id
$PastaLogs = Join-Path $Pasta 'Logs'
$ArqLog = Join-Path $PastaLogs ('atualizacao_' + $Id + '.log')
$ArqAndamento = Join-Path $Base 'aplicacao.json'
$ArqResultado = Join-Path $Base 'resultado.json'
$Itens = @('SisTerAPI.exe', 'public', 'Database\migrations', 'servico', 'scripts', 'README.md', 'sister.ini.example')
$ArqsBanco = @('sister.db', 'sister.db-wal', 'sister.db-shm')
$Inicio = Get-Date
$Linhas = New-Object System.Collections.Generic.List[string]
$Utf8 = New-Object System.Text.UTF8Encoding($false)

# ------------------------------------------------------------------ utilitarios

function Log([string]$Msg) {
    $linha = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + ' ' + $Msg
    $Linhas.Add($linha)
    Write-Host $linha
    try {
        if (-not (Test-Path -LiteralPath $PastaLogs)) { New-Item -ItemType Directory -Path $PastaLogs -Force | Out-Null }
        [System.IO.File]::AppendAllText($ArqLog, $linha + "`r`n", $Utf8)
    } catch { }
}

function Gravar-Json([string]$Arquivo, $Objeto) {
    $json = $Objeto | ConvertTo-Json -Compress -Depth 5
    for ($i = 0; $i -lt 5; $i++) {
        try { [System.IO.File]::WriteAllText($Arquivo, $json, $Utf8); return } catch { Start-Sleep -Milliseconds 300 }
    }
}

function Andamento([string]$Fase, [string]$Msg) {
    Log ('[' + $Fase + '] ' + $Msg)
    Gravar-Json $ArqAndamento ([ordered]@{
        id = $Id; fase = $Fase; mensagem = $Msg; versao_antes = $VersaoAntes; versao_nova = $VersaoNova
        inicio = $Inicio.ToString('yyyy-MM-dd HH:mm:ss'); atualizado = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    })
}

function Concluir([bool]$Ok, [bool]$Revertido, [bool]$NoAr, [string]$Etapa, [string]$Msg) {
    $cauda = @($Linhas | Select-Object -Last 60)
    Gravar-Json $ArqResultado ([ordered]@{
        id = $Id; ok = $Ok; revertido = $Revertido; no_ar = $NoAr; etapa = $Etapa; mensagem = $Msg
        versao_antes = $VersaoAntes; versao_nova = $VersaoNova
        inicio = $Inicio.ToString('yyyy-MM-dd HH:mm:ss'); fim = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); log = $cauda
    })
    $fase = 'falhou'
    if ($Ok) { $fase = 'concluido' } elseif ($Revertido) { $fase = 'revertido' }
    Gravar-Json $ArqAndamento ([ordered]@{
        id = $Id; fase = $fase; mensagem = $Msg; versao_antes = $VersaoAntes; versao_nova = $VersaoNova
        inicio = $Inicio.ToString('yyyy-MM-dd HH:mm:ss'); atualizado = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    })
}

function Copiar-Arquivo([string]$Origem, [string]$Destino) {
    for ($t = 1; $t -le 6; $t++) {
        try { Copy-Item -LiteralPath $Origem -Destination $Destino -Force -ErrorAction Stop; return }
        catch { if ($t -eq 6) { throw }; Start-Sleep -Seconds 2 }
    }
}

function Copiar-Pasta([string]$Origem, [string]$Destino) {
    if (-not (Test-Path -LiteralPath $Destino)) { New-Item -ItemType Directory -Path $Destino -Force | Out-Null }
    $ea = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & robocopy.exe $Origem $Destino /E /IS /IT /R:3 /W:2 /NFL /NDL /NJH /NJS /NP | Out-Null
        $codigo = $LASTEXITCODE
    } finally { $ErrorActionPreference = $ea }
    if ($codigo -ge 8) { throw ('Falha ao copiar "' + $Origem + '" (robocopy, codigo ' + $codigo + ').') }
}

function Copiar-Item-Qualquer([string]$Origem, [string]$Destino) {
    if ((Get-Item -LiteralPath $Origem).PSIsContainer) { Copiar-Pasta $Origem $Destino } else { Copiar-Arquivo $Origem $Destino }
}

function Servico-Existe { return [bool](Get-Service -Name $Servico -ErrorAction SilentlyContinue) }

function Aguardar-Status([string]$Status, [int]$Seg) {
    try {
        $svc = Get-Service -Name $Servico
        $svc.WaitForStatus($Status, [TimeSpan]::FromSeconds($Seg))
        return $true
    } catch { return $false }
}

function Parar-Servico {
    $svc = Get-Service -Name $Servico
    if ($svc.Status -eq 'Stopped') { Log 'O servico ja estava parado.'; return }
    try { Stop-Service -Name $Servico -Force -ErrorAction Stop } catch { Log ('Stop-Service: ' + $_.Exception.Message) }
    if (-not (Aguardar-Status 'Stopped' 60)) { throw 'O servico nao parou em 60 segundos.' }
}

function Iniciar-Servico {
    $svc = Get-Service -Name $Servico
    if ($svc.Status -eq 'Running') { return }
    Start-Service -Name $Servico -ErrorAction Stop
    if (-not (Aguardar-Status 'Running' 60)) { throw 'O servico nao entrou em execucao em 60 segundos.' }
}

function Esperar-ArquivoLivre([string]$Arquivo, [int]$Seg) {
    for ($i = 0; $i -lt $Seg; $i++) {
        try {
            $fs = [System.IO.File]::Open($Arquivo, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
            $fs.Close()
            return $true
        } catch { Start-Sleep -Seconds 1 }
    }
    return $false
}

function Esperar-Saude([int]$Seg) {
    $limite = (Get-Date).AddSeconds($Seg)
    $parado = 0
    while ((Get-Date) -lt $limite) {
        try {
            $r = Invoke-WebRequest -Uri ('http://127.0.0.1:' + $Porta + '/api/saude') -UseBasicParsing -TimeoutSec 5
            if ($r.StatusCode -eq 200 -and $r.Content -match '"status"\s*:\s*"ok"') { return $true }
        } catch { }
        $s = Get-Service -Name $Servico -ErrorAction SilentlyContinue
        if ($s -and $s.Status -eq 'Stopped') { $parado++ } else { $parado = 0 }
        if ($parado -ge 12) { return $false }     # parado ha ~24 s seguidos: nao vai subir
        Start-Sleep -Seconds 2
    }
    return $false
}

function Fazer-Backup {
    New-Item -ItemType Directory -Path $PastaBackup -Force | Out-Null
    foreach ($item in $Itens) {
        $orig = Join-Path $Pasta $item
        if (-not (Test-Path -LiteralPath $orig)) { continue }
        $dest = Join-Path $PastaBackup $item
        $pai = Split-Path $dest -Parent
        if (-not (Test-Path -LiteralPath $pai)) { New-Item -ItemType Directory -Path $pai -Force | Out-Null }
        Copiar-Item-Qualquer $orig $dest
    }
    # o banco (criptografado) entra no ponto de restauracao; a chave (sister.key) nao muda na atualizacao e nao e copiada
    $dbDest = Join-Path $PastaBackup 'Database'
    New-Item -ItemType Directory -Path $dbDest -Force | Out-Null
    foreach ($a in $ArqsBanco) {
        $orig = Join-Path (Join-Path $Pasta 'Database') $a
        if (Test-Path -LiteralPath $orig) { Copiar-Arquivo $orig (Join-Path $dbDest $a) }
    }
    Log ('Copia de seguranca em ' + $PastaBackup)
}

function Aplicar-Staging {
    foreach ($item in $Itens) {
        $src = Join-Path $Staging $item
        if (-not (Test-Path -LiteralPath $src)) { continue }
        Copiar-Item-Qualquer $src (Join-Path $Pasta $item)
        Log ('  atualizado: ' + $item)
    }
}

function Restaurar-Backup([bool]$RestaurarBanco) {
    foreach ($item in $Itens) {
        $orig = Join-Path $PastaBackup $item
        if (-not (Test-Path -LiteralPath $orig)) { continue }
        Copiar-Item-Qualquer $orig (Join-Path $Pasta $item)
        Log ('  restaurado: ' + $item)
    }
    $bk = Join-Path $PastaBackup 'Database'
    if ($RestaurarBanco -and (Test-Path -LiteralPath (Join-Path $bk 'sister.db'))) {
        $dbDir = Join-Path $Pasta 'Database'
        foreach ($a in $ArqsBanco) { Remove-Item -LiteralPath (Join-Path $dbDir $a) -Force -ErrorAction SilentlyContinue }
        foreach ($a in $ArqsBanco) {
            $o = Join-Path $bk $a
            if (Test-Path -LiteralPath $o) { Copiar-Arquivo $o (Join-Path $dbDir $a) }
        }
        Log '  banco de dados restaurado'
    }
}

function Versao-Instalada {
    $vi = (Get-Item -LiteralPath (Join-Path $Pasta 'SisTerAPI.exe')).VersionInfo
    return ('{0}.{1}.{2}' -f $vi.FileMajorPart, $vi.FileMinorPart, $vi.FileBuildPart)
}

function Limpar-Restos {
    foreach ($a in @('pacote.json', 'pacote.zip', 'pacote.zip.partial')) {
        Remove-Item -LiteralPath (Join-Path $Base $a) -Force -ErrorAction SilentlyContinue
    }
    Remove-Item -LiteralPath $Staging -Recurse -Force -ErrorAction SilentlyContinue
    # guarda so os 3 pontos de restauracao mais recentes
    $dirs = Get-ChildItem -LiteralPath (Join-Path $Base 'backup') -Directory -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending | Select-Object -Skip 3
    foreach ($d in $dirs) { Remove-Item -LiteralPath $d.FullName -Recurse -Force -ErrorAction SilentlyContinue }
    $velhos = Get-ChildItem -LiteralPath $Base -Filter 'atualizar_*.ps1' -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending | Select-Object -Skip 3
    foreach ($v in $velhos) { Remove-Item -LiteralPath $v.FullName -Force -ErrorAction SilentlyContinue }
}

# ------------------------------------------------------------------ principal

$mutex = New-Object System.Threading.Mutex($false, 'Global\SisTerAtualizador')
if (-not $mutex.WaitOne(0)) { Write-Host 'Ja existe um atualizador rodando.'; exit 2 }

$etapa = 'preparo'
$trocou = $false
$novoIniciado = $false
$saida = 1
try {
    try {
        Log ('Atualizador iniciado. Pasta=' + $Pasta + ' Servico=' + $Servico + ' (' + $VersaoAntes + ' -> ' + $VersaoNova + ')')
        if (-not (Test-Path -LiteralPath (Join-Path $Staging 'SisTerAPI.exe'))) { throw 'Nao encontrei o pacote preparado em Atualizacao\staging.' }
        if (-not (Servico-Existe)) { throw ('O servico "' + $Servico + '" nao existe neste computador.') }

        if ($Simular) {
            Log 'MODO SIMULACAO: nada sera parado nem alterado.'
            foreach ($item in $Itens) {
                $quando = 'nao esta no pacote'
                if (Test-Path -LiteralPath (Join-Path $Staging $item)) { $quando = 'seria atualizado' }
                Log ('  ' + $item + ': ' + $quando)
            }
            Log 'Simulacao concluida.'
            $saida = 0
            return
        }

        Andamento 'aguardando' 'Aguardando a tela receber a confirmacao...'
        Start-Sleep -Seconds $EsperaInicialSeg

        $etapa = 'parar'
        Andamento 'parando' 'Parando o servico do SisTer...'
        Parar-Servico
        if (-not (Esperar-ArquivoLivre (Join-Path $Pasta 'SisTerAPI.exe') 40)) { throw 'O SisTerAPI.exe continua em uso.' }

        Andamento 'backup' 'Guardando copia dos arquivos atuais e do banco...'
        Fazer-Backup

        $etapa = 'trocar'
        Andamento 'copiando' 'Trocando os arquivos pelos da nova versao...'
        $trocou = $true
        Aplicar-Staging
        if ($VersaoNova -ne '') {
            $inst = Versao-Instalada
            if ($inst -ne $VersaoNova) { throw ('O SisTerAPI.exe instalado ficou na versao ' + $inst + ' (esperado ' + $VersaoNova + ').') }
        }

        $etapa = 'ligar'
        Andamento 'iniciando' 'Ligando o servico...'
        $novoIniciado = $true
        Iniciar-Servico

        $etapa = 'validar'
        Andamento 'conferindo' 'Conferindo se o sistema respondeu...'
        if (-not (Esperar-Saude $TempoMaxSaudeSeg)) { throw 'O sistema nao respondeu depois da atualizacao.' }

        Log 'Atualizacao concluida com sucesso.'
        Limpar-Restos
        Concluir $true $false $true '' ('Atualizado para a versao ' + $VersaoNova + '.')
        $saida = 0
    }
    catch {
        $motivo = $_.Exception.Message
        Log ('FALHA na etapa "' + $etapa + '": ' + $motivo)
        $revertido = $false
        $noAr = $false
        try {
            Andamento 'revertendo' 'Algo deu errado. Voltando a versao anterior...'
            if ($trocou) {
                try { Parar-Servico } catch { Log ('Ao parar para reverter: ' + $_.Exception.Message) }
                [void](Esperar-ArquivoLivre (Join-Path $Pasta 'SisTerAPI.exe') 40)
                Restaurar-Backup $novoIniciado
                $revertido = $true
            }
            Iniciar-Servico
            $noAr = Esperar-Saude $TempoMaxSaudeSeg
            if ($noAr) { Log 'O sistema esta no ar.' } else { Log 'ATENCAO: o sistema NAO respondeu depois de reverter.' }
        } catch {
            Log ('ERRO ao reverter: ' + $_.Exception.Message)
        }
        Limpar-Restos
        $texto = 'A atualizacao nao foi concluida (' + $motivo + ').'
        if ($revertido -and $noAr) { $texto += ' O sistema voltou para a versao anterior e esta funcionando.' }
        elseif ($noAr) { $texto += ' Nada foi alterado e o sistema esta funcionando.' }
        else { $texto += ' O sistema NAO esta respondendo: veja o log e, se preciso, restaure a copia em Atualizacao\backup\' + $Id + '.' }
        Concluir $false $revertido $noAr $etapa $texto
        $saida = 1
    }
}
finally {
    try { $mutex.ReleaseMutex() } catch { }
    $mutex.Dispose()
}
exit $saida
