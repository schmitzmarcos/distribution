<#
  Smoke test das protecoes basicas da API do SisTer (nao altera dados).
  Uso:  .\smoke_test.ps1 [-Base http://localhost:9000] [-Usuario admin -Senha '...']
  Sem -Usuario/-Senha, os testes que exigem login sao ignorados.
#>
param(
  [string]$Base = 'http://localhost:9000',
  [string]$Usuario = '',
  [string]$Senha = ''
)
Add-Type -AssemblyName System.Net.Http
$http = New-Object System.Net.Http.HttpClient
$http.Timeout = [TimeSpan]::FromSeconds(15)
$falhas = 0

# ATENCAO: $Corpo e $Token NAO podem ser tipados como [string]: o PowerShell converte $null em '' e o
# Windows PowerShell 5.1 recusaria o GET com conteudo ("nao e possivel enviar conteudo com este verbo").
function Chamar([string]$Metodo, [string]$Caminho, $Corpo = $null, $Token = $null) {
  try {
    $req = New-Object System.Net.Http.HttpRequestMessage ([System.Net.Http.HttpMethod]::new($Metodo), ($Base + $Caminho))
    if ($Token) { $req.Headers.Add('Authorization', "Bearer $Token") }
    # so POST/PUT levam corpo; sem corpo = nenhum conteudo (nem Content-Type) na requisicao
    if (($Metodo -eq 'POST' -or $Metodo -eq 'PUT') -and $null -ne $Corpo) {
      $req.Content = New-Object System.Net.Http.StringContent ([string]$Corpo, [Text.Encoding]::UTF8, 'application/json')
    }
    $resp = $http.SendAsync($req).GetAwaiter().GetResult()
    [pscustomobject]@{ Status = [int]$resp.StatusCode; Texto = $resp.Content.ReadAsStringAsync().GetAwaiter().GetResult() }
  } catch {
    # sem resposta HTTP (servidor fora do ar, porta errada, firewall...) ou erro ao montar a requisicao: Status 0
    $msg = $_.Exception.Message
    if ($_.Exception.InnerException) { $msg = $_.Exception.InnerException.Message }
    [pscustomobject]@{ Status = 0; Texto = $msg }
  }
}
function Esperar([string]$Nome, [int[]]$Aceitos, $Resp) {
  if ($Aceitos -contains $Resp.Status) { Write-Host ("[ OK ] {0} -> {1}" -f $Nome, $Resp.Status) -ForegroundColor Green }
  else { Write-Host ("[FALHA] {0} -> {1} (esperado: {2})  {3}" -f $Nome, $Resp.Status, ($Aceitos -join '/'), $Resp.Texto) -ForegroundColor Red; $script:falhas++ }
}

# Antes de tudo: o servidor responde neste endereco?
$saude = Chamar GET '/api/saude'
if ($saude.Status -eq 0) {
  Write-Host ''
  Write-Host "Nao foi possivel conectar em $Base" -ForegroundColor Red
  Write-Host "Motivo: $($saude.Texto)" -ForegroundColor Red
  Write-Host 'Confira: 1) o SisTerAPI.exe esta rodando (e NAO pausado pelo depurador do Delphi)?' -ForegroundColor Yellow
  Write-Host '         2) a porta e a do sister.ini ([Servidor] Porta=...)? Use -Base http://localhost:PORTA' -ForegroundColor Yellow
  Write-Host '         3) abra o endereco no navegador: se tambem nao abrir, o problema e o servidor, nao o script.' -ForegroundColor Yellow
  exit 2
}

Esperar 'GET /api/saude (livre)'                        @(200) $saude
Esperar 'GET /api/clientes sem token'                   @(401) (Chamar GET '/api/clientes')
Esperar 'GET /api/versao sem token'                     @(401) (Chamar GET '/api/versao')
Esperar 'GET /api/clientes com token invalido'          @(401) (Chamar GET '/api/clientes' $null 'x.y.z')
Esperar 'PUT /api/auth/trocar-senha sem token (V2)'     @(401) (Chamar PUT '/api/auth/trocar-senha' '{"senha_atual":"a","senha_nova":"b"}')
Esperar 'POST /api/auth/login sem corpo'                @(400) (Chamar POST '/api/auth/login')
Esperar 'POST /api/auth/login JSON invalido (V3)'       @(400) (Chamar POST '/api/auth/login' '{nao e json')
Esperar 'POST /api/auth/login campos vazios'            @(400) (Chamar POST '/api/auth/login' '{"login":"","senha":""}')
Esperar 'GET /../ nao sai da pasta public'              @(403,404) (Chamar GET '/..%5Csister.ini')

if ($Usuario -ne '') {
  $login = Chamar POST '/api/auth/login' (@{ login = $Usuario; senha = $Senha } | ConvertTo-Json -Compress)
  Esperar 'POST /api/auth/login valido' @(200) $login
  if ($login.Status -eq 200) {
    $tk = ($login.Texto | ConvertFrom-Json).token
    Esperar 'POST /api/clientes sem corpo -> 400, nao 500'   @(400,403) (Chamar POST '/api/clientes' $null $tk)
    Esperar 'PUT /api/faturas/0/gastos sem corpo -> 400/404' @(400,403,404) (Chamar PUT '/api/faturas/0/gastos' $null $tk)
    Esperar 'GET /api/minhas-permissoes'                     @(200,403) (Chamar GET '/api/minhas-permissoes' $null $tk)
    $ver = Chamar GET '/api/versao' $null $tk
    Esperar 'GET /api/versao (logado)'                       @(200) $ver
    if ($ver.Status -eq 200) { $vj = $ver.Texto | ConvertFrom-Json; Write-Host ("       SisTer v{0} - compilado em {1} - banco {2}" -f $vj.versao, $vj.compilado_em, $vj.banco) -ForegroundColor Cyan }
  }
}

# V4 (informativo): corpo grande com Transfer-Encoding: chunked deve ser recusado (413) se o limite funciona
if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
  $tmp = New-TemporaryFile
  [IO.File]::WriteAllText($tmp, '{"login":"' + ('a' * (5MB)) + '","senha":"x"}')
  $codigo = & curl.exe -s -o NUL -w '%{http_code}' -X POST -H 'Content-Type: application/json' -H 'Transfer-Encoding: chunked' --data-binary "@$tmp" "$Base/api/auth/login"
  Remove-Item $tmp -ErrorAction SilentlyContinue
  Write-Host ("[INFO] V4 corpo chunked de 5 MB em /api/auth/login -> {0} (413 = limite eficaz; outro valor: investigar)" -f $codigo) -ForegroundColor Yellow
}

Write-Host ''
if ($falhas -eq 0) { Write-Host 'Tudo certo.' -ForegroundColor Green } else { Write-Host "$falhas teste(s) falharam." -ForegroundColor Red; exit 1 }
