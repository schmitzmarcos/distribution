<#
 gerar_pacote.ps1 - Gera o pacote de atualizacao do SisTer (o ZIP que a tela "Atualizacao" baixa).

 Passo a passo para lancar uma versao:
   1. backend\scripts\definir_versao.ps1 -Versao 1.2.0        (ajusta Versao.pas e as propriedades do .exe)
   2. compile o SisTerAPI.dproj (Win32, Release); o SisTerAPI.exe deve ficar em backend\
   3. backend\scripts\gerar_pacote.ps1                        (este script)
   4. publique o .zip num endereco HTTPS (site da empresa, GitHub Releases, nuvem com link direto...)
   5. na tela Atualizacao do cliente: cole a URL e o SHA-256 (o script mostra e grava o .sha256 ao lado do .zip)

 Saida: backend\dist\SisTer_v<versao>.zip e SisTer_v<versao>.zip.sha256
 O pacote leva SO: SisTerAPI.exe, public, Database\migrations, servico, scripts, README.md, sister.ini.example.
 (sister.ini, banco, chave, Logs e backup NUNCA entram.)
#>
[CmdletBinding()]
param(
    [string]$Exe = '',
    [string]$Saida = ''
)
$ErrorActionPreference = 'Stop'

$backend = Split-Path -Parent $PSScriptRoot
if ($Exe -eq '') { $Exe = Join-Path $backend 'SisTerAPI.exe' }
if ($Saida -eq '') { $Saida = Join-Path $backend 'dist' }

$texto = Get-Content -Raw -LiteralPath (Join-Path $backend 'src\Common\Versao.pas')
$m = [regex]::Match($texto, "VERSAO_SISTEMA\s*=\s*'([0-9.]+)'")
if (-not $m.Success) { throw 'Nao achei VERSAO_SISTEMA em src\Common\Versao.pas.' }
$versao = $m.Groups[1].Value

if (-not (Test-Path -LiteralPath $Exe)) { throw ('Nao encontrei o executavel: ' + $Exe + ' (compile o SisTerAPI.dproj).') }
$vi = (Get-Item -LiteralPath $Exe).VersionInfo
$versaoExe = '{0}.{1}.{2}' -f $vi.FileMajorPart, $vi.FileMinorPart, $vi.FileBuildPart
if ($versaoExe -ne $versao) {
    throw ('O SisTerAPI.exe e da versao ' + $versaoExe + ', mas Versao.pas diz ' + $versao +
           '. Rode definir_versao.ps1, recompile e tente de novo.')
}

$arquivos = New-Object System.Collections.Generic.List[object]
function Adicionar([string]$Origem, [string]$NoZip) {
    $arquivos.Add([pscustomobject]@{ Origem = $Origem; NoZip = $NoZip })
}
function Adicionar-Pasta([string]$Pasta, [string]$Prefixo) {
    if (-not (Test-Path -LiteralPath $Pasta)) { return }
    $raiz = (Resolve-Path -LiteralPath $Pasta).Path.TrimEnd('\')
    Get-ChildItem -LiteralPath $raiz -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($raiz.Length + 1).Replace('\', '/')
        Adicionar $_.FullName ($Prefixo + '/' + $rel)
    }
}

Adicionar $Exe 'SisTerAPI.exe'
Adicionar-Pasta (Join-Path $backend 'public') 'public'
Adicionar-Pasta (Join-Path $backend 'Database\migrations') 'Database/migrations'
Adicionar-Pasta (Join-Path $backend 'servico') 'servico'
Adicionar-Pasta (Join-Path $backend 'scripts') 'scripts'
foreach ($n in @('README.md', 'sister.ini.example')) {
    foreach ($pasta in @($backend, (Split-Path -Parent $backend))) {
        $c = Join-Path $pasta $n
        if (Test-Path -LiteralPath $c) { Adicionar $c $n; break }
    }
}

New-Item -ItemType Directory -Path $Saida -Force | Out-Null
$zipPath = Join-Path $Saida ('SisTer_v' + $versao + '.zip')
if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($a in $arquivos) {
        [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $a.Origem, $a.NoZip, [System.IO.Compression.CompressionLevel]::Optimal)
    }
} finally { $zip.Dispose() }

$sha = (Get-FileHash -Algorithm SHA256 -LiteralPath $zipPath).Hash.ToLower()
[System.IO.File]::WriteAllText($zipPath + '.sha256', $sha + '  ' + (Split-Path -Leaf $zipPath) + "`r`n", (New-Object System.Text.UTF8Encoding($false)))

$tam = [math]::Round((Get-Item -LiteralPath $zipPath).Length / 1MB, 1)
Write-Host ''
Write-Host ('Pacote gerado: ' + $zipPath + ' (' + $tam + ' MB, ' + $arquivos.Count + ' arquivos)')
Write-Host ('SHA-256:       ' + $sha)
Write-Host ''
Write-Host 'Proximo passo: publique o .zip em um endereco HTTPS e cole a URL e o SHA-256 na tela Atualizacao.'
