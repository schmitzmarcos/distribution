<#
  Define a versao do SisTer em TODOS os lugares de uma vez:
    - src\Common\Versao.pas  (VERSAO_SISTEMA: aparece no console, no log, na API e no menu das telas)
    - SisTerAPI.dproj (versao do .exe nas Propriedades do arquivo)

  Uso (na pasta backend\scripts):   .\definir_versao.ps1 -Versao 1.2.0
  Depois: compile o SisTerAPI de novo. Sugestao: git commit + git tag v1.2.0
#>
param(
  [Parameter(Mandatory = $true)][string]$Versao
)

if ($Versao -notmatch '^(\d+)\.(\d+)\.(\d+)$') { throw "Use o formato MAIOR.MENOR.CORRECAO, ex.: 1.2.0" }
$maior = $Matches[1]; $menor = $Matches[2]; $correcao = $Matches[3]
$raiz = Split-Path -Parent $PSScriptRoot

# 1) Versao.pas (so ASCII: grava sem BOM)
$arq = Join-Path $raiz 'src\Common\Versao.pas'
$txt = [IO.File]::ReadAllText($arq)
if ($txt -notmatch "VERSAO_SISTEMA = '[^']*';") { throw "Nao achei VERSAO_SISTEMA em $arq" }
$novo = [regex]::Replace($txt, "VERSAO_SISTEMA = '[^']*';", "VERSAO_SISTEMA = '$Versao';")
[IO.File]::WriteAllText($arq, $novo, (New-Object Text.UTF8Encoding($false)))
Write-Host "OK  Versao.pas -> $Versao"

# 2) .dproj (mantem o BOM do arquivo)
foreach ($nome in 'SisTerAPI.dproj') {
  $f = Join-Path $raiz $nome
  if (-not (Test-Path $f)) { Write-Host "--  $nome nao encontrado, ignorado"; continue }
  $t = [IO.File]::ReadAllText($f)
  $t = [regex]::Replace($t, '<VerInfo_MajorVer>\d+</VerInfo_MajorVer>', "<VerInfo_MajorVer>$maior</VerInfo_MajorVer>")
  $t = [regex]::Replace($t, '<VerInfo_MinorVer>\d+</VerInfo_MinorVer>', "<VerInfo_MinorVer>$menor</VerInfo_MinorVer>")
  $t = [regex]::Replace($t, '<VerInfo_Release>\d+</VerInfo_Release>', "<VerInfo_Release>$correcao</VerInfo_Release>")
  $t = [regex]::Replace($t, 'FileVersion=[0-9.]+', "FileVersion=$Versao.0")
  $t = [regex]::Replace($t, 'ProductVersion=[0-9.]+', "ProductVersion=$Versao.0")
  [IO.File]::WriteAllText($f, $t, (New-Object Text.UTF8Encoding($true)))
  Write-Host "OK  $nome -> $Versao.0"
}
Write-Host ""
Write-Host "Pronto. Compile o SisTerAPI de novo."
