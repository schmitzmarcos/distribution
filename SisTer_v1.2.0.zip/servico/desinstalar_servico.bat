@echo off
rem Remove o servico SisTerAPI (nao apaga banco, logs nem backups). Execute como ADMINISTRADOR.
setlocal
set NOME=SisTerAPI

net session >nul 2>&1
if errorlevel 1 (
  echo Execute este arquivo como ADMINISTRADOR.
  pause
  exit /b 1
)

sc query %NOME% >nul 2>&1
if errorlevel 1 (
  echo O servico %NOME% nao esta instalado.
  pause
  exit /b 0
)

echo Parando o servico...
net stop %NOME%
echo Removendo o servico...
sc delete %NOME%
echo Pronto.
pause
