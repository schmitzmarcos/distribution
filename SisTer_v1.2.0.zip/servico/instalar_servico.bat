@echo off
rem ============================================================================
rem  Instala o SisTer como SERVICO do Windows (inicio automatico, reinicia sozinho
rem  se cair). Execute como ADMINISTRADOR (botao direito > Executar como administrador).
rem ============================================================================
setlocal
set NOME=SisTerAPI

net session >nul 2>&1
if errorlevel 1 (
  echo Execute este arquivo como ADMINISTRADOR.
  pause
  exit /b 1
)

for %%I in ("%~dp0..") do set PASTA=%%~fI
set EXE=%PASTA%\SisTerAPI.exe

if not exist "%EXE%" (
  echo Nao encontrei "%EXE%". Compile o projeto SisTerAPI.dproj e deixe o .exe na pasta backend.
  pause
  exit /b 1
)
rem (nao ha mais sqlite3.dll: o banco e criptografado com o SQLite embutido no FireDAC)
if exist "%PASTA%\sqlite3.dll" (
  echo AVISO: ha uma sqlite3.dll nesta pasta. O SisTer nao a usa mais; apague-a para evitar confusao.
)
if not exist "%PASTA%\Database\sister.key" (
  echo A chave do banco ainda nao existe. Rode SisTerAPI.exe em modo console UMA vez, depois rode
  echo "SisTerAPI.exe --exibir-chave", anote a chave de recuperacao e guarde FORA do servidor.
  pause
  exit /b 1
)
if not exist "%PASTA%\Database\sister.db" (
  echo O banco ainda nao existe. Rode SisTerAPI.exe (duplo clique abre o modo console^) UMA vez, anote a senha inicial do
  echo usuario admin que aparece na tela, feche com Ctrl+C e rode este instalador de novo.
  pause
  exit /b 1
)

sc query %NOME% >nul 2>&1
if not errorlevel 1 (
  echo O servico %NOME% ja existe. Rode desinstalar_servico.bat antes.
  pause
  exit /b 1
)

echo Instalando o servico %NOME%...
sc create %NOME% binPath= "\"%EXE%\"" start= delayed-auto DisplayName= "SisTer API"
if errorlevel 1 (
  echo Falha ao criar o servico.
  pause
  exit /b 1
)
sc description %NOME% "Servidor da API e do front-end do SisTer (Horse/Delphi)."
rem reinicia sozinho se parar com erro: 1a e 2a falha em 5 s, depois em 60 s; zera a contagem apos 1 dia
sc failure %NOME% reset= 86400 actions= restart/5000/restart/5000/restart/60000
sc failureflag %NOME% 1

rem Se o sister.ini estiver com ApenasLocalhost=0 e o Firewall do Windows bloquear a rede interna,
rem libere a porta (troque 9000 pela Porta do sister.ini):
rem   netsh advfirewall firewall add rule name="SisTer API" dir=in action=allow protocol=TCP localport=9000

echo Iniciando...
sc start %NOME%
echo.
echo Pronto. Logs: %PASTA%\Logs\servico.log e servico_console.log
echo Parar: net stop %NOME%    Iniciar: net start %NOME%
pause
