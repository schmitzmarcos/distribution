// Helpers comuns às 3 páginas de relatório (Lista de Passageiros, Etiquetas,
// Controle de Viagem). Cada página chama RelatorioBase.carregarFatura() e
// desenha o conteúdo específico dela.

const RelatorioBase = {
  idFatura() {
    return new URLSearchParams(window.location.search).get('fatura');
  },

  escaparHtml(t) {
    const d = document.createElement('div');
    d.textContent = t == null ? '' : String(t);
    return d.innerHTML;
  },

  fmtDataBR(s) {
    if (!s) return '—';
    const [a, m, d] = s.split('-');
    return `${d}/${m}/${a}`;
  },

  fmtMoeda(n) {
    return Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  },

  fmtGeradoEm() {
    return new Date().toLocaleString('pt-BR');
  },

  async carregarFatura() {
    const id = this.idFatura();
    if (!id) {
      document.body.innerHTML = '<p style="padding:40px; font-family:sans-serif;">Nenhuma viagem informada (parâmetro ?fatura= ausente na URL).</p>';
      throw new Error('sem fatura na URL');
    }
    exigirLogin();
    return Api.get('/faturas/' + id);
  },

  async carregarPassageiros() {
    const r = await Api.get(`/faturas/${this.idFatura()}/passageiros`);
    return r.dados;
  },

  async carregarGastos() {
    try { return await Api.get(`/faturas/${this.idFatura()}/gastos`); }
    catch (e) { return {}; }
  },

  preencherFicha(f) {
    document.querySelectorAll('[data-ficha]').forEach((el) => {
      const campo = el.dataset.ficha;
      let v = f[campo];
      if (campo.startsWith('data_')) v = this.fmtDataBR(v);
      el.textContent = (v == null || v === '') ? '—' : v;
    });
    const rota = [f.origem, f.destino].filter(Boolean).join(' → ');
    const elRota = document.querySelector('[data-ficha-rota]');
    if (elRota) elRota.textContent = rota || '—';
  },
};

// Botao "Imprimir / Salvar PDF" (data-imprimir). Fica aqui, e nao em onclick="" na pagina, porque a politica de
// seguranca do servidor (CSP) nao permite scripts nem handlers embutidos no HTML.
document.addEventListener('click', (ev) => {
  if (ev.target.closest('[data-imprimir]')) window.print();
});
