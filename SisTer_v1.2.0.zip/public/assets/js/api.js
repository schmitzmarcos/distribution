// Wrapper simples de fetch, ja cuidando de anexar o token JWT e tratar
// respostas 401 (sessao expirada -> volta pro login automaticamente).
//
// API_BASE relativo ('/api'): como o proprio back-end Horse agora serve
// este front-end (Horse.StaticFiles), as chamadas caem sempre no mesmo
// host/porta que serviu a pagina - nao precisa mais configurar IP nem CORS.
const API_BASE = '/api';

const Api = {
  token() {
    return localStorage.getItem('sister_token');
  },

  usuario() {
    const raw = localStorage.getItem('sister_usuario');
    return raw ? JSON.parse(raw) : null;
  },

  salvarSessao(token, usuario) {
    localStorage.removeItem('sister_permissoes');
    localStorage.setItem('sister_token', token);
    localStorage.setItem('sister_usuario', JSON.stringify(usuario));
  },

  sair() {
    localStorage.removeItem('sister_permissoes');
    localStorage.removeItem('sister_token');
    localStorage.removeItem('sister_usuario');
    window.location.href = 'login.html';
  },

  async requisitar(caminho, opcoes = {}) {
    const headers = Object.assign(
      { 'Content-Type': 'application/json' },
      opcoes.headers || {}
    );

    if (this.token()) {
      headers['Authorization'] = 'Bearer ' + this.token();
    }

    const bloqueio = Permissoes.bloqueio(opcoes.method || 'GET', caminho);
    if (bloqueio) {
      const negado = new Error(bloqueio);
      negado.status = 403;
      throw negado;
    }

    const resposta = await fetch(API_BASE + caminho, Object.assign({}, opcoes, { headers }));

    const texto = await resposta.text();
    let corpo = null;
    let naoJson = null; // texto recebido quando a resposta NAO e JSON (ex.: "Invalid JSON", pagina de erro)
    if (texto) {
      try { corpo = JSON.parse(texto); } catch (e) { naoJson = texto; }
    }
    const trechoNaoJson = () =>
      'Resposta inesperada do servidor (HTTP ' + resposta.status + '): ' +
      (String(naoJson).replace(/\s+/g, ' ').trim().slice(0, 160) || '(vazia)');

    // 401 do próprio /auth/login é "usuário ou senha errados" - não é sessão
    // expirada (nem existe sessão ainda nesse momento), então aqui some
    // normal como erro de validação, SEM acionar sair()/redirecionar
    // (antes isso recarregava a tela de login antes da mensagem aparecer).
    if (resposta.status === 401 && caminho !== '/auth/login') {
      this.sair();
      throw new Error('Sessao expirada');
    }

    // O servidor exige a troca de senha (primeiro acesso / senha resetada) e recusa todo o resto
    if (resposta.status === 403 && corpo && corpo.codigo === 'TROCAR_SENHA') {
      const u = this.usuario();
      if (u) { u.precisa_trocar_senha = true; localStorage.setItem('sister_usuario', JSON.stringify(u)); }
      if (!/trocar-senha\.html$/i.test(location.pathname)) window.location.href = 'trocar-senha.html';
    }

    if (!resposta.ok) {
      // além da mensagem, guarda status e corpo (ex.: { limite: true } no caixa) para a tela decidir o que fazer
      const erro = new Error((corpo && corpo.erro) || (naoJson !== null ? trechoNaoJson() : 'Erro inesperado (HTTP ' + resposta.status + ')'));
      erro.status = resposta.status;
      erro.corpo = corpo;
      throw erro;
    }

    if (naoJson !== null) {
      const erro = new Error(trechoNaoJson());
      erro.status = resposta.status;
      throw erro;
    }

    return corpo;
  },

  // JSON em ASCII puro: acentos viram \uXXXX. E JSON valido do mesmo jeito, e o servidor nao depende de
  // acertar o charset do corpo da requisicao.
  json(dados) {
    return JSON.stringify(dados).replace(/[\u007f-\uffff]/g, (c) => '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4));
  },

  get(caminho) { return this.requisitar(caminho, { method: 'GET' }); },
  post(caminho, dados) { return this.requisitar(caminho, { method: 'POST', body: this.json(dados) }); },
  put(caminho, dados) { return this.requisitar(caminho, { method: 'PUT', body: this.json(dados) }); },
  del(caminho) { return this.requisitar(caminho, { method: 'DELETE' }); },
};

// Protege paginas internas: se nao tiver token, volta pro login.
function exigirLogin() {
  if (!Api.token()) {
    window.location.href = 'login.html';
  }
}

// ---------------------------------------------------------------------------
// Permissoes no front-end
//
// O servidor (Horse) e quem realmente barra cada acao (ver/incluir/editar/excluir). Aqui o front
// so usa as mesmas permissoes (GET /api/minhas-permissoes) pra nao oferecer o que o usuario nao pode fazer:
//   - esconde no menu os modulos sem permissao de "ver" e, se abrirem a tela direto, mostra um aviso;
//   - esconde botoes marcados com data-perm="incluir|editar|excluir|salvar|salvar-sub";
//   - deixa o formulario somente leitura quando marcado com data-perm-form
//     ("principal" = incluir se o painel e de registro novo, senao editar; "sub" = incluir ou editar; ou uma acao);
//   - recusa no proprio Api.requisitar qualquer POST/PUT/DELETE sem permissao.
// Se o servidor nao responder /minhas-permissoes (versao antiga) e nao houver cache, nada e escondido:
// o servidor continua barrando normalmente.
// ---------------------------------------------------------------------------
const Permissoes = (function () {
  const CHAVE = 'sister_permissoes';
  const PAGINAS = {
    'clientes.html': 'clientes', 'funcionarios.html': 'funcionarios', 'frota.html': 'frota',
    'agenda.html': 'faturas', 'financeiro.html': 'caixa', 'cheques.html': 'cheques', 'usuarios.html': 'usuarios',
    'estoque.html': 'estoque', 'fornecedores.html': 'fornecedores', 'auditoria.html': 'usuarios', 'rentabilidade.html': 'caixa',
  };
  const ROTAS = [
    ['/clientes', 'clientes'], ['/funcionarios', 'funcionarios'], ['/motoristas', 'faturas'], ['/frota', 'frota'], ['/faturas', 'faturas'],
    ['/agenda', 'faturas'], ['/caixa', 'caixa'], ['/contas-caixa', 'caixa'], ['/financeiro', 'caixa'],
    ['/cheques', 'cheques'], ['/usuarios', 'usuarios'], ['/perfis', 'usuarios'],
    ['/estoque-opcoes', 'estoque'], ['/estoque', 'estoque'], ['/fornecedores', 'fornecedores'], ['/auditoria', 'usuarios'], ['/equipamentos', 'frota'], ['/rentabilidade', 'caixa'],
  ];
  const paginaAtual = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  const moduloDaPagina = PAGINAS[paginaAtual] || null;

  let mapa = null; // modulo -> { ver, incluir, editar, excluir }; null = desconhecido (nada e escondido)
  try { mapa = JSON.parse(localStorage.getItem(CHAVE) || 'null'); } catch (e) { mapa = null; }

  function pode(modulo, acao) {
    if (!mapa) return true;
    const m = mapa[modulo];
    return !!(m && m[acao]);
  }

  function moduloDaRota(caminho) {
    const p = String(caminho).split('?')[0];
    for (const [prefixo, modulo] of ROTAS) {
      if (p === prefixo || p.startsWith(prefixo + '/')) return modulo;
    }
    return null;
  }

  // Devolve o texto do bloqueio, ou '' se pode seguir.
  function bloqueio(metodo, caminho) {
    const modulo = moduloDaRota(caminho);
    if (!modulo) return '';
    metodo = String(metodo).toUpperCase();
    let acao = 'ver', texto = 'visualizar esta tela';
    if (metodo === 'POST') { acao = 'incluir'; texto = 'incluir registros nesta tela'; }
    else if (metodo === 'PUT') { acao = 'editar'; texto = 'editar registros nesta tela'; }
    else if (metodo === 'DELETE') { acao = 'excluir'; texto = 'excluir registros nesta tela'; }
    if (metodo === 'POST' && /\/(reativar|resetar-senha)$/.test(String(caminho).split('?')[0])) { acao = 'editar'; texto = 'editar registros nesta tela'; }
    return pode(modulo, acao) ? '' : 'Você não tem permissão para ' + texto + '.';
  }

  function permitido(el, regra) {
    const mod = moduloDaPagina;
    if (!mod) return true;
    const painel = el.closest('.painel-lateral');
    const novo = !!painel && painel.dataset.novo === '1';
    if (regra === 'principal' || regra === 'salvar') return pode(mod, novo ? 'incluir' : 'editar');
    if (regra === 'sub' || regra === 'salvar-sub') return pode(mod, 'incluir') || pode(mod, 'editar');
    return pode(mod, regra);
  }

  function aplicarMenu() {
    document.querySelectorAll('.barra-lateral .nav-item[href]').forEach((a) => {
      const modulo = PAGINAS[(a.getAttribute('href') || '').toLowerCase()];
      if (!modulo) return;
      // (o link Administracao continua aparecendo so para o perfil Administrador - isso e decidido em cada pagina)
      a.hidden = !pode(modulo, 'ver');
    });
  }

  function aplicarPagina() {
    if (!moduloDaPagina) return;
    const conteudo = document.querySelector('.conteudo');
    if (!conteudo) return;
    const sem = !pode(moduloDaPagina, 'ver');
    let aviso = conteudo.querySelector(':scope > .sem-acesso');
    if (sem && !aviso) {
      aviso = document.createElement('div');
      aviso.className = 'sem-acesso';
      aviso.innerHTML = '<div class="sem-acesso-icone" aria-hidden="true">🔒</div>' +
        '<h2>Acesso restrito</h2><p>Seu perfil não tem permissão para visualizar esta tela.<br>Se precisar dela, peça ao administrador do sistema.</p>' +
        '<a class="btn btn-primario" href="index.html">Voltar ao início</a>';
      conteudo.prepend(aviso);
    }
    Array.from(conteudo.children).forEach((el) => { if (el !== aviso) el.classList.toggle('sem-permissao', sem); });
    if (!sem && aviso) aviso.remove();
  }

  function aplicarElementos() {
    if (!moduloDaPagina) return;
    document.querySelectorAll('[data-perm]').forEach((el) => {
      el.classList.toggle('sem-permissao', !permitido(el, el.dataset.perm));
    });
    document.querySelectorAll('[data-perm-form]').forEach((f) => {
      const ok = permitido(f, f.dataset.permForm);
      f.querySelectorAll('input, select, textarea, button').forEach((c) => {
        if (!ok) { if (!c.disabled) { c.disabled = true; c.dataset.somenteLeitura = '1'; } }
        else if (c.dataset.somenteLeitura) { c.disabled = false; delete c.dataset.somenteLeitura; }
      });
      if (f.dataset.permForm === 'principal') {
        const nota = f.querySelector(':scope > .aviso-somente-leitura');
        if (!ok && !nota) {
          const n = document.createElement('div');
          n.className = 'aviso-somente-leitura';
          n.textContent = 'Somente leitura: seu perfil não tem permissão para alterar este registro.';
          f.prepend(n);
        } else if (ok && nota) nota.remove();
      }
    });
  }

  function aplicar() {
    if (!document.body) return;
    aplicarMenu();
    aplicarPagina();
    aplicarElementos();
  }

  async function carregar() {
    try {
      const r = await Api.requisitar('/minhas-permissoes', { method: 'GET' });
      const novo = {};
      (r.dados || []).forEach((p) => {
        novo[p.modulo] = { ver: !!p.pode_ver, incluir: !!p.pode_incluir, editar: !!p.pode_editar, excluir: !!p.pode_excluir };
      });
      mapa = novo;
      localStorage.setItem(CHAVE, JSON.stringify(novo));
    } catch (e) {
      // servidor antigo/instavel: segue com o cache (ou sem restricao no front; o servidor continua barrando)
    }
    aplicar();
  }

  // Resolve quando as permissoes frescas chegaram (ou apos 2,5 s) - o painel inicial espera por isso
  // (o Promise.resolve().then adia a chamada ate o objeto Permissoes estar inicializado: o Api.requisitar usa Permissoes.bloqueio)
  const pronto = Api.token()
    ? Promise.race([Promise.resolve().then(carregar), new Promise((res) => setTimeout(res, 2500))])
    : Promise.resolve();

  // Conteudo montado depois (tabelas, formularios de historico etc.) tambem recebe as regras
  let agendado = false;
  function observar() {
    new MutationObserver(() => {
      if (agendado) return;
      agendado = true;
      requestAnimationFrame(() => { agendado = false; aplicar(); });
    }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-novo'] });
    aplicar();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', observar);
  else observar();

  return { pode, bloqueio, aplicar, carregar, pronto };
})();

// Menu lateral responsivo: no celular a barra lateral vira uma gaveta aberta por um botao no topo.
// Fica aqui porque o api.js ja e carregado por todas as paginas; paginas sem barra lateral (login) nao sao afetadas.
(function () {
  function iniciar() {
    const barra = document.querySelector('.barra-lateral');
    if (!barra || document.querySelector('.topo-mobile')) return;
    barra.id = barra.id || 'menuLateral';

    const ativo = barra.querySelector('.nav-item.ativo');
    const topo = document.createElement('header');
    topo.className = 'topo-mobile';
    topo.innerHTML =
      '<button type="button" class="btn-menu" aria-label="Abrir menu" aria-expanded="false" aria-controls="' + barra.id + '">' +
        '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">' +
        '<path d="M4 7h16M4 12h16M4 17h16"/></svg></button>' +
      '<div class="marca-mobile">Sis<span>Ter</span></div>' +
      (ativo ? '<div class="pagina-mobile"></div>' : '');
    if (ativo) topo.querySelector('.pagina-mobile').textContent = ativo.textContent.trim();

    const fundo = document.createElement('div');
    fundo.className = 'menu-fundo';
    document.body.prepend(fundo);
    document.body.prepend(topo);

    const botao = topo.querySelector('.btn-menu');
    const aberto = () => barra.classList.contains('aberta');
    function definir(abrir) {
      barra.classList.toggle('aberta', abrir);
      fundo.classList.toggle('aberto', abrir);
      document.body.classList.toggle('menu-aberto', abrir);
      botao.setAttribute('aria-expanded', String(abrir));
      botao.setAttribute('aria-label', abrir ? 'Fechar menu' : 'Abrir menu');
      if (abrir) { const primeiro = barra.querySelector('.nav-item'); if (primeiro) primeiro.focus(); }
      else if (document.activeElement && barra.contains(document.activeElement)) botao.focus();
    }
    botao.addEventListener('click', () => definir(!aberto()));
    fundo.addEventListener('click', () => definir(false));
    barra.addEventListener('click', (ev) => { if (ev.target.closest('a, button') && !ev.target.closest('.btn-menu-usuario')) definir(false); });
    document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && aberto()) definir(false); });
    // Voltando para tela larga, garante que nada fique "preso" aberto
    window.matchMedia('(min-width: 721px)').addEventListener('change', (e) => { if (e.matches && aberto()) definir(false); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
  else iniciar();
})();

// ---------------------------------------------------------------------------
// Rodape do menu lateral: so o usuario logado + um botao de opcoes (Trocar senha, Sair e a versao do sistema).
// As paginas continuam com o mesmo HTML de antes (avatar/nome/perfil, link "Trocar senha" e #btnSair): aqui os
// itens sao movidos para um menu suspenso, entao os eventos que cada pagina ja ligou no #btnSair seguem valendo.
// GET /api/versao exige login e so e pedido na primeira vez que o menu abre.
// ---------------------------------------------------------------------------
(function () {
  const ICONE = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true">' +
    '<circle cx="12" cy="5" r=".6"/><circle cx="12" cy="12" r=".6"/><circle cx="12" cy="19" r=".6"/></svg>';

  function montar() {
    const barra = document.querySelector('.barra-lateral');
    const rodape = barra && barra.querySelector('.rodape-lateral');
    if (!rodape || rodape.classList.contains('com-menu')) return;
    const info = rodape.querySelector('.info-usuario');
    const trocar = rodape.querySelector('a[href="trocar-senha.html"]');
    const sair = rodape.querySelector('#btnSair');
    if (!info || !sair) return;   // pagina com outro desenho de rodape: nao mexe
    rodape.classList.add('com-menu');

    const botao = document.createElement('button');
    botao.type = 'button';
    botao.className = 'btn-menu-usuario';
    botao.title = 'Conta: trocar senha, sair e versão';
    botao.setAttribute('aria-label', 'Opções da conta');
    botao.setAttribute('aria-haspopup', 'menu');
    botao.setAttribute('aria-expanded', 'false');
    botao.innerHTML = ICONE;
    info.appendChild(botao);

    const menu = document.createElement('div');
    menu.className = 'menu-usuario';
    menu.setAttribute('role', 'menu');
    menu.hidden = true;
    if (trocar) {
      trocar.className = 'item-menu-usuario';
      trocar.removeAttribute('style');
      trocar.setAttribute('role', 'menuitem');
      menu.appendChild(trocar);
    }
    sair.className = 'item-menu-usuario sair';
    sair.setAttribute('role', 'menuitem');
    menu.appendChild(sair);
    const versao = document.createElement('div');
    versao.className = 'versao-sistema';
    versao.textContent = 'SisTer';
    menu.appendChild(versao);
    rodape.appendChild(menu);

    let versaoCarregada = false;
    async function carregarVersao() {
      if (versaoCarregada) return;
      versaoCarregada = true;
      try {
        const v = await Api.get('/versao');
        versao.textContent = 'SisTer v' + v.versao;
        versao.title = 'Compilado em ' + v.compilado_em + '\nBanco: ' + v.banco;
      } catch (e) { versaoCarregada = false; /* sem versao no menu nao atrapalha nada */ }
    }

    function abrir(sim) {
      menu.hidden = !sim;
      botao.setAttribute('aria-expanded', String(sim));
      if (sim) { carregarVersao(); const primeiro = menu.querySelector('.item-menu-usuario'); if (primeiro) primeiro.focus(); }
    }
    botao.addEventListener('click', () => abrir(menu.hidden));
    document.addEventListener('click', (ev) => { if (!menu.hidden && !rodape.contains(ev.target)) abrir(false); });
    document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && !menu.hidden) { abrir(false); botao.focus(); } });
    // no celular, fechar a gaveta do menu tambem fecha este menu
    new MutationObserver(() => { if (!barra.classList.contains('aberta') && window.matchMedia('(max-width: 720px)').matches) abrir(false); })
      .observe(barra, { attributes: true, attributeFilter: ['class'] });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', montar);
  else montar();
})();

// ---------------------------------------------------------------------------
// Links "Auditoria" e "Atualizacao" do menu: so aparecem para o Administrador (o servidor confere de novo em cada rota).
// ---------------------------------------------------------------------------
(function () {
  function mostrarAuditoria() {
    const u = Api.usuario();
    ['navAuditoria', 'navAtualizacao'].forEach((id) => {
      const link = document.getElementById(id);
      if (link && u && u.perfil === 'Administrador') link.style.display = '';
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mostrarAuditoria);
  else mostrarAuditoria();
})();
