// ===========================================================================
// Trilha de auditoria (somente Administrador)
// A API devolve o registro ANTES e DEPOIS de cada operacao (JSON). Aqui os dois sao comparados e
// so o que MUDOU aparece: campo, valor antigo -> valor novo.
// ===========================================================================

// ---------------------------------------------------------------- dicionarios
const ENTIDADES = {
  fatura: 'Fatura (viagem)', fatura_gastos: 'Gastos da viagem', caixa_lancamento: 'Lançamento do caixa',
  conta_caixa: 'Conta do caixa', cheque: 'Cheque', permissoes_perfil: 'Permissões do perfil',
  fornecedor: 'Fornecedor', estoque_item: 'Item de estoque', estoque_movimento: 'Movimentação de estoque',
  cliente: 'Cliente', funcionario: 'Funcionário', veiculo: 'Veículo', equipamento: 'Equipamento (cadastro)',
  funcionario_horas: 'Horas do funcionário', funcionario_bonificacoes: 'Bonificação do funcionário',
  veiculo_manutencoes: 'Manutenção do veículo', veiculo_preventivas: 'Preventiva do veículo',
  veiculo_medias: 'Média de consumo', veiculo_multas: 'Multa do veículo', veiculo_acidentes: 'Acidente do veículo',
  atualizacao: 'Atualização do sistema',
};
const ACOES = {
  criar: ['Criação', 'criar'], alterar: ['Alteração', 'alterar'], excluir: ['Exclusão', 'excluir'],
  inativar: ['Inativação', 'excluir'], salvar: ['Gravação', 'alterar'], redefinir: ['Redefinição', 'alterar'],
  inventario: ['Inventário', 'inventario'],
  configurar: ['Configuração', 'alterar'], baixar: ['Download do pacote', 'criar'],
  aplicar: ['Instalação', 'alterar'], descartar: ['Pacote descartado', 'excluir'],
};
const MODULOS = {
  clientes: 'Clientes', funcionarios: 'Funcionários', frota: 'Frota', faturas: 'Agenda de Viagens',
  caixa: 'Financeiro (Caixa)', cheques: 'Cheques', usuarios: 'Administração', salarios: 'Salários',
  estoque: 'Estoque', fornecedores: 'Fornecedores',
};
const PERMISSOES = { pode_ver: 'ver', pode_incluir: 'incluir', pode_editar: 'editar', pode_excluir: 'excluir' };
const CAMPOS = {
  url: 'Endereço (URL)', sha256: 'SHA-256', versao: 'Versão',
  salario: 'Salário', foto: 'Foto', apelido: 'Apelido', nome: 'Nome', descricao: 'Descrição', observacao: 'Observação', observacoes: 'Observações', situacao: 'Situação',
  cnpj_cpf: 'CNPJ/CPF', nome_fantasia: 'Nome fantasia', sigla: 'Sigla', inscricao_estadual: 'Inscrição estadual',
  inscricao_municipal: 'Inscrição municipal', cep: 'CEP', endereco: 'Endereço', cidade: 'Cidade', uf: 'UF',
  telefone: 'Telefone', email: 'E-mail', site: 'Site', tipo: 'Tipo', unidade: 'Unidade', categoria: 'Categoria',
  localizacao: 'Localização', referencia: 'Referência', estoque_minimo: 'Estoque mínimo', quantidade: 'Quantidade',
  valor: 'Valor', valor_unitario: 'Valor unitário', valor_total: 'Valor total', documento: 'Documento',
  data: 'Data', data_saida: 'Data de saída', data_retorno: 'Data de retorno', usuario: 'Lançado por',
  id_fornecedor: 'Fornecedor (código)', id_veiculo: 'Veículo (código)', id_item: 'Item (código)',
  id_cliente: 'Cliente (código)', id_funcionario: 'Funcionário (código)', numero: 'Número', placa: 'Placa',
  banco: 'Banco', agencia: 'Agência', conta: 'Conta', vencimento: 'Vencimento', emitente: 'Emitente',
  destino: 'Destino', origem: 'Origem', saida: 'Saída', retorno: 'Retorno',
};
// campos que mudam em toda gravacao e nao dizem nada ao leitor
const IGNORAR = new Set(['atualizado_em', 'criado_em']);

const ATIVO_INATIVO = { A: 'Ativo', I: 'Inativo' };
const ROTULO_VALOR = {
  situacao: {
    fornecedor: ATIVO_INATIVO, estoque_item: ATIVO_INATIVO, cliente: ATIVO_INATIVO, funcionario: ATIVO_INATIVO, veiculo: ATIVO_INATIVO,
  },
  tipo: {
    estoque_movimento: { E: 'Entrada', S: 'Saída', A: 'Ajuste' },
    funcionario: { A: 'Agente', E: 'Eletricista', G: 'Guia', N: 'Mecânico', M: 'Motorista', S: 'Serviços Gerais' },
  },
};

// siglas e abreviacoes dos nomes de coluna ("venc_ipva" -> "Vencimento IPVA")
const PALAVRAS = {
  venc: 'vencimento', equip: 'equipamento', lic: 'licença', inmetro: 'INMETRO', antt: 'ANTT', embratur: 'Embratur',
  ipva: 'IPVA', daer: 'DAER', metroplan: 'Metroplan', receftur: 'Receftur', cnh: 'CNH', cpf: 'CPF', cnpj: 'CNPJ',
  rg: 'RG', km: 'KM', wc: 'WC', lcd: 'LCD', cd: 'CD', dvd: 'DVD', k7: 'K7', uf: 'UF', cep: 'CEP', id: 'código',
  senac: 'SENAC', mei: 'MEI', dt: 'data', qtd: 'quantidade', nro: 'número', tel: 'telefone', fone: 'telefone',
};

// ---------------------------------------------------------------- formatacao
function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function humanizar(chave) {
  if (CAMPOS[chave]) return CAMPOS[chave];
  if (chave.startsWith('id_')) return humanizar(chave.slice(3)) + ' (código)';
  const t = chave.split('_').map((p) => PALAVRAS[p] || p).join(' ');
  return t.charAt(0).toUpperCase() + t.slice(1);
}
const brl = (n) => Number(n).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const ehNumero = (v) => (typeof v === 'number' && Number.isFinite(v)) || (typeof v === 'string' && v.trim() !== '' && /^-?\d+(\.\d+)?$/.test(v.trim()));

function formatarValor(chave, valor, entidade) {
  if (valor === null || valor === undefined || valor === '') return null; // vazio
  const v = typeof valor === 'string' ? valor.trim() : valor;
  const mapa = ROTULO_VALOR[chave] && ROTULO_VALOR[chave][entidade];
  if (mapa && mapa[v] !== undefined) return mapa[v];
  if (/^(pode_|equip_)/.test(chave)) return Number(v) === 1 || v === true ? 'Sim' : 'Não';
  if (typeof v === 'boolean') return v ? 'Sim' : 'Não';
  if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) { const [a, m, d] = v.split('-'); return `${d}/${m}/${a}`; }
  if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}/.test(v)) { const [a, m, d] = v.slice(0, 10).split('-'); return `${d}/${m}/${a} ${v.slice(11, 16)}`; }
  if (ehNumero(v) && (entidade === 'fatura_gastos' || /(^|_)(valor|preco|salario|custo)(_|$)/.test(chave))) return brl(v);
  if (ehNumero(v)) return Number(v).toLocaleString('pt-BR', { maximumFractionDigits: 3 });
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
}

// ---------------------------------------------------------------- comparacao antes x depois
function lerJson(texto) {
  if (texto == null || texto === '') return null;
  try { return JSON.parse(texto); } catch (e) { return String(texto); }
}

// Arrays de objetos com "modulo" (permissoes) viram objeto indexado pelo modulo; os demais pelo indice.
function normalizar(valor) {
  if (Array.isArray(valor)) {
    const porModulo = valor.length > 0 && valor.every((x) => x && typeof x === 'object' && 'modulo' in x);
    const saida = {};
    valor.forEach((x, i) => { saida[porModulo ? x.modulo : String(i + 1)] = x; });
    return { _lista: true, _porModulo: porModulo, itens: saida };
  }
  return valor;
}

function iguais(a, b) {
  const vazio = (x) => x === null || x === undefined || x === '';
  if (vazio(a) && vazio(b)) return true;
  if (vazio(a) || vazio(b)) return false;
  if (ehNumero(a) && ehNumero(b)) return Number(a) === Number(b);
  return String(a).trim() === String(b).trim();
}

/**
 * Compara os dois instantaneos e devolve { modo, linhas }.
 *   modo 'mudou'   : so os campos que mudaram   -> linhas { campo, de, para }
 *   modo 'novo'    : registro criado            -> linhas { campo, para }   (so campos preenchidos)
 *   modo 'removido': registro excluido          -> linhas { campo, de }     (so campos preenchidos)
 * Chaves que existem so no "antes" nao contam como remocao (o "depois" de algumas operacoes e parcial).
 */
function compararVersoes(antesTxt, depoisTxt, entidade) {
  const antes = normalizar(lerJson(antesTxt));
  const depois = normalizar(lerJson(depoisTxt));
  const linhas = [];

  const rotuloCampo = (chave, pai) => {
    if (pai && PERMISSOES[chave]) return `${MODULOS[pai] || humanizar(pai)} · pode ${PERMISSOES[chave]}`;
    return pai ? `${humanizar(pai)} · ${humanizar(chave)}` : humanizar(chave);
  };

  // transforma em lista de [rotulo, chaveOriginal, valor]
  const achatar = (obj) => {
    const saida = [];
    if (obj === null || obj === undefined) return saida;
    if (typeof obj !== 'object') { saida.push(['Valor', 'valor', obj]); return saida; }
    const raiz = obj._lista ? obj.itens : obj;
    Object.keys(raiz).forEach((k) => {
      const v = raiz[k];
      if (v && typeof v === 'object' && !Array.isArray(v)) {
        Object.keys(v).forEach((k2) => { if (!IGNORAR.has(k2) && k2 !== 'modulo') saida.push([rotuloCampo(k2, obj._lista && !obj._porModulo ? `Item ${k}` : k), k2, v[k2], `${k}.${k2}`]); });
      } else if (!IGNORAR.has(k)) {
        saida.push([rotuloCampo(k), k, v, k]);
      }
    });
    return saida;
  };

  const a = achatar(antes), d = achatar(depois);
  const mapaA = new Map(a.map((x) => [x[3] || x[1], x]));
  const mapaD = new Map(d.map((x) => [x[3] || x[1], x]));

  if (!antes && depois) {
    d.forEach(([rot, chave, val]) => { const f = formatarValor(chave, val, entidade); if (f !== null) linhas.push({ campo: rot, para: f }); });
    return { modo: 'novo', linhas };
  }
  if (antes && !depois) {
    a.forEach(([rot, chave, val]) => { const f = formatarValor(chave, val, entidade); if (f !== null) linhas.push({ campo: rot, de: f }); });
    return { modo: 'removido', linhas };
  }
  mapaD.forEach(([rot, chave, valNovo], id) => {
    const ant = mapaA.get(id);
    const valAntigo = ant ? ant[2] : undefined;
    if (iguais(valAntigo, valNovo)) return;
    linhas.push({ campo: rot, de: formatarValor(chave, valAntigo, entidade), para: formatarValor(chave, valNovo, entidade) });
  });
  return { modo: 'mudou', linhas };
}

if (typeof module !== 'undefined') module.exports = { compararVersoes, formatarValor, humanizar };

// ===========================================================================
// TELA (so no navegador)
// ===========================================================================
if (typeof window !== 'undefined') (function () {
  exigirLogin();
  const $ = (id) => document.getElementById(id);

  const usuario = Api.usuario();
  if (usuario) {
    $('nomeUsuario').textContent = usuario.nome;
    $('perfilUsuario').textContent = usuario.perfil;
    $('avatarUsuario').textContent = usuario.nome.charAt(0).toUpperCase();
  }
  $('btnSair').addEventListener('click', () => Api.sair());

  const rotuloEntidade = (e) => ENTIDADES[e] || humanizar(e);
  const rotuloAcao = (a) => (ACOES[a] ? ACOES[a][0] : humanizar(a));
  const classeAcao = (a) => (ACOES[a] ? ACOES[a][1] : 'alterar');

  const params = new URLSearchParams(location.search);
  const filtros = {
    entidade: params.get('entidade') || '', acao: '', usuario: '', id_registro: params.get('id') || '',
    busca: '', de: '', ate: '', limite: '100',
  };
  let eventos = [];
  let temMais = false;
  let abrirTudo = false;
  let carregando = false;
  let temporizador = null;

  // ---------------------------------------------------------------- carga
  async function carregar(reiniciar) {
    if (carregando) return;
    carregando = true;
    if (reiniciar) { eventos = []; $('listaEventos').innerHTML = '<div class="esqueleto"></div><div class="esqueleto"></div><div class="esqueleto"></div>'; }
    try {
      const q = new URLSearchParams();
      Object.entries(filtros).forEach(([k, v]) => { if (v) q.set(k, v); });
      if (!eventos.length && !$('fEntidade').dataset.pronto) q.set('opcoes', '1');
      if (!reiniciar && eventos.length) q.set('antes_id', eventos[eventos.length - 1].id);
      const r = await Api.get('/auditoria?' + q.toString());
      if (r.entidades) preencherOpcoes(r);
      eventos = eventos.concat(r.dados || []);
      temMais = !!r.tem_mais;
      renderizar();
    } catch (e) {
      $('listaEventos').innerHTML = e.status === 403
        ? '<div class="estado"><div class="estado-icone">🔒</div><h3>Área restrita</h3><p>A trilha de auditoria só pode ser consultada por administradores.</p></div>'
        : `<div class="estado"><div class="estado-icone">⚠</div><h3>Não foi possível carregar</h3><p>${escaparHtml(e.message)}</p></div>`;
      $('resumo').innerHTML = '';
      exibir($('btnMais'), false);
    } finally { carregando = false; }
  }
  const exibir = (el, v) => { el.style.display = v ? '' : 'none'; };

  function preencherOpcoes(r) {
    const opt = (v, t, sel) => `<option value="${escaparHtml(v)}"${sel ? ' selected' : ''}>${escaparHtml(t)}</option>`;
    $('fEntidade').innerHTML = opt('', 'Tudo', !filtros.entidade) + r.entidades.map((e) => opt(e, rotuloEntidade(e), e === filtros.entidade)).join('');
    $('fAcao').innerHTML = opt('', 'Todas', !filtros.acao) + r.acoes.map((a) => opt(a, rotuloAcao(a), a === filtros.acao)).join('');
    $('fUsuario').innerHTML = opt('', 'Todos', !filtros.usuario) + r.usuarios.map((u) => opt(u, u, u === filtros.usuario)).join('');
    $('fEntidade').dataset.pronto = '1';
  }

  // ---------------------------------------------------------------- desenho
  function corDoUsuario(nome) {
    let h = 0;
    for (let i = 0; i < nome.length; i++) h = (h * 31 + nome.charCodeAt(i)) % 360;
    return h;
  }
  function partesData(quando) {
    const [d, h] = String(quando).split(' ');
    return { dia: d, hora: (h || '').slice(0, 5) };
  }
  function tituloDoDia(dia) {
    const hoje = new Date(); const fmt = (dt) => `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
    const ontem = new Date(hoje.getTime() - 86400000);
    const [a, m, d] = dia.split('-').map(Number);
    const longo = new Date(a, m - 1, d).toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    if (dia === fmt(hoje)) return { rotulo: 'Hoje', sub: longo };
    if (dia === fmt(ontem)) return { rotulo: 'Ontem', sub: longo };
    return { rotulo: longo.charAt(0).toUpperCase() + longo.slice(1), sub: '' };
  }

  const valorHtml = (v) => (v === null || v === undefined ? '<span class="vazio">vazio</span>' : escaparHtml(v.length > 220 ? v.slice(0, 220) + '…' : v));

  function diffHtml(ev) {
    const dif = compararVersoes(ev.antes, ev.depois, ev.entidade);
    const n = dif.linhas.length;
    if (dif.modo === 'mudou') {
      if (!n) return '<div class="ev-nada">Gravado sem alterar nenhum campo.</div>';
      const corpo = dif.linhas.map((l) =>
        `<div class="dif-linha"><div class="dif-campo">${escaparHtml(l.campo)}</div>` +
        `<div class="dif-valores"><span class="de">${valorHtml(l.de)}</span><span class="seta">→</span><span class="para">${valorHtml(l.para)}</span></div></div>`).join('');
      if (n > 8) return `<details class="dif-det"${abrirTudo ? ' open' : ''}><summary>${n} campos alterados</summary><div class="dif">${corpo}</div></details>`;
      return `<div class="dif">${corpo}</div>`;
    }
    if (!n) return '<div class="ev-nada">Sem valores preenchidos.</div>';
    const novo = dif.modo === 'novo';
    const corpo = dif.linhas.map((l) =>
      `<div class="dif-linha"><div class="dif-campo">${escaparHtml(l.campo)}</div>` +
      `<div class="dif-valores"><span class="${novo ? 'para' : 'de'}">${valorHtml(novo ? l.para : l.de)}</span></div></div>`).join('');
    return `<details class="dif-det ${novo ? 'det-novo' : 'det-removido'}"${abrirTudo ? ' open' : ''}><summary>${novo ? 'Valores iniciais' : 'Valores que foram removidos'} · ${n} ${n === 1 ? 'campo' : 'campos'}</summary><div class="dif">${corpo}</div></details>`;
  }

  function eventoHtml(ev) {
    const { hora } = partesData(ev.quando);
    const quem = ev.usuario || '?';
    const cls = classeAcao(ev.acao);
    return `<article class="ev ev-${cls}">
      <span class="ev-ponto"></span>
      <div class="ev-cartao">
        <header class="ev-cab">
          <time>${escaparHtml(hora)}</time>
          <span class="chip chip-${cls}">${escaparHtml(rotuloAcao(ev.acao))}</span>
          <span class="ev-titulo">${escaparHtml(rotuloEntidade(ev.entidade))}${ev.registro ? ` <span class="ev-registro">${escaparHtml(ev.registro)}</span>` : ''}${ev.id_registro ? ` <em title="Código (Cód.) mostrado no cadastro">#${ev.id_registro}</em>` : ''}</span>
          <span class="ev-quem" title="${ev.ip ? 'IP ' + escaparHtml(ev.ip) : ''}"><span class="avatar" style="--h:${corDoUsuario(quem)}">${escaparHtml(quem.charAt(0).toUpperCase())}</span>${escaparHtml(quem)}</span>
        </header>
        ${diffHtml(ev)}
      </div>
    </article>`;
  }

  function renderizar() {
    // resumo do que esta carregado
    const pessoas = new Set(eventos.map((e) => e.usuario)).size;
    const cont = (a) => eventos.filter((e) => classeAcao(e.acao) === a).length;
    $('resumo').innerHTML = [
      ['Eventos', eventos.length + (temMais ? '+' : ''), ''], ['Pessoas', pessoas, ''],
      ['Criações', cont('criar'), 'ok'], ['Alterações', cont('alterar'), ''], ['Exclusões', cont('excluir'), cont('excluir') ? 'perigo' : ''],
    ].map(([r, v, t]) => `<div class="res ${t}"><span>${r}</span><strong>${v}</strong></div>`).join('');

    $('listaEventos').classList.toggle('linha', eventos.length > 0);
    if (!eventos.length) {
      $('listaEventos').innerHTML = '<div class="estado"><div class="estado-icone">🗂</div><h3>Nenhum registro encontrado</h3><p>Ajuste ou limpe os filtros para ver mais eventos.</p></div>';
      exibir($('btnMais'), false);
      return;
    }
    let html = '', diaAtual = '';
    eventos.forEach((ev) => {
      const { dia } = partesData(ev.quando);
      if (dia !== diaAtual) {
        if (diaAtual) html += '</section>';
        const t = tituloDoDia(dia);
        html += `<section class="dia"><h2 class="dia-titulo"><span>${escaparHtml(t.rotulo)}</span>${t.sub ? `<small>${escaparHtml(t.sub)}</small>` : ''}</h2>`;
        diaAtual = dia;
      }
      html += eventoHtml(ev);
    });
    html += '</section>';
    $('listaEventos').innerHTML = html;
    exibir($('btnMais'), temMais);
    exibir($('btnLimpar'), !!(filtros.entidade || filtros.acao || filtros.usuario || filtros.id_registro || filtros.busca || filtros.de || filtros.ate));
  }

  // ---------------------------------------------------------------- filtros
  function aplicar() { clearTimeout(temporizador); temporizador = setTimeout(() => carregar(true), 250); }
  const ligar = (id, chave) => $(id).addEventListener('change', (ev) => { filtros[chave] = ev.target.value.trim(); aplicar(); });
  ligar('fEntidade', 'entidade'); ligar('fAcao', 'acao'); ligar('fUsuario', 'usuario'); ligar('fDe', 'de'); ligar('fAte', 'ate'); ligar('fLimite', 'limite');
  $('fRegistro').addEventListener('input', (ev) => { filtros.id_registro = ev.target.value.replace(/\D/g, ''); aplicar(); });
  $('fRegistro').value = filtros.id_registro;
  $('fBusca').addEventListener('input', (ev) => { filtros.busca = ev.target.value.trim(); aplicar(); });
  $('btnLimpar').addEventListener('click', () => {
    Object.assign(filtros, { entidade: '', acao: '', usuario: '', id_registro: '', busca: '', de: '', ate: '' });
    ['fEntidade', 'fAcao', 'fUsuario', 'fRegistro', 'fBusca', 'fDe', 'fAte'].forEach((id) => { $(id).value = ''; });
    carregar(true);
  });
  $('btnMais').addEventListener('click', () => carregar(false));
  $('btnExpandir').addEventListener('click', () => {
    abrirTudo = !abrirTudo;
    document.querySelectorAll('.dif-det').forEach((d) => { d.open = abrirTudo; });
    $('btnExpandir').textContent = abrirTudo ? 'Recolher detalhes' : 'Expandir detalhes';
  });

  carregar(true);
})();
