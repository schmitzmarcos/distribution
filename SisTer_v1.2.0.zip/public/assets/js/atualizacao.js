// Tela "Atualização do sistema" (só o Administrador). Fala com /api/atualizacao (ver AtualizacaoController.pas).
// Fluxo: salvar a origem -> baixar (o servidor baixa, confere e prepara, com o sistema no ar) -> instalar
// (o servidor entrega a um atualizador separado, que para o serviço, troca os arquivos, liga e confere).
// Enquanto o serviço reinicia a API some: a tela continua perguntando até o servidor voltar e entrega o resultado.
exigirLogin();

const $ = (id) => document.getElementById(id);

const usuarioLogado = Api.usuario();
if (usuarioLogado) {
  $('nomeUsuario').textContent = usuarioLogado.nome;
  $('perfilUsuario').textContent = usuarioLogado.perfil;
  $('avatarUsuario').textContent = usuarioLogado.nome.charAt(0).toUpperCase();
  if (usuarioLogado.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML;
}
let toastTimer = null;
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('visivel'), 4200);
}

// ---------------------------------------------------------------- funções puras
const fmtBytes = (n) => {
  n = Number(n) || 0;
  if (n >= 1048576) return (n / 1048576).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' MB';
  return Math.max(0, Math.round(n / 1024)).toLocaleString('pt-BR') + ' KB';
};
const fmtTempo = (seg) => `${Math.floor(seg / 60)}:${String(Math.floor(seg % 60)).padStart(2, '0')}`;

function parteVersao(v) {
  const s = String(v || '').trim().replace(/^v/i, '');
  const p = s.split('.').map((x) => parseInt(x, 10));
  if (p.length < 2 || p.some((x) => Number.isNaN(x))) return [0, 0, 0, 0];
  while (p.length < 4) p.push(0);
  return p.slice(0, 4);
}
// -1 se a < b, 0 se iguais, 1 se a > b
function compararVersoes(a, b) {
  const x = parteVersao(a), y = parteVersao(b);
  for (let i = 0; i < 4; i++) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
  return 0;
}

const FASES_PREPARO = ['baixando', 'verificando', 'preparando'];
const FASES_FIM = ['concluido', 'revertido', 'falhou'];
const ETAPA_PARADA = { parar: 3, trocar: 4, ligar: 5, validar: 6 };
const PARADA_DA_FASE = { aguardando: 3, parando: 3, backup: 3, copiando: 4, iniciando: 5, conferindo: 6, revertendo: 4 };

// O servidor está instalando agora? (o estado em memória some quando o serviço reinicia; o aplicacao.json não)
function emInstalacao(p) {
  if (!p) return false;
  if (p.estado && p.estado.fase === 'aplicando') return true;
  return !!(p.aplicacao && !FASES_FIM.includes(p.aplicacao.fase) && !p.resultado);
}

// Onde o ônibus está na rota de 7 paradas e como cada parada deve aparecer.
function calcularRota(p, ultimaAtiva) {
  const e = (p && p.estado) || {};
  const a = p && p.aplicacao;
  const r = p && p.resultado;
  const rota = { feitas: 0, ativa: -1, erro: -1, proxima: -1, revertida: false, bus: 0, andando: false, texto: '' };

  if (r) {
    if (r.ok) {
      rota.feitas = 7; rota.bus = 6;
      rota.texto = 'Chegamos! Atualização concluída.';
    } else {
      const i = ETAPA_PARADA[r.etapa] != null ? ETAPA_PARADA[r.etapa] : 3;
      rota.feitas = i; rota.erro = i; rota.bus = i; rota.revertida = !!r.revertido;
      rota.texto = r.revertido ? 'A viagem foi interrompida e voltamos à versão anterior.' : 'A viagem foi interrompida.';
    }
    return rota;
  }
  if (emInstalacao(p)) {
    const fase = a ? a.fase : 'aguardando';
    const i = PARADA_DA_FASE[fase] != null ? PARADA_DA_FASE[fase] : 3;
    rota.feitas = i; rota.ativa = i; rota.bus = i; rota.andando = true; rota.revertida = fase === 'revertendo';
    return rota;
  }
  switch (e.fase) {
    case 'baixando':
      rota.ativa = 0; rota.bus = 0; rota.andando = true;
      rota.texto = 'Baixando o pacote… ' + fmtBytes(e.baixado) + (e.total > 0 ? ' de ' + fmtBytes(e.total) : '');
      break;
    case 'verificando':
      rota.feitas = 1; rota.ativa = 1; rota.bus = 1; rota.andando = true;
      rota.texto = 'Conferindo a integridade do pacote (SHA-256)…';
      break;
    case 'preparando':
      rota.feitas = 2; rota.ativa = 2; rota.bus = 2; rota.andando = true;
      rota.texto = 'Separando os arquivos do pacote…';
      break;
    case 'pronta':
      rota.feitas = 3; rota.proxima = 3; rota.bus = 3;
      rota.texto = 'Pacote v' + e.versao_pacote + ' pronto. O ônibus espera o sinal verde para partir.';
      break;
    case 'erro': {
      const i = ultimaAtiva >= 0 ? ultimaAtiva : 0;
      rota.feitas = i; rota.erro = i; rota.bus = i;
      rota.texto = 'A viagem parou antes da instalação: nada foi alterado no sistema.';
      break;
    }
    default:
      rota.texto = 'Tudo parado por aqui. Salve a origem e baixe o pacote para começar a rota.';
  }
  return rota;
}

function resumoGeral(p) {
  const e = (p && p.estado) || {};
  if (p && p.resultado) return p.resultado.ok ? { classe: '', texto: 'Atualizado com sucesso' } : { classe: 'erro', texto: 'Instalação não concluída' };
  if (emInstalacao(p)) return { classe: 'ocupada', texto: 'Instalando a atualização…' };
  if (FASES_PREPARO.includes(e.fase)) return { classe: 'ocupada', texto: 'Preparando o pacote…' };
  if (e.fase === 'pronta') return { classe: 'pronta', texto: 'Pacote v' + e.versao_pacote + ' pronto para instalar' };
  if (e.fase === 'erro') return { classe: 'erro', texto: 'Falha ao preparar o pacote' };
  return { classe: '', texto: 'Nenhum pacote baixado' };
}

// ---------------------------------------------------------------- rota (DOM persistente, para o ônibus andar de verdade)
const BUS_SVG = '<svg viewBox="0 0 46 30" aria-hidden="true"><rect x="1" y="3" width="44" height="21" rx="5" fill="#C98A2B"/><rect x="1" y="3" width="44" height="5" rx="3" fill="#E2B060"/>' +
  '<rect x="5" y="9" width="8" height="7" rx="1.5" fill="#EAF6F1"/><rect x="15" y="9" width="8" height="7" rx="1.5" fill="#EAF6F1"/><rect x="25" y="9" width="8" height="7" rx="1.5" fill="#EAF6F1"/>' +
  '<rect x="35" y="9" width="8" height="10" rx="1.5" fill="#CFE8DE"/><rect x="1" y="19" width="44" height="2" fill="#A86F1C"/>' +
  '<circle cx="11" cy="25" r="4.2" fill="#0F1B16"/><circle cx="11" cy="25" r="1.8" fill="#9AA6A0"/><circle cx="35" cy="25" r="4.2" fill="#0F1B16"/><circle cx="35" cy="25" r="1.8" fill="#9AA6A0"/></svg>';
const CHECK_SVG = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8.5l3.2 3.2L13 4.8"/></svg>';
const X_SVG = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>';
const PARADAS = ['Baixar', 'Conferir', 'Preparar', 'Parar', 'Trocar', 'Ligar', 'Validar'];

function montarRota(el) {
  el.innerHTML = '<div class="rota"><div class="rota-trilho"></div><div class="rota-fill"></div><div class="onibus">' + BUS_SVG + '</div><div class="paradas">' +
    PARADAS.map((n, i) => `<div class="parada"><div class="no" data-simbolo="n">${i + 1}</div><div class="nome-parada">${n}</div></div>`).join('') +
    '</div></div>';
}
function atualizarRota(el, r) {
  const rota = el.firstElementChild;
  if (!rota) return;
  rota.style.setProperty('--pos', r.bus);
  rota.classList.toggle('andando', !!r.andando);
  rota.classList.toggle('com-erro', r.erro >= 0 && !r.revertida);
  rota.classList.toggle('reverte', !!r.revertida);
  rota.querySelectorAll('.parada').forEach((p, i) => {
    const erro = i === r.erro;
    const feita = i < r.feitas && !erro;
    p.classList.toggle('feita', feita);
    p.classList.toggle('ativa', i === r.ativa && !erro);
    p.classList.toggle('proxima', i === r.proxima);
    p.classList.toggle('erro', erro && !r.revertida);
    p.classList.toggle('reverte', erro && r.revertida);
    const no = p.querySelector('.no');
    const simbolo = erro ? 'x' : feita ? 'v' : 'n';
    if (no.dataset.simbolo !== simbolo) {
      no.dataset.simbolo = simbolo;
      no.innerHTML = erro ? X_SVG : feita ? CHECK_SVG : String(i + 1);
    }
  });
}

// ---------------------------------------------------------------- estado da tela
let painel = null;
let timer = null;
let sujo = false;               // campos da origem editados e ainda não salvos
let ultimaAtiva = -1;           // última parada ativa antes de um erro de preparo (para marcar onde falhou)
let servidorFora = false;
let confirmaIgual = false;
let amostras = [];              // [{t, b}] para velocidade e tempo restante do download
let chaveBloco = '';
let versaoMostrada = null;
let inicioInstalacao = 0;       // ms (relógio deste navegador)
let chaveFim = '';
const FLAG = 'sister_atualizando';

function ocupado(p) {
  return !!p && (FASES_PREPARO.includes(p.estado.fase) || emInstalacao(p));
}
function overlayDeveAparecer(p) {
  return !!((p && (emInstalacao(p) || p.resultado)) || (sessionStorage.getItem(FLAG) && servidorFora));
}

// ---------------------------------------------------------------- odômetro, resumo e origem
function renderOdometro(versao) {
  const mudou = versaoMostrada !== null && versaoMostrada !== versao;
  if (versaoMostrada === versao) return;
  versaoMostrada = versao;
  const partes = ['<span class="odo-v">v</span>'];
  String(versao || '').split('').forEach((ch) => {
    partes.push(ch === '.' ? '<span class="odo-sep">·</span>' : `<span class="odo-dig${mudou ? ' rolando' : ''}"><span>${escaparHtml(ch)}</span></span>`);
  });
  $('odometro').innerHTML = partes.join('');
  $('odometro').setAttribute('aria-label', 'Versão ' + versao);
}

function validarCampos() {
  const url = $('campoUrl').value.trim();
  const sha = $('campoSha').value.replace(/\s+/g, '');
  let urlOk = true, shaOk = true;
  const dUrl = $('dicaUrl'), dSha = $('dicaSha');
  dUrl.className = 'dica nota'; dSha.className = 'dica nota';
  if (url === '') {
    dUrl.textContent = 'Só endereços https:// são aceitos.';
  } else if (/^http:\/\//i.test(url)) {
    urlOk = false; dUrl.className = 'dica erro'; dUrl.textContent = 'http:// não é aceito: o pacote viajaria sem proteção. Use https://.';
  } else if (!/^https:\/\/[^\s/?#@]+/i.test(url) || /\s/.test(url)) {
    urlOk = false; dUrl.className = 'dica erro'; dUrl.textContent = 'Endereço inválido. Exemplo: https://exemplo.com.br/SisTer_v1.2.0.zip';
  } else if (/^https:\/\/[^/?#]*@/i.test(url)) {
    urlOk = false; dUrl.className = 'dica erro'; dUrl.textContent = 'A URL não pode ter usuário e senha.';
  } else {
    dUrl.textContent = 'Endereço direto para o arquivo .zip.';
  }
  if (sha === '') {
    dSha.className = 'dica nota aviso'; dSha.textContent = 'Sem o SHA-256 a integridade do arquivo não será conferida.';
  } else if (!/^[0-9a-f]{64}$/i.test(sha)) {
    shaOk = false; dSha.className = 'dica erro'; dSha.textContent = 'O SHA-256 tem 64 caracteres (0-9 e a-f). Confira se copiou inteiro.';
  } else {
    dSha.textContent = 'Com o SHA-256, o SisTer recusa um arquivo adulterado ou trocado.';
  }
  return { url, sha: sha.toLowerCase(), valido: urlOk && shaOk };
}

function renderOrigem(p) {
  if (!sujo && document.activeElement !== $('campoUrl') && document.activeElement !== $('campoSha')) {
    $('campoUrl').value = p.url || '';
    $('campoSha').value = p.sha256_esperado || '';
  }
  const v = validarCampos();
  const bloqueado = ocupado(p);
  $('campoUrl').disabled = bloqueado;
  $('campoSha').disabled = bloqueado;
  $('btnSalvar').disabled = bloqueado || !sujo || !v.valido;
  $('btnBaixar').disabled = bloqueado || v.url === '' || !v.valido;
  $('btnBaixar').textContent = p.estado.fase === 'pronta' ? 'Baixar de novo' : 'Baixar pacote';
}

// ---------------------------------------------------------------- bloco do pacote (muda conforme a fase)
const CAIXA_SVG = '<svg viewBox="0 0 84 84" fill="none" stroke="#9AA6A0" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" aria-hidden="true"><path d="M14 30l28-14 28 14v30L42 74 14 60z" fill="#F4F6F2"/><path d="M14 30l28 14 28-14M42 44v30"/><path d="M28 23l28 14" stroke-dasharray="3 4"/></svg>';

function htmlPronto(p) {
  const e = p.estado;
  const cmp = compararVersoes(e.versao_pacote, p.versao_atual);
  const classeNova = cmp === 0 ? 'ver nova igual' : 'ver nova';
  const fichas = [];
  fichas.push(`<span class="ficha">${e.arquivos} arquivos</span>`);
  fichas.push(`<span class="ficha">${fmtBytes(e.tamanho)}</span>`);
  if (e.sha256_confere === true) fichas.push('<span class="ficha ok">SHA-256 conferido</span>');
  else fichas.push('<span class="ficha atencao">SHA-256 não informado: integridade não conferida</span>');
  if (e.sha256) fichas.push(`<span class="ficha mono" title="${escaparHtml(e.sha256)}">${escaparHtml(e.sha256.slice(0, 10))}…${escaparHtml(e.sha256.slice(-6))} <button type="button" data-copiar="${escaparHtml(e.sha256)}">copiar</button></span>`);
  if (e.ignorados > 0) fichas.push(`<span class="ficha" title="Arquivos do pacote fora da lista permitida (ex.: sister.ini, banco, logs) nunca são copiados.">${e.ignorados} ignorados por segurança</span>`);

  let avisos = '';
  if (!p.modo_servico) {
    avisos += '<div class="caixa-aviso"><b>O SisTer está em modo console.</b> A instalação automática precisa dele rodando como serviço do Windows (<span class="mono">servico\\instalar_servico.bat</span>). O pacote já está pronto, mas aqui não dá para instalar.</div>';
  }
  if (cmp === 0) avisos += '<div class="caixa-aviso">O pacote é da <b>mesma versão</b> que está instalada (v' + escaparHtml(p.versao_atual) + ').</div>';
  if (cmp < 0) avisos += '<div class="caixa-aviso">Atenção: o pacote é de uma versão <b>mais antiga</b> (v' + escaparHtml(e.versao_pacote) + ') que a instalada. Voltar versão pode exigir banco compatível.</div>';
  const confirma = cmp <= 0
    ? `<label class="confirma-igual"><input type="checkbox" id="chkIgual" ${confirmaIgual ? 'checked' : ''}> <span>Entendo e quero instalar mesmo assim.</span></label>`
    : '';

  return `
    <h3>Pacote pronto</h3>
    <p class="nota lead">Baixado e conferido. <b>Nada foi alterado ainda</b>: o sistema segue funcionando normalmente.</p>
    <div class="transicao">
      <div class="ver"><div class="num">v${escaparHtml(p.versao_atual)}</div><small>INSTALADA</small></div>
      <svg class="seta-viagem" viewBox="0 0 64 24" fill="none" stroke="#C98A2B" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12H52"/><path d="M45 4l12 8-12 8" style="stroke-dasharray:none;animation:none"/></svg>
      <div class="${classeNova}"><div class="num">v${escaparHtml(e.versao_pacote)}</div><small>NOVO PACOTE</small></div>
    </div>
    <div class="fichas">${fichas.join('')}</div>
    ${avisos}
    <ol class="vai-acontecer">
      <li>O sistema <b>fica fora do ar por cerca de 1 minuto</b>; quem estiver usando verá a tela cair e voltar.</li>
      <li>Guardamos uma cópia dos arquivos atuais <b>e do banco de dados</b>.</li>
      <li>Trocamos o programa e as telas. <b>Dados, usuários e configurações não são tocados.</b></li>
      <li>Ligamos de novo e conferimos que respondeu. Se não responder, <b>voltamos sozinhos à versão anterior</b>.</li>
    </ol>
    ${confirma}
    <div class="acoes">
      <button class="btn btn-instalar btn-grande" type="button" id="btnInstalar">Instalar atualização</button>
      <button class="btn btn-secundario" type="button" id="btnDescartar">Descartar pacote</button>
    </div>`;
}

function renderBloco(p) {
  const e = p.estado;
  const bloco = $('blocoPacote');
  let chave = e.fase;
  if (e.fase === 'pronta') chave += '|' + e.versao_pacote + '|' + e.sha256 + '|' + p.versao_atual + '|' + p.modo_servico + '|' + confirmaIgual;
  if (e.fase === 'erro') chave += '|' + e.erro;
  if (emInstalacao(p) || p.resultado) chave = 'instalando';

  if (chave !== chaveBloco) {
    chaveBloco = chave;
    if (chave === 'instalando') {
      bloco.innerHTML = '<h3>Instalação em andamento</h3><p class="nota lead">Acompanhe pela tela cheia. Se ela foi fechada, atualize esta página.</p>';
    } else if (FASES_PREPARO.includes(e.fase)) {
      bloco.innerHTML = `<h3 id="pgTitulo">Baixando o pacote</h3><p class="nota lead" id="pgSub"></p>
        <div class="barra" id="pgBarra"><i></i></div>
        <div class="stats"><span><b id="pgPct">0%</b></span><span id="pgBytes"></span><span id="pgVel"></span><span id="pgEta"></span></div>
        <div class="acoes" style="margin-top:14px;"><button class="btn btn-secundario" type="button" id="btnCancelar">Cancelar</button></div>`;
    } else if (e.fase === 'pronta') {
      bloco.innerHTML = htmlPronto(p);
      const instalar = $('btnInstalar');
      const precisaConfirmar = compararVersoes(e.versao_pacote, p.versao_atual) <= 0;
      instalar.disabled = !p.modo_servico || (precisaConfirmar && !confirmaIgual);
    } else if (e.fase === 'erro') {
      bloco.innerHTML = `<h3>Não foi possível preparar o pacote</h3><div class="caixa-erro">${escaparHtml(e.erro)}</div>
        <p class="nota">Nada foi alterado no sistema. Corrija a origem e tente de novo.</p>
        <div class="acoes"><button class="btn btn-secundario" type="button" id="btnDescartar">Entendi</button></div>`;
    } else {
      bloco.innerHTML = `<div class="vazio-pacote">${CAIXA_SVG}<div class="fonte-display">Nenhum pacote baixado</div>
        <div class="nota">Salve a origem ao lado e clique em “Baixar pacote”.<br>Nada muda no sistema até você instalar.</div></div>`;
    }
  }

  if (FASES_PREPARO.includes(e.fase)) {
    const titulos = { baixando: 'Baixando o pacote', verificando: 'Conferindo o pacote', preparando: 'Preparando os arquivos' };
    $('pgTitulo').textContent = titulos[e.fase];
    $('pgSub').textContent = e.mensagem || '';
    const barra = $('pgBarra');
    const temTotal = e.fase === 'baixando' ? e.total > 0 : true;
    barra.classList.toggle('indef', !temTotal);
    const pct = e.fase === 'baixando' ? (e.total > 0 ? Math.min(100, (e.baixado / e.total) * 100) : 0) : 100;
    barra.firstElementChild.style.setProperty('--p', pct.toFixed(1) + '%');
    $('pgPct').textContent = e.fase === 'baixando' ? (e.total > 0 ? Math.floor(pct) + '%' : '…') : '100%';
    $('pgBytes').textContent = e.fase === 'baixando' ? fmtBytes(e.baixado) + (e.total > 0 ? ' de ' + fmtBytes(e.total) : '') : fmtBytes(e.tamanho);
    let vel = '', eta = '';
    if (e.fase === 'baixando') {
      amostras.push({ t: Date.now(), b: e.baixado });
      amostras = amostras.slice(-6);
      if (amostras.length >= 2) {
        const a = amostras[0], z = amostras[amostras.length - 1];
        const bps = (z.b - a.b) / Math.max(0.2, (z.t - a.t) / 1000);
        if (bps > 0) {
          vel = fmtBytes(bps) + '/s';
          if (e.total > 0) eta = 'faltam ~' + Math.max(1, Math.ceil((e.total - e.baixado) / bps)) + ' s';
        }
      }
    }
    $('pgVel').textContent = vel;
    $('pgEta').textContent = eta;
  }
}

// ---------------------------------------------------------------- tela cheia (instalação e resultado)
const TEXTOS_FASE = {
  aguardando: 'Preparando para parar o servidor…',
  parando: 'Parando o serviço do SisTer…',
  backup: 'Guardando uma cópia de segurança dos arquivos e do banco…',
  copiando: 'Trocando os arquivos pelos da versão nova…',
  iniciando: 'Ligando o serviço…',
  conferindo: 'Conferindo se o sistema voltou a responder…',
  revertendo: 'Algo deu errado. Voltando à versão anterior…',
};

function confete(el) {
  const cores = ['#0B6E4F', '#3FB68B', '#C98A2B', '#FFC862', '#8CC8FF', '#E4F2EC'];
  for (let i = 0; i < 34; i++) {
    const s = document.createElement('span');
    s.className = 'confete';
    s.style.left = (Math.random() * 100).toFixed(1) + '%';
    s.style.background = cores[i % cores.length];
    s.style.animationDelay = (Math.random() * 0.7).toFixed(2) + 's';
    s.style.transform = 'rotate(' + Math.floor(Math.random() * 180) + 'deg)';
    s.style.width = (6 + Math.random() * 6).toFixed(0) + 'px';
    el.appendChild(s);
  }
}

function htmlFim(r) {
  const log = (r.log || []).join('\n');
  const marcaOk = '<path class="marca" d="M24 41 L35 52 L57 29"/>';
  const marcaAviso = '<path class="marca" d="M40 22 V45 M40 56 V57"/>';
  let classe = '', titulo = '', texto = '', marca = marcaAviso;
  if (r.ok) {
    classe = ''; marca = marcaOk;
    titulo = 'Atualizado para a versão ' + escaparHtml(r.versao_nova);
    texto = 'O SisTer voltou a funcionar já na versão nova. Se alguma tela parecer antiga, pressione <b>Ctrl+F5</b>.';
  } else if (r.no_ar && r.revertido) {
    classe = 'falha';
    titulo = 'A atualização não foi concluída';
    texto = escaparHtml(r.mensagem);
  } else if (r.no_ar) {
    classe = 'falha';
    titulo = 'Atualização cancelada';
    texto = escaparHtml(r.mensagem);
  } else {
    classe = 'critico';
    titulo = 'O sistema não está respondendo';
    texto = escaparHtml(r.mensagem) + ' Abra <span class="mono">Logs\\atualizacao_' + escaparHtml(r.id) + '.log</span> no servidor.';
  }
  return `<div class="fim ${classe}" id="cartaoFim">
      <svg class="selo" viewBox="0 0 80 80" aria-hidden="true"><circle class="anel" cx="40" cy="40" r="36"/>${marca}</svg>
      <h2>${titulo}</h2>
      <p>${texto}</p>
      ${log ? `<details><summary>Ver o registro da instalação</summary><pre>${escaparHtml(log)}</pre></details>` : ''}
      <div class="acoes" style="justify-content:center; margin-top:14px;">
        <button class="btn btn-primario btn-grande" type="button" id="btnFechaFim" data-ok="${r.ok ? 1 : 0}">${r.ok ? 'Abrir o sistema atualizado' : 'Entendi'}</button>
      </div>
    </div>`;
}

function renderSobreposicao(p) {
  const aberta = overlayDeveAparecer(p);
  $('sobreposicao').classList.toggle('aberto', aberta);
  document.body.style.overflow = aberta ? 'hidden' : '';
  if (!aberta) { chaveFim = ''; return; }

  atualizarRota($('rotaOv'), calcularRota(p, ultimaAtiva));

  if (p && p.resultado) {
    $('ovAndamento').style.display = 'none';
    $('ovFim').style.display = '';
    const k = p.resultado.id + '|' + p.resultado.fim;
    if (k !== chaveFim) {
      chaveFim = k;
      $('ovFim').innerHTML = htmlFim(p.resultado);
      if (p.resultado.ok) confete($('cartaoFim'));
    }
    return;
  }
  $('ovAndamento').style.display = '';
  $('ovFim').style.display = 'none';
  chaveFim = '';
  const fase = p && p.aplicacao ? p.aplicacao.fase : 'aguardando';
  $('ovTexto').textContent = TEXTOS_FASE[fase] || 'Instalando…';
  $('ovSub').textContent = servidorFora
    ? 'O servidor está reiniciando — isso é esperado. Aguardando ele voltar…'
    : (fase === 'revertendo' ? 'Não se preocupe: a cópia de segurança está sendo restaurada.' : '');
}

setInterval(() => {
  if (!$('sobreposicao').classList.contains('aberto') || !inicioInstalacao) return;
  $('ovTempo').textContent = fmtTempo((Date.now() - inicioInstalacao) / 1000);
}, 1000);

// ---------------------------------------------------------------- renderização geral e polling
function renderizar() {
  if (!painel) return;
  const p = painel;
  if (p.estado.fase === 'baixando') ultimaAtiva = 0;
  else if (p.estado.fase === 'verificando') ultimaAtiva = 1;
  else if (p.estado.fase === 'preparando') ultimaAtiva = 2;

  if (emInstalacao(p) && !inicioInstalacao) {
    const t = p.aplicacao && p.aplicacao.inicio ? Date.parse(String(p.aplicacao.inicio).replace(' ', 'T')) : NaN;
    inicioInstalacao = Number.isNaN(t) ? Date.now() : t;
  }
  if (!emInstalacao(p) && !p.resultado && !servidorFora) {
    sessionStorage.removeItem(FLAG);
    if (!sessionStorage.getItem(FLAG)) inicioInstalacao = 0;
  }

  renderOdometro(p.versao_atual);
  $('heroSub').textContent = 'Compilado em ' + p.compilado_em;
  const g = resumoGeral(p);
  $('pilula').className = 'pilula ' + g.classe;
  $('pilulaTexto').textContent = g.texto;
  $('hero').classList.toggle('acelera', emInstalacao(p) || p.estado.fase === 'baixando');

  const r = calcularRota(p, ultimaAtiva);
  atualizarRota($('rota'), r);
  $('rotaTexto').textContent = r.texto;

  renderOrigem(p);
  renderBloco(p);
  renderSobreposicao(p);
}

function agendar() {
  clearTimeout(timer);
  let ms = 0;
  if (overlayDeveAparecer(painel) || (sessionStorage.getItem(FLAG) && servidorFora)) ms = 1500;
  else if (painel && FASES_PREPARO.includes(painel.estado.fase)) ms = 900;
  if (ms) timer = setTimeout(atualizar, ms);
}

async function atualizar() {
  try {
    painel = await Api.get('/atualizacao');
    servidorFora = false;
  } catch (e) {
    if (e.status === 403) { mostrarBloqueado(); return; }
    servidorFora = true;
    if (!sessionStorage.getItem(FLAG) && !emInstalacao(painel)) mostrarToast('Não foi possível atualizar o painel: ' + e.message);
  }
  renderizar();
  agendar();
}

function mostrarBloqueado() {
  $('conteudoAtualizacao').style.display = 'none';
  $('bloqueado').style.display = '';
}

// ---------------------------------------------------------------- ações
async function salvar(silencioso) {
  const v = validarCampos();
  if (!v.valido) throw new Error('Corrija os campos antes de salvar.');
  painel = await Api.put('/atualizacao/config', { url: v.url, sha256: v.sha });
  sujo = false;
  if (!silencioso) mostrarToast('Origem salva.');
  renderizar();
}

async function baixar() {
  $('btnBaixar').disabled = true;
  try {
    if (sujo) await salvar(true);
    amostras = [];
    painel = await Api.post('/atualizacao/baixar', {});
    renderizar();
    agendar();
  } catch (e) {
    mostrarToast(e.message);
    renderizar();
  }
}

async function cancelarOuDescartar() {
  try {
    painel = await Api.post('/atualizacao/cancelar', {});
    chaveBloco = '';
    confirmaIgual = false;
    renderizar();
    agendar();
  } catch (e) { mostrarToast(e.message); }
}

function abrirModal() {
  const p = painel;
  $('modalTexto').innerHTML = `O SisTer vai ficar <b>fora do ar por cerca de 1 minuto</b> para ir da <b>v${escaparHtml(p.versao_atual)}</b> para a <b>v${escaparHtml(p.estado.versao_pacote)}</b>. Todos os usuários serão desconectados por instantes.`;
  $('campoSenha').value = '';
  $('erroSenha').textContent = '';
  $('btnModalInstalar').disabled = false;
  $('btnModalInstalar').textContent = 'Instalar agora';
  $('modalConfirma').classList.add('aberto');
  setTimeout(() => $('campoSenha').focus(), 50);
}
function fecharModal() { $('modalConfirma').classList.remove('aberto'); }

async function instalar() {
  const senha = $('campoSenha').value;
  if (!senha) { $('erroSenha').textContent = 'Digite a sua senha para confirmar.'; return; }
  $('btnModalInstalar').disabled = true;
  $('btnModalInstalar').textContent = 'Conferindo…';
  try {
    painel = await Api.post('/atualizacao/aplicar', { senha });
    fecharModal();
    sessionStorage.setItem(FLAG, '1');
    inicioInstalacao = Date.now();
    chaveFim = '';
    renderizar();
    agendar();
  } catch (e) {
    $('erroSenha').textContent = e.message;
    $('btnModalInstalar').disabled = false;
    $('btnModalInstalar').textContent = 'Instalar agora';
  }
}

async function fecharResultado(ok) {
  try { await Api.del('/atualizacao/resultado'); } catch (e) { /* segue mesmo assim */ }
  sessionStorage.removeItem(FLAG);
  inicioInstalacao = 0;
  if (ok) { location.reload(); return; }
  await atualizar();
}

function copiar(texto) {
  const ok = () => mostrarToast('SHA-256 copiado.');
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(texto).then(ok, () => mostrarToast('Não foi possível copiar.'));
  else mostrarToast('Seu navegador não permite copiar daqui.');
}

// ---------------------------------------------------------------- eventos e partida
function iniciar() {
  montarRota($('rota'));
  montarRota($('rotaOv'));

  ['campoUrl', 'campoSha'].forEach((id) => $(id).addEventListener('input', () => { sujo = true; if (painel) renderOrigem(painel); }));
  $('btnSalvar').addEventListener('click', () => salvar(false).catch((e) => mostrarToast(e.message)));
  $('btnBaixar').addEventListener('click', baixar);

  // o bloco do pacote é redesenhado conforme a fase: os botões dele usam delegação
  $('blocoPacote').addEventListener('click', (ev) => {
    const alvo = ev.target.closest('button');
    if (!alvo) return;
    if (alvo.id === 'btnCancelar' || alvo.id === 'btnDescartar') cancelarOuDescartar();
    else if (alvo.id === 'btnInstalar') abrirModal();
    else if (alvo.dataset.copiar) copiar(alvo.dataset.copiar);
  });
  $('blocoPacote').addEventListener('change', (ev) => {
    if (ev.target.id === 'chkIgual') {
      confirmaIgual = ev.target.checked;
      $('btnInstalar').disabled = !painel.modo_servico || !confirmaIgual;
    }
  });

  $('btnModalCancelar').addEventListener('click', fecharModal);
  $('btnModalInstalar').addEventListener('click', instalar);
  $('campoSenha').addEventListener('keydown', (ev) => { if (ev.key === 'Enter') instalar(); });
  $('modalConfirma').addEventListener('click', (ev) => { if (ev.target === $('modalConfirma')) fecharModal(); });
  document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && $('modalConfirma').classList.contains('aberto')) fecharModal(); });
  $('ovFim').addEventListener('click', (ev) => {
    const b = ev.target.closest('#btnFechaFim');
    if (b) fecharResultado(b.dataset.ok === '1');
  });

  atualizar();
}

if (!usuarioLogado || usuarioLogado.perfil !== 'Administrador') mostrarBloqueado();
else iniciar();
