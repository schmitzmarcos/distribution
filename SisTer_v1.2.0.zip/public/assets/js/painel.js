  exigirLogin();

  // ------------------------------------------------------------------ sessão / barra lateral
  const $ = (id) => document.getElementById(id);
  const usuario = Api.usuario();
  if (usuario) {
    $('nomeUsuario').textContent = usuario.nome;
    $('perfilUsuario').textContent = usuario.perfil;
    $('avatarUsuario').textContent = usuario.nome.charAt(0).toUpperCase();
    if (usuario.perfil === 'Administrador') $('navAdministracao').style.display = '';
  }
  $('btnSair').addEventListener('click', () => Api.sair());

  // ------------------------------------------------------------------ utilidades
  const ICONES = {
    route:    '<circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19h6a3 3 0 0 0 0-6h-4a3 3 0 0 1 0-6h6"/>',
    trend:    '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    gauge:    '<path d="M4 17a8 8 0 1 1 16 0"/><path d="M12 17l4-5"/>',
    wallet:   '<path d="M3 7h15a3 3 0 0 1 3 3v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 7V6a2 2 0 0 1 2-2h11"/><circle cx="16.5" cy="14" r="1"/>',
    bell:     '<path d="M6 17V11a6 6 0 1 1 12 0v6l2 2H4z"/><path d="M10 21a2 2 0 0 0 4 0"/>',
    bus:      '<rect x="4" y="3" width="16" height="14" rx="3"/><path d="M4 11h16M8 21v-3M16 21v-3"/><circle cx="8" cy="14" r=".7"/><circle cx="16" cy="14" r=".7"/>',
    pessoa:   '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M6 16c.6-1.5 1.8-2 3-2s2.4.5 3 2M14 10h4M14 14h3"/>',
    cheque:   '<path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
    caixa:    '<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
    refresh:  '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
    ok:       '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/>',
  };
  const ico = (nome, tam = 18) =>
    `<svg width="${tam}" height="${tam}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONES[nome] || ''}</svg>`;
  document.querySelectorAll('[data-ico]').forEach((el) => { el.innerHTML = ico(el.dataset.ico, Number(el.dataset.tam) || 17); });

  const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  const MESES_LONGO = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const DIAS_SEM = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];

  const pad = (n) => String(n).padStart(2, '0');
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const daIso = (s) => new Date(s.slice(0, 10) + 'T12:00:00');
  const somaDias = (d, n) => { const r = new Date(d); r.setDate(r.getDate() + n); return r; };
  const diffDias = (alvo, base) => Math.round((daIso(alvo) - daIso(base)) / 86400000);
  const dataCurta = (s) => `${s.slice(8, 10)}/${s.slice(5, 7)}`;
  const ehData = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}/.test(s);
  const plural = (n, um, varios) => (n === 1 ? um : varios);
  const capitalizar = (t) => t.charAt(0).toUpperCase() + t.slice(1);

  const esc = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const brl = (n) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 });
  const num = (n) => Math.round(n).toLocaleString('pt-BR');
  const compacto = (n) => {
    n = Number(n) || 0;
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace('.', ',').replace(',0', '') + ' mi';
    if (n >= 1e3) return (n / 1e3).toFixed(n < 1e5 ? 1 : 0).replace('.', ',').replace(',0', '') + ' mil';
    return String(Math.round(n));
  };
  const primeiroNome = (nome) => String(nome || '').trim().split(/\s+/)[0] || '';

  // Regra de "faturamento" de uma viagem: valor da nota; se estiver vazio, valor da viagem.
  const receita = (v) => (Number(v.valor_nota) > 0 ? Number(v.valor_nota) : Number(v.valor_viagem) || 0);
  const fimViagem = (v) => v.data_volta || v.data_saida;
  const somar = (lista, fn) => lista.reduce((s, x) => s + fn(x), 0);

  const reduzirMovimento = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Evita refazer o DOM (e reiniciar animações) quando nada mudou
  function pintar(el, html) { if (el._html !== html) { el.innerHTML = html; el._html = html; } }

  // Número que "sobe" até o valor final
  function contar(el, alvo, fmt) {
    el.classList.remove('dash-skel');
    cancelAnimationFrame(el._raf);
    const de = el._v ?? 0;
    el._v = alvo;
    if (reduzirMovimento || de === alvo) { el.textContent = fmt(alvo); return; }
    const t0 = performance.now(), dur = 750;
    const passo = (t) => {
      const p = Math.min(1, (t - t0) / dur);
      el.textContent = fmt(de + (alvo - de) * (1 - Math.pow(1 - p, 3)));
      if (p < 1) el._raf = requestAnimationFrame(passo);
    };
    el._raf = requestAnimationFrame(passo);
  }

  function pilulaDelta(atual, anterior, sufixo) {
    if (anterior === 0 && atual === 0) return '';
    if (anterior === 0) return `<span class="dash-delta neutro">sem comparativo</span>`;
    const pct = Math.round(((atual - anterior) / anterior) * 100);
    if (pct === 0) return `<span class="dash-delta neutro">= 0%</span>${sufixo}`;
    return `<span class="dash-delta ${pct > 0 ? 'sobe' : 'desce'}">${pct > 0 ? '▲ +' : '▼ −'}${Math.abs(pct)}%</span>${sufixo}`;
  }

  function sparkline(valores, svg) {
    const W = 86, H = 30, max = Math.max(...valores, 1), min = Math.min(...valores, 0);
    const passo = W / (valores.length - 1 || 1);
    const pts = valores.map((v, i) => [i * passo, H - 3 - ((v - min) / (max - min || 1)) * (H - 8)]);
    const linha = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    const ult = pts[pts.length - 1];
    pintar(svg, `<path d="${linha} L${W} ${H} L0 ${H} Z" fill="rgba(11,110,79,.10)"/>` +
      `<path d="${linha}" fill="none" stroke="#0B6E4F" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>` +
      `<circle cx="${ult[0].toFixed(1)}" cy="${ult[1].toFixed(1)}" r="2.6" fill="#C98A2B"/>`);
  }

  // ------------------------------------------------------------------ estado e carregamento
  // undefined = carregando · null = sem acesso / falhou · demais = dado
  const estado = { prox: undefined, meses: undefined, frota: undefined, func: undefined, aniv: undefined, clientes: undefined, resumo: undefined, chA: undefined, chT: undefined, est: undefined, forn: undefined };
  let falhas = 0;
  let alertasAbertos = false;
  let ultimaAtualizacao = 0;
  let carregando = false;

  const detalhesFalhas = [];
  async function seguro(fn, rotulo) {
    try { return await fn(); }
    catch (e) {
      if (e.status !== 403) { falhas++; detalhesFalhas.push(`${rotulo || 'indicador'}${e.status ? ' (' + e.status + ')' : ''}: ${e.message}`); }
      console.warn('Painel:', rotulo, e.status, e.message);
      return null;
    }
  }
  function guardar(chave, valor) { if (valor !== null || estado[chave] === undefined) estado[chave] = valor; }

  // Poucas requisições simultâneas: o servidor agradece (e o painel carrega do mesmo jeito)
  async function emFila(tarefas, limite) {
    let i = 0;
    const trabalhador = async () => { while (i < tarefas.length) { const t = tarefas[i++]; await t(); } };
    await Promise.all(Array.from({ length: Math.min(limite, tarefas.length) }, trabalhador));
  }

  function montarTarefas() {
    const agora = new Date();
    const hoje = iso(agora);
    // Módulo de permissão de cada indicador: sem "ver", nem pede ao servidor (o bloco simplesmente não aparece)
    const MODULO = { prox: 'faturas', meses: 'faturas', frota: 'frota', resumo: 'caixa', func: 'funcionarios', aniv: 'funcionarios', clientes: 'clientes', chA: 'cheques', chT: 'cheques', est: 'estoque', forn: 'fornecedores' };
    const ROTULO = { prox: 'Próximas saídas', meses: 'Faturamento', frota: 'Frota', resumo: 'Caixa', func: 'Funcionários', aniv: 'Aniversariantes', clientes: 'Clientes', chA: 'Cheques', chT: 'Cheques', est: 'Estoque', forn: 'Fornecedores' };
    const tarefa = (chave, fn) => async () => {
      guardar(chave, Permissoes.pode(MODULO[chave], 'ver') ? await seguro(fn, ROTULO[chave]) : null);
      renderTudo();
    };

    return [
      tarefa('prox', async () => (await Api.get(`/faturas?de=${hoje}&ate=${iso(somaDias(agora, 14))}`)).dados),
      tarefa('frota', async () => Api.get('/frota?somente_ativos=1&itens_por_pagina=200')),
      tarefa('resumo', async () => {
        const ini = iso(new Date(agora.getFullYear(), agora.getMonth(), 1));
        const fim = iso(new Date(agora.getFullYear(), agora.getMonth() + 1, 0));
        return Api.get(`/financeiro/resumo?de=${ini}&ate=${fim}`);
      }),
      tarefa('func', async () => (await Api.get('/funcionarios?somente_ativos=1&itens_por_pagina=200')).dados),
      tarefa('meses', async () => {
        const saida = [];
        for (let i = 0; i < 6; i++) {
          const ref = new Date(agora.getFullYear(), agora.getMonth() - i, 1);
          const ini = iso(ref), fim = iso(new Date(ref.getFullYear(), ref.getMonth() + 1, 0));
          const r = await Api.get(`/faturas?de=${ini}&ate=${fim}`);
          saida.push({ ini, fim, rotulo: MESES[ref.getMonth()], viagens: r.dados.filter((v) => v.data_saida >= ini && v.data_saida <= fim) });
        }
        return saida.reverse(); // do mais antigo ao mês atual
      }),
      tarefa('aniv', async () => (await Api.get(`/funcionarios/relatorios/aniversariantes?mes=${agora.getMonth() + 1}`)).dados),
      tarefa('clientes', async () => (await Api.get('/clientes?itens_por_pagina=1')).total),
      tarefa('chA', async () => (await Api.get('/cheques?tipo=A')).dados),
      tarefa('chT', async () => (await Api.get('/cheques?tipo=T')).dados),
      tarefa('est', async () => Api.get('/estoque?filtro=repor&ordem=urgencia&itens_por_pagina=6')),
      tarefa('forn', async () => Api.get('/fornecedores?itens_por_pagina=1')),
    ];
  }

  async function carregar() {
    if (carregando) return;
    carregando = true;
    falhas = 0;
    detalhesFalhas.length = 0;
    await Permissoes.pronto; // permissões atualizadas antes de decidir o que pedir
    $('btnAtualizar').classList.add('girando');
    await emFila(montarTarefas(), 4);
    ultimaAtualizacao = Date.now();
    const d = new Date();
    $('textoAtualizado').textContent = `Atualizado às ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    $('avisoFalha').hidden = falhas === 0;
    if (falhas) $('avisoFalha').querySelector('span').textContent = 'Alguns indicadores não puderam ser carregados: ' + detalhesFalhas.slice(0, 3).join(' · ');
    $('btnAtualizar').classList.remove('girando');
    carregando = false;
  }

  // ------------------------------------------------------------------ pontos de atenção
  const DOCS_FROTA = [
    ['venc_vistoria', 'Laudo de vistoria'], ['venc_lic_turismo', 'Licença de turismo'], ['venc_lic_fretamento', 'Licença de fretamento'],
    ['venc_inmetro_nacional', 'Inmetro nacional'], ['venc_inmetro_internacional', 'Inmetro internacional'], ['venc_ipva', 'IPVA'],
    ['venc_consulado_argentina', 'Consulado Argentina'], ['venc_consulado_uruguai', 'Consulado Uruguai'], ['venc_consulado_chile', 'Consulado Chile'],
    ['venc_embratur', 'Embratur'], ['venc_metroplan', 'Laudo Metroplan'], ['venc_antt_nacional', 'Laudo ANTT nacional'],
    ['venc_antt_internacional', 'Laudo ANTT internacional'], ['venc_receftur', 'RecefTur'], ['venc_apolice', 'Apólice de seguro'],
    ['venc_grade_daer', 'Grade horária DAER'], ['venc_extintor', 'Extintor'], ['venc_tacografo', 'Tacógrafo'],
  ];
  const CHEQUE_RESOLVIDO = /compensad|devolvid|pag[oa]|baixad|cancelad|depositad|descontad|sustad/i;

  const prazo = (dias, data) => {
    if (dias < 0) return `venceu há ${-dias} ${plural(-dias, 'dia', 'dias')}`;
    if (dias === 0) return 'vence hoje';
    if (dias === 1) return 'vence amanhã';
    return `vence em ${dias} dias (${dataCurta(data)})`;
  };
  const etiquetaPrazo = (dias) => (dias < 0 ? 'Vencido' : dias === 0 ? 'Hoje' : dias === 1 ? 'Amanhã' : `${dias} dias`);

  function montarAlertas() {
    const hoje = iso(new Date());
    const lista = [];
    const add = (nivel, tipo, titulo, detalhe, dias, link, etiqueta) => lista.push({ nivel, tipo, titulo, detalhe, dias, link, etiqueta });

    // Documentos da frota (vencidos ou a vencer em 30 dias)
    (estado.frota?.dados || []).forEach((v) => DOCS_FROTA.forEach(([campo, rotulo]) => {
      const data = v[campo];
      if (!ehData(data)) return;
      const dias = diffDias(data, hoje);
      if (dias > 30) return;
      add(dias <= 0 ? 'perigo' : 'alerta', 'bus', `${rotulo} · Veículo ${v.numero}`, `${v.placa} · ${prazo(dias, data)}`, dias, 'frota.html');
    }));

    // CNH e exame de saúde da equipe
    (estado.func || []).forEach((f) => [['data_vencimento_cnh', 'CNH'], ['data_vencimento_exame_saude', 'Exame de saúde']].forEach(([campo, rotulo]) => {
      const data = f[campo];
      if (!ehData(data)) return;
      const dias = diffDias(data, hoje);
      if (dias > 30) return;
      add(dias <= 0 ? 'perigo' : 'alerta', 'pessoa', `${rotulo} · ${f.apelido || f.nome}`, prazo(dias, data), dias, 'funcionarios.html');
    }));

    // Viagens da próxima semana: sem motorista/veículo ou pendentes de confirmação
    (estado.prox || []).filter((v) => v.data_saida >= hoje && diffDias(v.data_saida, hoje) <= 7).forEach((v) => {
      const dias = diffDias(v.data_saida, hoje);
      const quando = dias === 0 ? 'sai hoje' : dias === 1 ? 'sai amanhã' : `sai em ${dias} dias`;
      const faltam = [];
      if (!v.id_funcionario1) faltam.push('motorista');
      if (!v.id_veiculo) faltam.push('veículo');
      const rota = `${v.cliente_nome || 'Cliente'} → ${v.destino || 'destino a definir'} · ${quando}`;
      if (faltam.length) add(dias <= 1 ? 'perigo' : 'alerta', 'route', `Sem ${faltam.join(' e ')} definido`, rota, dias, 'agenda.html');
      if (v.status === 'P') add('alerta', 'route', 'Viagem pendente de confirmação', rota, dias, 'agenda.html');
    });

    // Cheques recém-vencidos ou a vencer (só os que ainda não têm status de baixa)
    [['A', estado.chA, 'agência'], ['T', estado.chT, 'terceiros']].forEach(([, cheques, origem]) => (cheques || []).forEach((c) => {
      if (!ehData(c.vencimento) || CHEQUE_RESOLVIDO.test(c.status || '')) return;
      const dias = diffDias(c.vencimento, hoje);
      if (dias < -3 || dias > 7) return;
      const quem = c.emitente || c.recebido_de || c.destino || '';
      const valor = Number(c.valor_saida) || Number(c.valor_entrada) || 0;
      add(dias < 0 ? 'perigo' : 'alerta', 'cheque', `Cheque ${c.numero ? 'nº ' + c.numero + ' ' : ''}(${origem})`,
        [quem, valor ? brl(valor) : '', prazo(dias, c.vencimento)].filter(Boolean).join(' · '), dias, 'cheques.html');
    }));

    // Estoque: itens no minimo (ou abaixo) e itens sem saldo
    if (estado.est && estado.est.resumo && estado.est.resumo.negativos > 0) {
      const n = estado.est.resumo.negativos;
      add('alerta', 'caixa', 'Estoque com saldo negativo', `${n} ${plural(n, 'item', 'itens')} com saldo menor que zero: confira as movimentações`, 14, 'estoque.html', 'Conferir');
    }
    if (estado.est && estado.est.resumo && (estado.est.resumo.repor > 0 || estado.est.resumo.zerados > 0)) {
      const e = estado.est.resumo;
      const partes = [];
      if (e.repor > 0) partes.push(`${e.repor} ${e.repor === 1 ? 'item' : 'itens'} para repor`);
      if (e.zerados > 0) partes.push(`${e.zerados} sem saldo`);
      add(e.zerados > 0 ? 'perigo' : 'alerta', 'caixa', 'Estoque pede reposição', partes.join(' · '), 15, 'estoque.html?filtro=repor', 'Repor');
    }

    const peso = { perigo: 0, alerta: 1 };
    lista.sort((a, b) => peso[a.nivel] - peso[b.nivel] || a.dias - b.dias);
    return lista;
  }

  const alertasProntos = () => ['prox', 'frota', 'func', 'chA', 'chT', 'est'].every((k) => estado[k] !== undefined);

  // ------------------------------------------------------------------ renderização
  function visivel(id, fonte) { // devolve true se há dado para desenhar
    if (fonte === undefined) return false;
    $(id).hidden = fonte === null;
    return fonte !== null;
  }
  const kpi = (id) => ({ el: $(id), v: $(id).querySelector('[data-v]'), sub: $(id).querySelector('[data-sub]'), spark: $(id).querySelector('[data-spark]') });

  function renderKpis() {
    const hoje = iso(new Date());

    // Saídas hoje
    if (visivel('kpiSaidas', estado.prox)) {
      const k = kpi('kpiSaidas');
      const saidas = estado.prox.filter((v) => v.data_saida === hoje).length;
      const emCurso = estado.prox.filter((v) => v.data_saida < hoje && fimViagem(v) >= hoje).length;
      contar(k.v, saidas, (n) => String(Math.round(n)));
      k.sub.textContent = emCurso ? `${emCurso} ${plural(emCurso, 'viagem em curso', 'viagens em curso')}` : 'Nenhuma viagem em curso';
    }

    // Faturamento e viagens do mês
    if (estado.meses === undefined) { /* carregando */ }
    else if (estado.meses === null) { $('kpiFaturamento').hidden = true; $('kpiViagens').hidden = true; }
    else {
      $('kpiFaturamento').hidden = false; $('kpiViagens').hidden = false;
      const atual = estado.meses[5], ant = estado.meses[4];
      const diaHoje = new Date().getDate();
      const corteAnt = ant.ini.slice(0, 8) + pad(Math.min(diaHoje, Number(ant.fim.slice(8))));
      const feitasAtual = atual.viagens.filter((v) => v.data_saida <= hoje);
      const feitasAnt = ant.viagens.filter((v) => v.data_saida <= corteAnt);
      const recAtual = somar(feitasAtual, receita), recAnt = somar(feitasAnt, receita);
      const agendado = somar(atual.viagens.filter((v) => v.data_saida > hoje), receita);
      const liquido = somar(feitasAtual, (v) => Number(v.valor_liquido) || 0);

      const kf = kpi('kpiFaturamento');
      contar(kf.v, recAtual, (n) => brl(n));
      kf.sub.innerHTML = pilulaDelta(recAtual, recAnt, 'vs. mesmo período do mês anterior') +
        (agendado ? `<br>+ ${brl(agendado)} já agendado até o fim do mês` : (liquido ? `<br>Líquido após impostos: ${brl(liquido)}` : ''));
      sparkline(estado.meses.map((m) => somar(m.viagens, receita)), kf.spark);

      const kv = kpi('kpiViagens');
      contar(kv.v, feitasAtual.length, (n) => String(Math.round(n)));
      const ticket = feitasAtual.length ? recAtual / feitasAtual.length : 0;
      const aindaAgendadas = atual.viagens.length - feitasAtual.length;
      kv.sub.innerHTML = pilulaDelta(feitasAtual.length, feitasAnt.length, 'vs. mês anterior') +
        `<br>${aindaAgendadas ? aindaAgendadas + ' ' + plural(aindaAgendadas, 'agendada', 'agendadas') + ' · ' : ''}${ticket ? 'ticket médio ' + brl(ticket) : 'sem valores lançados'}`;
    }

    // Frota em operação hoje
    if (visivel('kpiFrota', estado.prox)) {
      const k = kpi('kpiFrota');
      const emUso = new Set(estado.prox.filter((v) => v.id_veiculo && v.data_saida <= hoje && fimViagem(v) >= hoje).map((v) => v.id_veiculo)).size;
      const total = estado.frota ? Number(estado.frota.total) || estado.frota.dados.length : null;
      if (total) {
        contar(k.v, (emUso / total) * 100, (n) => `${Math.round(n)}%`);
        k.sub.textContent = `${emUso} de ${total} ${plural(total, 'veículo ativo', 'veículos ativos')} em viagem`;
        k.el.dataset.tom = emUso / total >= 0.9 ? 'alerta' : '';
      } else {
        contar(k.v, emUso, (n) => String(Math.round(n)));
        k.sub.textContent = plural(emUso, 'veículo em viagem', 'veículos em viagem');
      }
    }

    // Saldo do caixa
    if (visivel('kpiCaixa', estado.resumo)) {
      const k = kpi('kpiCaixa');
      const r = estado.resumo;
      const ate = (r.dias || []).filter((d) => d.data <= hoje);
      const saldo = (Number(r.saldo_anterior) || 0) + somar(ate, (d) => d.entradas - d.saidas);
      const entradas = somar(r.dias || [], (d) => Number(d.entradas) || 0), saidas = somar(r.dias || [], (d) => Number(d.saidas) || 0);
      contar(k.v, saldo, (n) => brl(n));
      k.v.classList.toggle('negativo', saldo < 0);
      k.sub.innerHTML = `Entradas ${brl(entradas)} · Saídas ${brl(saidas)}` + (r.previsto ? `<br>${brl(r.previsto)} a receber/em aberto` : '');
      k.el.dataset.tom = saldo < 0 ? 'perigo' : '';
    }

    // Estoque e fornecedores
    if (visivel('kpiEstoque', estado.est)) {
      const k = kpi('kpiEstoque');
      const e = estado.est.resumo || {};
      contar(k.v, e.repor || 0, (n) => String(Math.round(n)));
      const partes = [];
      if (e.zerados) partes.push(`${e.zerados} ${plural(e.zerados, 'item sem saldo', 'itens sem saldo')}`);
      if (e.negativos) partes.push(`${e.negativos} com saldo negativo`);
      k.sub.textContent = partes.length ? partes.join(' · ') : 'Tudo acima do mínimo ✓';
      k.el.dataset.tom = e.zerados || e.negativos ? 'perigo' : e.repor ? 'alerta' : '';
    }
    if (visivel('kpiValorEstoque', estado.est)) {
      const k = kpi('kpiValorEstoque');
      const e = estado.est.resumo || {};
      contar(k.v, e.valor_estoque || 0, (n) => brl(n));
      k.sub.innerHTML = `${num(e.itens || 0)} ${plural(e.itens, 'item ativo', 'itens ativos')} · a custo médio` +
        (e.compras_mes ? `<br>Compras no mês: ${brl(e.compras_mes)}` : '');
    }
    if (visivel('kpiFornecedores', estado.forn)) {
      const k = kpi('kpiFornecedores');
      const f = estado.forn.resumo || {};
      contar(k.v, f.ativos || 0, (n) => String(Math.round(n)));
      k.sub.innerHTML = f.sem_contato
        ? `${f.sem_contato} sem telefone, e-mail ou contato`
        : 'Todos com contato cadastrado ✓';
      k.el.dataset.tom = f.sem_contato ? 'alerta' : '';
    }

    // Pontos de atenção
    if (alertasProntos()) {
      const k = kpi('kpiAtencao');
      const lista = montarAlertas();
      const criticos = lista.filter((a) => a.nivel === 'perigo').length;
      contar(k.v, lista.length, (n) => String(Math.round(n)));
      k.el.dataset.tom = criticos ? 'perigo' : lista.length ? 'alerta' : '';
      k.sub.textContent = lista.length ? `${criticos} ${plural(criticos, 'crítico', 'críticos')} · ${lista.length - criticos} em atenção` : 'Tudo em dia ✓';
    }
  }

  function renderProximas() {
    if (!visivel('cartaoProximas', estado.prox)) return;
    const hoje = iso(new Date());
    const limite = iso(somaDias(new Date(), 7));
    const viagens = estado.prox.filter((v) => v.data_saida <= limite);
    $('subProximas').textContent = viagens.length ? `${viagens.length} ${plural(viagens.length, 'viagem', 'viagens')} nos próximos 7 dias` : 'Próximos 7 dias';

    if (!viagens.length) {
      pintar($('listaProximas'), '<div class="dash-vazio"><strong>Agenda livre por enquanto</strong>Nenhuma saída nos próximos 7 dias.</div>');
      return;
    }

    const MAX = 8;
    const grupos = new Map();
    viagens.slice(0, MAX).forEach((v) => {
      const chave = v.data_saida < hoje ? 'curso' : v.data_saida;
      if (!grupos.has(chave)) grupos.set(chave, []);
      grupos.get(chave).push(v);
    });

    const rotuloGrupo = (chave) => {
      if (chave === 'curso') return 'Em curso';
      const dias = diffDias(chave, hoje);
      if (dias === 0) return 'Hoje';
      if (dias === 1) return 'Amanhã';
      return `${DIAS_SEM[daIso(chave).getDay()]}, ${dataCurta(chave)}`;
    };
    const local = (cidade, uf) => esc(cidade || '—') + (uf ? '/' + esc(uf) : '');

    let html = '<ul class="dash-lista">';
    grupos.forEach((itens, chave) => {
      html += `<li class="dash-grupo ${chave === 'curso' || chave === hoje ? 'destaque' : ''}">${esc(rotuloGrupo(chave))}</li>`;
      itens.forEach((v) => {
        const hora = chave === 'curso'
          ? `<small>até</small>${esc(dataCurta(fimViagem(v)))}`
          : esc(v.hora_saida || '—');
        const motorista = v.motorista1_nome
          ? esc(primeiroNome(v.motorista1_nome)) + (v.motorista2_nome ? ' +1' : '')
          : '<span class="falta">Sem motorista</span>';
        const veiculo = v.veiculo_numero ? `Veículo ${esc(v.veiculo_numero)}` : '<span class="falta">Sem veículo</span>';
        html += `<li><a class="dash-viagem" href="agenda.html" style="text-decoration:none;color:inherit">` +
          `<div class="dash-hora">${hora}</div><div>` +
          `<div class="dash-viagem-titulo">${esc(v.cliente_nome || 'Cliente não informado')}` +
          `<span class="badge ${v.status === 'P' ? 'badge-alerta' : 'badge-ativo'}">${v.status === 'P' ? 'Pendente' : 'Confirmada'}</span>` +
          (Number(v.internacional) ? '<span class="badge badge-inativo">Internacional</span>' : '') + '</div>' +
          `<div class="dash-viagem-rota">${local(v.origem, v.uf_origem)} → ${local(v.destino, v.uf_destino)}</div>` +
          `<div class="dash-viagem-meta">${veiculo} · ${motorista}</div></div></a></li>`;
      });
    });
    html += '</ul>';
    if (viagens.length > MAX) html += `<div class="dash-rodape-lista">+ ${viagens.length - MAX} ${plural(viagens.length - MAX, 'saída', 'saídas')} nesta semana — veja tudo na agenda.</div>`;
    pintar($('listaProximas'), html);
  }

  function renderFaturamento() {
    if (!visivel('cartaoFaturamento', estado.meses)) return;
    const hoje = iso(new Date());
    const dados = estado.meses.map((m, i) => {
      const total = somar(m.viagens, receita);
      const real = i === estado.meses.length - 1 ? somar(m.viagens.filter((v) => v.data_saida <= hoje), receita) : total;
      return { rotulo: m.rotulo, total, real, qtd: m.viagens.length };
    });
    const anteriores = dados.slice(0, -1);
    const media = anteriores.length ? somar(anteriores, (d) => d.total) / anteriores.length : 0;
    $('subFaturamento').textContent = media ? `Média dos 5 meses anteriores: ${brl(media)}` : '';

    const W = 620, H = 236, pe = 10, pd = 10, pt = 30, pb = 46, area = H - pt - pb;
    const max = Math.max(1, ...dados.map((d) => d.total)) * 1.08;
    const slot = (W - pe - pd) / dados.length, larg = Math.min(58, slot * 0.56);

    let svg = `<svg viewBox="0 0 ${W} ${H}" class="dash-svg" role="img" aria-label="Faturamento dos últimos 6 meses">`;
    for (let g = 0; g <= 3; g++) { const y = pt + area - (area * g) / 3; svg += `<line x1="${pe}" x2="${W - pd}" y1="${y}" y2="${y}" class="grade"/>`; }
    dados.forEach((d, i) => {
      const x = pe + slot * i + (slot - larg) / 2, atual = i === dados.length - 1;
      const hTot = (area * d.total) / max, hReal = (area * d.real) / max;
      const yTot = pt + area - hTot, yReal = pt + area - hReal;
      const dica = `${d.rotulo}: ${brl(d.total)} em ${d.qtd} ${plural(d.qtd, 'viagem', 'viagens')}` + (atual && d.total > d.real ? ` (${brl(d.real)} realizado)` : '');
      if (d.total > d.real) svg += `<rect x="${x}" y="${yTot}" width="${larg}" height="${hTot - hReal}" rx="5" class="barra-agendada"><title>${esc(dica)}</title></rect>`;
      svg += `<rect x="${x}" y="${yReal}" width="${larg}" height="${Math.max(hReal, d.total ? 2 : 0)}" rx="5" class="${atual ? 'barra-atual' : 'barra-passada'}"><title>${esc(dica)}</title></rect>`;
      svg += `<text x="${x + larg / 2}" y="${yTot - 8}" text-anchor="middle" class="valor">${d.total ? compacto(d.total) : '—'}</text>`;
      svg += `<text x="${x + larg / 2}" y="${H - 24}" text-anchor="middle" class="mes ${atual ? 'atual' : ''}">${esc(d.rotulo)}</text>`;
      svg += `<text x="${x + larg / 2}" y="${H - 10}" text-anchor="middle" class="qtd">${d.qtd} ${plural(d.qtd, 'viagem', 'viagens')}</text>`;
    });
    if (media) { const y = pt + area - (area * media) / max; svg += `<line x1="${pe}" x2="${W - pd}" y1="${y}" y2="${y}" stroke="#C98A2B" stroke-width="1.2" stroke-dasharray="5 4"/>`; }
    svg += '</svg>';
    pintar($('graficoFaturamento'), svg);
  }

  function renderCaixa() {
    if (!visivel('cartaoCaixa', estado.resumo)) return;
    const r = estado.resumo, agora = new Date(), hoje = iso(agora);
    const diasMes = new Date(agora.getFullYear(), agora.getMonth() + 1, 0).getDate();
    const prefixo = iso(new Date(agora.getFullYear(), agora.getMonth(), 1)).slice(0, 8);
    const porDia = {};
    (r.dias || []).forEach((d) => { porDia[Number(d.data.slice(8, 10))] = d; });

    const entradas = somar(r.dias || [], (d) => Number(d.entradas) || 0), saidas = somar(r.dias || [], (d) => Number(d.saidas) || 0);
    const resultado = entradas - saidas;
    pintar($('resumoCaixa'),
      `<div><span>Entradas</span><strong class="pos">${brl(entradas)}</strong></div>` +
      `<div><span>Saídas</span><strong>${brl(saidas)}</strong></div>` +
      `<div><span>Resultado</span><strong class="${resultado < 0 ? 'neg' : 'pos'}">${brl(resultado)}</strong></div>` +
      `<div><span>A receber / em aberto</span><strong>${brl(r.previsto)}</strong></div>`);

    if (!(r.dias || []).length) {
      pintar($('graficoCaixa'), '<div class="dash-vazio"><strong>Sem movimentação ainda</strong>Nenhum lançamento no caixa neste mês.</div>');
      return;
    }

    const W = 620, H = 210, pe = 6, pd = 6, topo = 12, meio = 98, subida = meio - topo, descida = 70;
    const maxAbs = Math.max(1, ...(r.dias || []).map((d) => Math.max(Number(d.entradas) || 0, Number(d.saidas) || 0)));
    const slot = (W - pe - pd) / diasMes, larg = Math.max(3, slot * 0.62);
    const diaHoje = agora.getDate();

    let svg = `<svg viewBox="0 0 ${W} ${H}" class="dash-svg" role="img" aria-label="Fluxo de caixa diário do mês">`;
    svg += `<rect x="${pe + slot * (diaHoje - 1)}" y="${topo - 6}" width="${slot}" height="${subida + descida + 12}" class="faixa-hoje" rx="4"/>`;
    svg += `<line x1="${pe}" x2="${W - pd}" y1="${meio}" y2="${meio}" class="eixo"/>`;
    for (let dia = 1; dia <= diasMes; dia++) {
      const d = porDia[dia], x = pe + slot * (dia - 1) + (slot - larg) / 2;
      if (d) {
        const e = Number(d.entradas) || 0, s = Number(d.saidas) || 0;
        const dica = `${pad(dia)}/${prefixo.slice(5, 7)}: entradas ${brl(e)} · saídas ${brl(s)}`;
        if (e) svg += `<rect x="${x}" y="${meio - (subida * e) / maxAbs}" width="${larg}" height="${(subida * e) / maxAbs}" rx="2" class="entrada"><title>${esc(dica)}</title></rect>`;
        if (s) svg += `<rect x="${x}" y="${meio}" width="${larg}" height="${(descida * s) / maxAbs}" rx="2" class="saida"><title>${esc(dica)}</title></rect>`;
      }
      if (dia === 1 || dia % 5 === 0 || dia === diasMes) svg += `<text x="${pe + slot * (dia - 1) + slot / 2}" y="${H - 8}" text-anchor="middle">${dia}</text>`;
    }
    svg += '</svg>';
    pintar($('graficoCaixa'), svg);
  }

  function renderAtencao() {
    if (!alertasProntos()) return;
    const lista = montarAlertas();
    const todosNulos = [estado.prox, estado.frota, estado.func, estado.chA, estado.chT].every((x) => x === null);
    if (todosNulos) { $('cartaoAtencao').hidden = true; return; }
    $('cartaoAtencao').hidden = false;

    if (!lista.length) {
      $('subAtencao').textContent = 'Vencimentos e pendências';
      pintar($('listaAtencao'), `<div class="dash-tudo-ok"><span style="color:var(--rota)">${ico('ok', 30)}</span><div><b>Tudo em dia</b><span>Nenhum documento vencendo e nenhuma viagem sem definição.</span></div></div>`);
      return;
    }
    const criticos = lista.filter((a) => a.nivel === 'perigo').length;
    $('subAtencao').textContent = criticos ? `${criticos} ${plural(criticos, 'item crítico', 'itens críticos')}` : 'Itens para os próximos dias';

    const LIMITE = 7;
    const visiveis = alertasAbertos ? lista : lista.slice(0, LIMITE);
    let html = visiveis.map((a) =>
      `<a class="dash-alerta ${a.nivel}" href="${a.link}">` +
      `<span class="dash-alerta-ico">${ico(a.tipo, 17)}</span>` +
      `<span><span class="dash-alerta-titulo">${esc(a.titulo)}</span><br><span class="dash-alerta-det">${esc(a.detalhe)}</span></span>` +
      `<span class="dash-etiqueta">${esc(a.etiqueta || etiquetaPrazo(a.dias))}</span></a>`).join('');
    if (lista.length > LIMITE) html += `<button type="button" class="dash-mais" id="btnMaisAlertas">${alertasAbertos ? 'Mostrar menos' : `Mostrar todos (${lista.length})`}</button>`;
    pintar($('listaAtencao'), html);
  }

  function renderOcupacao() {
    if (!visivel('cartaoOcupacao', estado.prox)) return;
    const hojeD = new Date(), hoje = iso(hojeD);
    const total = estado.frota ? Number(estado.frota.total) || estado.frota.dados.length : null;

    const dias = Array.from({ length: 14 }, (_, i) => {
      const d = somaDias(hojeD, i), dia = iso(d);
      const veiculos = new Set(estado.prox.filter((v) => v.id_veiculo && v.data_saida <= dia && fimViagem(v) >= dia).map((v) => v.id_veiculo));
      return { d, dia, n: veiculos.size };
    });
    const maxN = Math.max(1, ...dias.map((x) => x.n));
    const escala = total ? Math.max(total, maxN) : maxN;

    let html = '<div class="dash-ocup">';
    dias.forEach((x, i) => {
      const pct = total ? x.n / total : x.n / maxN;
      const dow = x.d.getDay();
      const dica = `${DIAS_SEM[dow]} ${dataCurta(x.dia)}: ${x.n} ${total ? 'de ' + total + ' ' : ''}${plural(x.n, 'veículo', 'veículos')} em viagem`;
      html += `<div class="dash-dia ${x.dia === hoje ? 'hoje' : ''} ${total && pct >= 0.85 ? 'cheio' : ''} ${dow === 0 || dow === 6 ? 'fds' : ''}" title="${esc(dica)}">` +
        `<span class="n">${x.n || ''}</span><div class="dash-barra" style="height:${Math.max(4, (x.n / escala) * 78)}px; --k:${i}"></div>` +
        `<span class="d">${DIAS_SEM[dow].charAt(0).toUpperCase()}<br>${pad(x.d.getDate())}</span></div>`;
    });
    html += '</div>';
    pintar($('graficoOcupacao'), html);

    const pico = dias.reduce((a, b) => (b.n > a.n ? b : a), dias[0]);
    const livresHoje = total ? Math.max(0, total - dias[0].n) : null;
    let nota = '';
    if (pico.n > 0) nota += `Dia mais cheio: <b>${DIAS_SEM[pico.d.getDay()]} ${dataCurta(pico.dia)}</b> com ${pico.n} ${total ? 'de ' + total + ' ' : ''}${plural(pico.n, 'veículo', 'veículos')}` + (total ? ` (${Math.round((pico.n / total) * 100)}%)` : '') + '. ';
    else nota += 'Nenhum veículo escalado nos próximos 14 dias. ';
    if (livresHoje !== null) nota += `Hoje ${plural(livresHoje, 'resta', 'restam')} <b>${livresHoje}</b> ${plural(livresHoje, 'veículo disponível', 'veículos disponíveis')}.`;
    pintar($('notaOcupacao'), nota);
  }

  function renderClientes() {
    if (!visivel('cartaoClientes', estado.meses)) return;
    const atual = estado.meses[5];
    $('subClientes').textContent = estado.clientes ? `${num(estado.clientes)} ${plural(estado.clientes, 'cliente ativo', 'clientes ativos')} no cadastro` : '';
    const porCliente = new Map();
    atual.viagens.forEach((v) => {
      const nome = v.cliente_nome || 'Cliente não informado';
      const x = porCliente.get(nome) || { nome, valor: 0, viagens: 0 };
      x.valor += receita(v); x.viagens += 1;
      porCliente.set(nome, x);
    });
    const ranking = [...porCliente.values()].sort((a, b) => b.valor - a.valor || b.viagens - a.viagens).slice(0, 5);
    if (!ranking.length) { pintar($('rankingClientes'), '<div class="dash-vazio"><strong>Sem viagens neste mês</strong>Assim que houver viagens, os principais clientes aparecem aqui.</div>'); return; }
    const total = somar([...porCliente.values()], (x) => x.valor);
    const max = Math.max(1, ranking[0].valor);
    pintar($('rankingClientes'), '<ul class="dash-rank">' + ranking.map((x, i) =>
      `<li><div class="dash-rank-linha"><b title="${esc(x.nome)}">${esc(x.nome)}</b>` +
      `<span>${brl(x.valor)}${total ? ' · ' + Math.round((x.valor / total) * 100) + '%' : ''} · ${x.viagens} ${plural(x.viagens, 'viagem', 'viagens')}</span></div>` +
      `<div class="dash-rank-trilho"><i style="width:${Math.max(3, (x.valor / max) * 100)}%; --k:${i}"></i></div></li>`).join('') + '</ul>');
  }

  function renderEquipe() {
    const tem = estado.func !== undefined && estado.aniv !== undefined;
    if (!tem) return;
    if (estado.func === null && estado.aniv === null) { $('cartaoEquipe').hidden = true; return; }
    $('cartaoEquipe').hidden = false;

    const mesNome = MESES_LONGO[new Date().getMonth()];
    let html = '';
    if (estado.func) {
      const motoristas = estado.func.filter((f) => f.tipo === 'Motorista').length;
      $('subEquipe').textContent = '';
      html += `<div class="dash-equipe"><div><strong>${estado.func.length}</strong><span>${plural(estado.func.length, 'funcionário ativo', 'funcionários ativos')}</span></div>` +
        `<div><strong>${motoristas}</strong><span>${plural(motoristas, 'motorista', 'motoristas')}</span></div></div>`;
    }
    if (estado.aniv) {
      const diaHoje = new Date().getDate();
      html += `<div class="dash-subtitulo">Aniversariantes de ${mesNome}</div>`;
      if (!estado.aniv.length) html += '<div class="dash-vazio" style="padding:8px 0">Ninguém faz aniversário neste mês.</div>';
      else {
        const MAX = 5;
        html += '<ul class="dash-aniv">' + estado.aniv.slice(0, MAX).map((a) =>
          `<li class="${a.dia === diaHoje ? 'hoje' : a.dia < diaHoje ? 'passou' : ''}"><span class="dia">${pad(a.dia)}</span><span>${esc(a.nome)}${a.dia === diaHoje ? ' 🎂 <b>hoje!</b>' : ''}</span></li>`).join('') + '</ul>';
        if (estado.aniv.length > MAX) html += `<div class="dash-rodape-lista">+ ${estado.aniv.length - MAX} no mês</div>`;
      }
    }
    pintar($('blocoEquipe'), html);
  }

  function renderEstoque() {
    if (estado.est === undefined || estado.forn === undefined) return;
    if (estado.est === null && estado.forn === null) { $('cartaoEstoque').hidden = true; return; }
    $('cartaoEstoque').hidden = false;
    const qtd = (n) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: 3 });

    let html = '';
    if (estado.est) {
      const r = estado.est.resumo || {}, itens = estado.est.dados || [];
      $('subEstoque').textContent = `${num(r.itens)} ${plural(r.itens, 'item ativo', 'itens ativos')} · ${brl(r.valor_estoque)} em estoque`;
      if (r.negativos) {
        html += `<div class="dash-aviso-linha perigo"><span>⚠</span><span><b>${r.negativos} ${plural(r.negativos, 'item', 'itens')} com saldo negativo.</b> ` +
          `Confira as movimentações no <a href="estoque.html?filtro=zerado">estoque</a>.</span></div>`;
      }
      html += `<div class="dash-equipe"><div><strong>${r.repor}</strong><span>${plural(r.repor, 'item para repor', 'itens para repor')}</span></div>` +
        `<div><strong>${r.zerados}</strong><span>${plural(r.zerados, 'item sem saldo', 'itens sem saldo')}</span></div></div>`;
      html += '<div class="dash-subtitulo">Mais urgentes</div>';
      if (!itens.length) {
        html += '<div class="dash-vazio" style="padding:8px 0">Nenhum item no estoque mínimo ou abaixo dele.</div>';
      } else {
        html += '<ul class="dash-est">' + itens.map((i, k) => {
          const min = Number(i.estoque_minimo), saldo = Number(i.saldo);
          const pct = i.nivel === 'zerado' ? 3 : Math.max(3, Math.min(100, min > 0 ? (saldo / min) * 100 : 100));
          return `<li class="est-${esc(i.nivel)}"><a href="estoque.html?item=${Number(i.id_item)}">` +
            `<div class="dash-rank-linha"><b>${esc(i.descricao)}</b><span>${i.nivel === 'zerado' ? 'sem saldo' : qtd(saldo)} / mín. ${qtd(min)} ${esc(i.unidade)}</span></div>` +
            `<div class="dash-rank-trilho"><i style="width:${pct.toFixed(0)}%; --k:${k}"></i></div></a></li>`;
        }).join('') + '</ul>';
        if (r.repor > itens.length) html += `<div class="dash-rodape-lista"><a href="estoque.html?filtro=repor">+ ${r.repor - itens.length} para repor</a> · <a href="relatorios/reposicao-estoque.html">lista de reposição</a></div>`;
        else html += '<div class="dash-rodape-lista"><a href="relatorios/reposicao-estoque.html">Abrir a lista de reposição</a></div>';
      }
    } else {
      $('subEstoque').textContent = '';
    }

    if (estado.forn) {
      const f = estado.forn.resumo || {};
      html += '<div class="dash-subtitulo" style="margin-top:16px">Fornecedores</div><div class="dash-forn-linhas">' +
        `<div><span>Ativos no cadastro</span><b>${num(f.ativos)}</b></div>` +
        (f.sem_contato ? `<div><span>Sem telefone, e-mail ou contato</span><b>${f.sem_contato}</b></div>` : '') +
        (f.sem_documento ? `<div><span>Sem CNPJ/CPF</span><b>${f.sem_documento}</b></div>` : '') +
        '</div>';
      if (!f.sem_contato && !f.sem_documento) html += '<div class="dash-rodape-lista">Cadastro completo ✓</div>';
      else html += '<div class="dash-rodape-lista"><a href="fornecedores.html">Completar cadastros →</a></div>';
    }
    pintar($('blocoEstoque'), html);
  }

  function renderHero() {
    const agora = new Date(), h = agora.getHours();
    const saud = h < 5 ? 'Boa madrugada' : h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
    $('saudacao').textContent = usuario ? `${saud}, ${primeiroNome(usuario.nome)}` : saud;
    $('dataHoje').textContent = capitalizar(agora.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }));

    const partes = [];
    if (estado.prox) {
      const hoje = iso(agora);
      const saidas = estado.prox.filter((v) => v.data_saida === hoje).length;
      const emCurso = estado.prox.filter((v) => v.data_saida < hoje && fimViagem(v) >= hoje).length;
      if (!saidas && !emCurso) partes.push('Nenhuma viagem saindo ou em curso hoje.');
      else {
        let f = saidas ? `Hoje ${plural(saidas, 'sai', 'saem')} ${saidas} ${plural(saidas, 'viagem', 'viagens')}` : 'Nenhuma saída hoje';
        if (emCurso) f += `${saidas ? ' e' : ','} ${emCurso} ${plural(emCurso, 'está', 'estão')} em curso`;
        partes.push(f + '.');
      }
    }
    if (alertasProntos()) {
      const lista = montarAlertas(), criticos = lista.filter((a) => a.nivel === 'perigo').length;
      if (criticos) partes.push(`${criticos} ${plural(criticos, 'item crítico exige', 'itens críticos exigem')} atenção agora.`);
      else if (lista.length) partes.push(`${lista.length} ${plural(lista.length, 'ponto', 'pontos')} de atenção nos próximos dias.`);
      else partes.push('Documentos e escalas em dia — tudo certo por aqui.');
      document.title = `SisTer · Início${criticos ? ` (${criticos})` : ''}`;
    }
    if (partes.length) $('resumoDia').textContent = partes.join(' ');
    else if (Object.values(estado).every((x) => x !== undefined)) $('resumoDia').textContent = 'Seu perfil não tem acesso aos indicadores deste painel. Use o menu lateral para navegar.';
  }

  function renderTudo() {
    renderHero(); renderKpis(); renderProximas(); renderFaturamento(); renderCaixa();
    renderAtencao(); renderOcupacao(); renderClientes(); renderEstoque(); renderEquipe();
  }

  // ------------------------------------------------------------------ eventos
  $('btnAtualizar').addEventListener('click', carregar);
  $('btnTentar').addEventListener('click', carregar);
  $('listaAtencao').addEventListener('click', (ev) => {
    if (ev.target.closest('#btnMaisAlertas')) { alertasAbertos = !alertasAbertos; renderAtencao(); }
  });
  $('kpiAtencao').addEventListener('click', (ev) => {
    ev.preventDefault();
    $('cartaoAtencao').scrollIntoView({ behavior: reduzirMovimento ? 'auto' : 'smooth', block: 'center' });
  });

  renderHero();
  carregar();
  setInterval(() => { if (!document.hidden) carregar(); }, 5 * 60 * 1000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && Date.now() - ultimaAtualizacao > 5 * 60 * 1000) carregar();
  });
