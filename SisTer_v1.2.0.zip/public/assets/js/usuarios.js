exigirLogin();

const $ = (id) => document.getElementById(id);

const usuarioLogado = Api.usuario();
if (usuarioLogado) {
  $('nomeUsuario').textContent = usuarioLogado.nome;
  $('perfilUsuario').textContent = usuarioLogado.perfil;
  $('avatarUsuario').textContent = usuarioLogado.nome.charAt(0).toUpperCase();
}
$('btnSair').addEventListener('click', () => Api.sair());

if (!usuarioLogado || usuarioLogado.perfil !== 'Administrador') {
  document.querySelector('main.conteudo').innerHTML = `
    <div class="estado-vazio" style="padding-top:80px;">
      <div class="fonte-display">Acesso restrito</div>
      <p>Esta área é só para o perfil Administrador.</p>
    </div>`;
  throw new Error('acesso restrito a Administrador');
}

function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML;
}
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3600);
}
function fmtDataHoraBR(s) {
  if (!s) return 'Nunca';
  return s.replace(' ', ' às ').split('-').length === 3
    ? (() => { const [d, resto] = s.split(' '); const [a, m, di] = d.split('-'); return `${di}/${m}/${a} às ${resto || ''}`; })()
    : s;
}

const RÓTULOS_MODULO = {
  clientes: 'Clientes', funcionarios: 'Funcionários', frota: 'Frota', faturas: 'Agenda de Viagens',
  caixa: 'Financeiro (Caixa)', cheques: 'Cheques', usuarios: 'Administração',
  estoque: 'Estoque', fornecedores: 'Fornecedores',
  salarios: 'Salários (ver/alterar o salário do funcionário)',
};

// ---------------------------------------------------------------- abas da página
document.querySelectorAll('.aba-pagina').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('.aba-pagina').forEach((x) => x.classList.toggle('ativa', x === b));
  document.querySelectorAll('[data-secao-conteudo]').forEach((s) => s.classList.toggle('ativa', s.dataset.secaoConteudo === b.dataset.secao));
  if (b.dataset.secao === 'perfis') carregarPermissoesDoPerfilSelecionado();
}));

// ---------------------------------------------------------------- perfis (compartilhado)
let perfis = [];
async function carregarListaPerfis() {
  try { perfis = (await Api.get('/perfis')).dados; } catch (e) { perfis = []; }
  const opts = perfis.map((p) => `<option value="${p.id_perfil}">${escaparHtml(p.nome)}</option>`).join('');
  $('campoPerfil').innerHTML = opts;
  $('selPerfilAtivo').innerHTML = opts;
}

// ================================================================= USUÁRIOS
let usuarios = [];

async function carregarUsuarios() {
  try {
    usuarios = (await Api.get('/usuarios')).dados;
  } catch (e) { mostrarToast(e.message); return; }

  // ordem alfabetica pelo nome (ignora maiusculas e acentos: "Álvaro" vem antes de "Bruno")
  usuarios.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR', { sensitivity: 'base' }));
  renderizarUsuarios();
}

// minusculas e sem acento, para a busca achar "joao" em "João"
const semAcento = (t) => String(t == null ? '' : t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

// A API devolve todos os usuarios (sao poucos): busca e "somente ativos" sao filtrados aqui, sem nova chamada.
function renderizarUsuarios() {
  const termo = semAcento($('campoBuscaUsuario').value.trim());
  const somenteAtivos = $('checkSomenteAtivos').checked;
  const lista = usuarios.filter((u) =>
    (!somenteAtivos || u.ativo) &&
    (!termo || semAcento(`${u.nome} ${u.login} ${u.nome_perfil}`).includes(termo)));

  const corpo = $('corpoUsuarios');
  corpo.innerHTML = '';
  $('vazioUsuarios').style.display = lista.length ? 'none' : 'block';
  $('vazioUsuariosTexto').textContent = usuarios.length ? 'Nenhum usuário encontrado' : 'Nenhum usuário cadastrado';

  lista.forEach((u) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${escaparHtml(u.nome)}</strong></td>
      <td>${escaparHtml(u.login)}</td>
      <td>${escaparHtml(u.nome_perfil)}</td>
      <td><span class="badge ${u.ativo ? 'badge-ativo' : 'badge-inativo'}">${u.ativo ? 'Ativo' : 'Inativo'}</span>
          ${u.precisa_trocar_senha ? '<span class="badge badge-alerta" style="margin-left:4px;">troca de senha pendente</span>' : ''}</td>
      <td>${fmtDataHoraBR(u.ultimo_login)}</td>`;
    tr.addEventListener('click', () => abrirEdicaoUsuario(u.id_usuario));
    corpo.appendChild(tr);
  });
}

$('campoBuscaUsuario').addEventListener('input', renderizarUsuarios);
$('checkSomenteAtivos').addEventListener('change', renderizarUsuarios);

// ---- painel do usuário
const painelFundo = $('painelFundo');
const painelLateral = $('painelLateral');
let idUsuarioAtual = null;

function abrirPainel(titulo) { $('tituloPainel').textContent = titulo; painelFundo.classList.add('aberto'); painelLateral.classList.add('aberto'); }
function fecharPainel() { painelFundo.classList.remove('aberto'); painelLateral.classList.remove('aberto'); }
$('btnFecharPainel').addEventListener('click', fecharPainel);
$('btnCancelarPainel').addEventListener('click', fecharPainel);
painelFundo.addEventListener('click', fecharPainel);

$('btnNovoUsuario').addEventListener('click', () => {
  idUsuarioAtual = null;
  $('campoNome').value = '';
  $('campoLogin').value = '';
  $('campoLogin').disabled = false;
  $('campoEmail').value = '';
  $('campoPerfil').value = perfis[0] ? perfis[0].id_perfil : '';
  $('campoSenhaInicialBloco').style.display = 'block';
  $('campoSenhaInicial').value = '';
  $('campoAtivoBloco').style.display = 'none';
  $('blocoResetarSenha').style.display = 'none';
  $('senhaTempResultado').innerHTML = '';
  document.getElementById('painelLateral').dataset.novo = '1';
  abrirPainel('Novo usuário');
});

async function abrirEdicaoUsuario(id) {
  try {
    const u = await Api.get('/usuarios/' + id);
    idUsuarioAtual = id;
    $('campoNome').value = u.nome || '';
    $('campoLogin').value = u.login || '';
    $('campoLogin').disabled = true; // login não muda depois de criado
    $('campoEmail').value = u.email || '';
    $('campoPerfil').value = u.id_perfil;
    $('campoSenhaInicialBloco').style.display = 'none';
    $('campoAtivoBloco').style.display = 'block';
    $('campoAtivo').checked = u.ativo;
    $('blocoResetarSenha').style.display = 'block';
    $('senhaTempResultado').innerHTML = '';
    document.getElementById('painelLateral').dataset.novo = '0';
    abrirPainel(`Editar usuário · ${u.login}`);
  } catch (e) { mostrarToast(e.message); }
}

$('btnSalvarUsuario').addEventListener('click', async () => {
  if (!$('formUsuario').reportValidity()) return;

  const botao = $('btnSalvarUsuario');
  botao.disabled = true;
  botao.textContent = 'Salvando...';

  try {
    if (idUsuarioAtual) {
      await Api.put('/usuarios/' + idUsuarioAtual, {
        nome: $('campoNome').value.trim(),
        email: $('campoEmail').value.trim(),
        id_perfil: Number($('campoPerfil').value),
        ativo: $('campoAtivo').checked ? '1' : '0',
      });
      mostrarToast('Usuário atualizado.');
    } else {
      if ($('campoSenhaInicial').value.length < 10) {
        mostrarToast('A senha inicial precisa ter pelo menos 10 caracteres.');
        return;
      }
      await Api.post('/usuarios', {
        nome: $('campoNome').value.trim(),
        login: $('campoLogin').value.trim(),
        email: $('campoEmail').value.trim(),
        id_perfil: Number($('campoPerfil').value),
        senha_inicial: $('campoSenhaInicial').value,
      });
      mostrarToast('Usuário cadastrado.');
    }
    fecharPainel();
    carregarUsuarios();
  } catch (e) {
    mostrarToast(e.message);
  } finally {
    botao.disabled = false;
    botao.textContent = 'Salvar usuário';
  }
});

$('btnResetarSenha').addEventListener('click', async () => {
  if (!idUsuarioAtual || !confirm('Gerar uma nova senha temporária para este usuário?')) return;
  try {
    const r = await Api.post(`/usuarios/${idUsuarioAtual}/resetar-senha`, {});
    $('senhaTempResultado').innerHTML = `
      <div class="senha-temp">
        Nova senha temporária: <strong>${escaparHtml(r.senha_temporaria)}</strong><br>
        <span style="font-size:12px;">Repasse para o usuário por fora do sistema - ela só aparece aqui uma vez.
        Ele será obrigado a trocar no próximo login.</span>
      </div>`;
    carregarUsuarios();
  } catch (e) { mostrarToast(e.message); }
});

// ================================================================= PERFIS & PERMISSÕES
$('selPerfilAtivo').addEventListener('change', carregarPermissoesDoPerfilSelecionado);

async function carregarPermissoesDoPerfilSelecionado() {
  const idPerfil = $('selPerfilAtivo').value;
  if (!idPerfil) { $('corpoPermissoes').innerHTML = ''; return; }

  try {
    const r = await Api.get(`/perfis/${idPerfil}/permissoes`);
    // modulos em ordem alfabetica pelo nome que aparece na tela
    const rotulo = (l) => RÓTULOS_MODULO[l.modulo] || l.modulo;
    const ordenados = r.dados.slice().sort((a, b) => rotulo(a).localeCompare(rotulo(b), 'pt-BR', { sensitivity: 'base' }));
    $('corpoPermissoes').innerHTML = ordenados.map((linha) => `
      <tr data-modulo="${linha.modulo}">
        <td>${RÓTULOS_MODULO[linha.modulo] || linha.modulo}</td>
        <td class="centro"><input type="checkbox" data-acao="pode_ver" ${linha.pode_ver ? 'checked' : ''}></td>
        <td class="centro"><input type="checkbox" data-acao="pode_incluir" ${linha.pode_incluir ? 'checked' : ''}></td>
        <td class="centro"><input type="checkbox" data-acao="pode_editar" ${linha.pode_editar ? 'checked' : ''}></td>
        <td class="centro"><input type="checkbox" data-acao="pode_excluir" ${linha.pode_excluir ? 'checked' : ''}></td>
      </tr>`).join('');
  } catch (e) { mostrarToast(e.message); }
}

$('btnSalvarPermissoes').addEventListener('click', async () => {
  const idPerfil = $('selPerfilAtivo').value;
  if (!idPerfil) return;

  const permissoes = Array.from($('corpoPermissoes').querySelectorAll('tr[data-modulo]')).map((tr) => ({
    modulo: tr.dataset.modulo,
    pode_ver: tr.querySelector('[data-acao="pode_ver"]').checked,
    pode_incluir: tr.querySelector('[data-acao="pode_incluir"]').checked,
    pode_editar: tr.querySelector('[data-acao="pode_editar"]').checked,
    pode_excluir: tr.querySelector('[data-acao="pode_excluir"]').checked,
  }));

  try {
    await Api.put(`/perfis/${idPerfil}/permissoes`, { permissoes });
    mostrarToast('Permissões salvas. O usuário precisa entrar de novo (ou trocar de tela) para valerem.');
  } catch (e) { mostrarToast(e.message); }
});

$('btnNovoPerfil').addEventListener('click', async () => {
  const nome = prompt('Nome do novo perfil:');
  if (!nome || !nome.trim()) return;
  try {
    await Api.post('/perfis', { nome: nome.trim(), descricao: '' });
    mostrarToast('Perfil criado.');
    await carregarListaPerfis();
    $('selPerfilAtivo').value = perfis[perfis.length - 1].id_perfil;
    carregarPermissoesDoPerfilSelecionado();
  } catch (e) { mostrarToast(e.message); }
});

$('btnRenomearPerfil').addEventListener('click', async () => {
  const idPerfil = $('selPerfilAtivo').value;
  const atual = perfis.find((p) => String(p.id_perfil) === idPerfil);
  if (!atual) return;
  const nome = prompt('Novo nome do perfil:', atual.nome);
  if (!nome || !nome.trim()) return;
  try {
    await Api.put(`/perfis/${idPerfil}`, { nome: nome.trim(), descricao: atual.descricao || '' });
    mostrarToast('Perfil renomeado.');
    await carregarListaPerfis();
    $('selPerfilAtivo').value = idPerfil;
  } catch (e) { mostrarToast(e.message); }
});

$('btnExcluirPerfil').addEventListener('click', async () => {
  const idPerfil = $('selPerfilAtivo').value;
  if (!idPerfil || !confirm('Excluir este perfil? Só é possível se não houver usuários nele.')) return;
  try {
    await Api.del(`/perfis/${idPerfil}`);
    mostrarToast('Perfil excluído.');
    await carregarListaPerfis();
    carregarPermissoesDoPerfilSelecionado();
  } catch (e) { mostrarToast(e.message); }
});

// ---------------------------------------------------------------- início
(async () => {
  await carregarListaPerfis();
  carregarUsuarios();
})();
