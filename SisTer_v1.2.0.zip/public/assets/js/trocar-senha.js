exigirLogin();

const usuario = Api.usuario();
const obrigatorio = usuario && usuario.precisa_trocar_senha;

if (obrigatorio) {
  document.getElementById('avisoObrigatorio').style.display = 'block';
  document.getElementById('subtitulo').textContent = 'Primeiro acesso: defina uma senha só sua.';
} else {
  // troca voluntária (usuário já logado, veio por escolha própria) - pode voltar
  document.getElementById('btnCancelar').style.display = 'block';
  document.getElementById('btnCancelar').addEventListener('click', () => { window.location.href = 'index.html'; });
}

document.getElementById('formTrocarSenha').addEventListener('submit', async (ev) => {
  ev.preventDefault();

  const msgErro = document.getElementById('msgErro');
  msgErro.style.display = 'none';

  const nova = document.getElementById('senhaNova').value;
  const confirma = document.getElementById('senhaConfirma').value;

  if (nova !== confirma) {
    msgErro.textContent = 'A confirmação não bate com a nova senha.';
    msgErro.style.display = 'block';
    return;
  }

  const btn = document.getElementById('btnSalvar');
  btn.disabled = true;
  btn.textContent = 'Salvando...';

  try {
    const r = await Api.put('/auth/trocar-senha', {
      senha_atual: document.getElementById('senhaAtual').value,
      senha_nova: nova,
    });

    // trocar a senha encerra as sessões antigas (inclusive esta): o servidor devolve um token novo
    if (r && r.token) localStorage.setItem('sister_token', r.token);

    // atualiza a sessão local pra não pedir troca de novo
    if (usuario) {
      usuario.precisa_trocar_senha = false;
      localStorage.setItem('sister_usuario', JSON.stringify(usuario));
    }

    window.location.href = 'index.html';
  } catch (e) {
    msgErro.textContent = e.message || 'Não foi possível trocar a senha.';
    msgErro.style.display = 'block';
    btn.disabled = false;
    btn.textContent = 'Salvar nova senha';
  }
});
