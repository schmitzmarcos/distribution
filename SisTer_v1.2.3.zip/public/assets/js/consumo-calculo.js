// =========================================================================
// SisTer - Consumo da frota: calculos do painel (sem tela, sem rede).
// Entrada: veiculos e abastecimentos de GET /api/consumo-frota. Saida: uma linha por veiculo com km/l,
// comparacao com o periodo anterior e com o mesmo modelo, Arla, custo por km e alertas.
// Testado em tests/consumo-calculo.test.js (node tests/consumo-calculo.test.js).
// =========================================================================
(function (raiz) {
  'use strict';

  // km/l fora desta faixa e quase certo erro de digitacao (KM ou litros): a linha fica fora da media
  const KML_MIN = 0.5;
  const KML_MAX = 25;
  const LIMITE_QUEDA = 0.15;    // alerta se o km/l cair 15% ou mais frente ao periodo anterior
  const LIMITE_MODELO = 0.15;   // alerta se ficar 15% ou mais abaixo dos outros veiculos do mesmo modelo
  const MIN_LINHAS_COMPARAR = 2; // linhas validas em cada periodo para comparar (uma so oscila demais)
  const MIN_OUTROS_MODELO = 2;   // outros veiculos do mesmo modelo, com dados, para alertar

  const num = (v) => (v == null || v === '' || !isFinite(Number(v)) ? 0 : Number(v));
  const norm = (s) => String(s == null ? '' : s).trim().toLowerCase().replace(/\s+/g, ' ');
  const dia = (s) => String(s == null ? '' : s).slice(0, 10);

  function addDias(iso, n) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
    if (!m) return '';
    const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3] + n));
    return d.getUTCFullYear() + '-' + String(d.getUTCMonth() + 1).padStart(2, '0') + '-' + String(d.getUTCDate()).padStart(2, '0');
  }

  // 'atual' = ultimos N dias (hoje incluido) · 'anterior' = os N dias antes desses · null = fora
  function periodoDe(data, hoje, dias) {
    const d = dia(data);
    if (!d || d > hoje) return null;
    if (d > addDias(hoje, -dias)) return 'atual';
    if (d > addDias(hoje, -2 * dias)) return 'anterior';
    return null;
  }

  function resumir(linhas) {
    const r = {
      n: 0, litros: 0, kmRod: 0, litrosValidos: 0, nValidos: 0, descartados: 0,
      arla: 0, nArla: 0, litrosComArla: 0, arlaValidos: 0,
    };
    linhas.forEach((a) => {
      const litros = num(a.litros);
      const arla = num(a.litros_arla);
      r.n++;
      r.litros += litros;
      if (arla > 0) { r.arla += arla; r.nArla++; r.litrosComArla += litros; }
      const ki = num(a.km_inicial);
      const kf = num(a.km_final);
      if (ki > 0 && kf > ki && litros > 0) {
        const media = (kf - ki) / litros;
        if (media >= KML_MIN && media <= KML_MAX) {
          r.kmRod += kf - ki; r.litrosValidos += litros; r.nValidos++;
          if (arla > 0) r.arlaValidos += arla;
        } else {
          r.descartados++;
        }
      }
    });
    r.kml = r.litrosValidos > 0 ? r.kmRod / r.litrosValidos : null;
    // Arla em % do combustivel, so sobre os abastecimentos em que o Arla foi informado
    r.arlaPct = r.litrosComArla > 0 ? (r.arla / r.litrosComArla) * 100 : null;
    return r;
  }

  const arred = (n) => Math.round(n);

  function calcular(entrada) {
    const hoje = entrada.hoje;
    const dias = entrada.dias;
    const precoComb = num(entrada.precoComb);
    const precoArla = num(entrada.precoArla);
    const veiculos = entrada.veiculos || [];

    const porVeiculo = {};
    (entrada.abastecimentos || []).forEach((a) => {
      const p = periodoDe(a.data, hoje, dias);
      if (!p) return;
      const k = a.id_veiculo;
      if (!porVeiculo[k]) porVeiculo[k] = { atual: [], anterior: [] };
      porVeiculo[k][p].push(a);
    });

    const linhas = veiculos.map((v) => {
      const g = porVeiculo[v.id_veiculo] || { atual: [], anterior: [] };
      const modeloChave = norm(v.marca) || norm(v.modelo) ? norm(v.marca) + '|' + norm(v.modelo) : '';
      return { v, modeloChave, atual: resumir(g.atual), anterior: resumir(g.anterior), alertas: [] };
    });

    linhas.forEach((l) => {
      // variacao do km/l frente ao periodo anterior
      l.variacao = null;
      if (l.atual.kml && l.anterior.kml) l.variacao = (l.atual.kml / l.anterior.kml - 1) * 100;

      // os OUTROS veiculos do mesmo modelo (marca + modelo): media ponderada por litros
      l.modelo = null;
      if (l.modeloChave && l.atual.kml) {
        const outros = linhas.filter((o) => o !== l && o.modeloChave === l.modeloChave && o.atual.kml);
        if (outros.length) {
          const km = outros.reduce((s, o) => s + o.atual.kmRod, 0);
          const lt = outros.reduce((s, o) => s + o.atual.litrosValidos, 0);
          const ref = km / lt;
          l.modelo = { kml: ref, outros: outros.length, dif: (l.atual.kml / ref - 1) * 100 };
        }
      }

      // custo estimado por km (preco do litro informado na tela)
      l.custoKm = null;
      if (precoComb > 0 && l.atual.kmRod > 0) {
        l.custoKm = (l.atual.litrosValidos * precoComb + (precoArla > 0 ? l.atual.arlaValidos * precoArla : 0)) / l.atual.kmRod;
      }

      // alertas
      if (l.variacao != null && l.atual.nValidos >= MIN_LINHAS_COMPARAR && l.anterior.nValidos >= MIN_LINHAS_COMPARAR &&
          l.variacao <= -LIMITE_QUEDA * 100) {
        l.alertas.push({ tipo: 'queda', texto: 'Média caiu ' + arred(-l.variacao) + '% frente aos ' + dias + ' dias anteriores' });
      }
      if (l.modelo && l.modelo.outros >= MIN_OUTROS_MODELO && l.modelo.dif <= -LIMITE_MODELO * 100) {
        l.alertas.push({ tipo: 'modelo', texto: arred(-l.modelo.dif) + '% abaixo dos outros ' + [l.v.marca, l.v.modelo].filter(Boolean).join(' ') });
      }
      // o Arla so vira alerta se o veiculo ja usava no periodo anterior (nem todo veiculo usa Arla)
      if (l.anterior.nArla > 0 && l.atual.n >= MIN_LINHAS_COMPARAR && l.atual.nArla === 0) {
        l.alertas.push({ tipo: 'arla', texto: 'Sem Arla neste período (no anterior havia)' });
      }
    });

    const soma = (f) => linhas.reduce((s, l) => s + f(l), 0);
    const kmTotal = soma((l) => l.atual.kmRod);
    const litrosValidos = soma((l) => l.atual.litrosValidos);
    const total = {
      veiculos: linhas.length,
      comDados: linhas.filter((l) => l.atual.n > 0).length,
      kmRod: kmTotal,
      kml: litrosValidos > 0 ? kmTotal / litrosValidos : null,
      litros: soma((l) => l.atual.litros),
      arla: soma((l) => l.atual.arla),
      descartados: soma((l) => l.atual.descartados),
      emAlerta: linhas.filter((l) => l.alertas.length).length,
    };
    return { linhas, total };
  }

  const API = { calcular, resumir, periodoDe, addDias, KML_MIN, KML_MAX };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else raiz.ConsumoCalculo = API;
})(typeof window !== 'undefined' ? window : this);
