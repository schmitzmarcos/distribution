// Painel de consumo da frota: km/l, Arla e custo por km (GET /api/consumo-frota).
// Os calculos ficam em consumo-calculo.js (ConsumoCalculo), que tem teste proprio.
exigirLogin();

const $ = (id) => document.getElementById(id);

const usuarioLogado = Api.usuario();
if (usuarioLogado) {
  $('nomeUsuario').textContent = usuarioLogado.nome;
  $('perfilUsuario').textContent = usuarioLogado.perfil;
  $('avatarUsuario').textContent = usuarioLogado.nome.charAt(0).toUpperCase();
  if (usuarioLogado.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML;
}
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3600);
}

const fmtNum = (n, dec) => Number(n).toLocaleString('pt-BR', { maximumFractionDigits: dec == null ? 0 : dec, minimumFractionDigits: dec == null ? 0 : dec });
const fmtMoeda = (n) => 'R$ ' + Number(n).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const semAcento = (t) => String(t == null ? '' : t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const VAZIO = '<span class="nota">—</span>';

// "6,29" ou "6.29" -> 6.29 · vazio ou invalido -> 0
function lerPreco(s) {
  s = String(s == null ? '' : s).trim().replace(/\s/g, '');
  if (!s) return 0;
  if (s.indexOf(',') >= 0) s = s.replace(/\./g, '').replace(',', '.');
  const n = Number(s);
  return isFinite(n) && n > 0 ? n : 0;
}

const CHAVE_PRECOS = 'sister_consumo_precos';
function lerPrecosGuardados() {
  try { return JSON.parse(localStorage.getItem(CHAVE_PRECOS) || '{}') || {}; } catch (e) { return {}; }
}
function guardarPrecos() {
  try { localStorage.setItem(CHAVE_PRECOS, JSON.stringify({ comb: $('fPrecoComb').value, arla: $('fPrecoArla').value })); } catch (e) { /* sem espaco: segue sem guardar */ }
}

let dados = null;   // resposta do servidor
const filtros = { dias: 90, ordem: 'alerta', busca: '', soAlerta: false };

async function carregar() {
  try {
    dados = await Api.get('/consumo-frota?dias=' + filtros.dias);
  } catch (e) {
    mostrarToast(e.message);
    $('corpo').innerHTML = '';
    $('vazioTitulo').textContent = 'Não foi possível carregar';
    $('vazioTexto').textContent = e.message;
    $('vazio').style.display = 'block';
    return;
  }
  renderizar();
}

function celulaVariacao(pct) {
  if (pct == null) return VAZIO;
  const r = Math.round(pct);
  if (r === 0) return '0%';
  return r < 0 ? '<span class="var-neg">▼ ' + fmtNum(-r) + '%</span>' : '<span class="var-pos">▲ ' + fmtNum(r) + '%</span>';
}

function ordenar(linhas) {
  const num = (l) => l.v.numero;
  const por = {
    alerta: (a, b) => (b.alertas.length - a.alertas.length) || ((b.atual.n > 0) - (a.atual.n > 0)) || (num(a) - num(b)),
    numero: (a, b) => num(a) - num(b),
    kml: (a, b) => (a.atual.kml == null) - (b.atual.kml == null) || (a.atual.kml - b.atual.kml) || (num(a) - num(b)),
    litros: (a, b) => (b.atual.litros - a.atual.litros) || (num(a) - num(b)),
  };
  return linhas.slice().sort(por[filtros.ordem] || por.alerta);
}

function renderizar() {
  if (!dados) return;
  const res = ConsumoCalculo.calcular({
    veiculos: dados.veiculos, abastecimentos: dados.abastecimentos, hoje: dados.hoje, dias: dados.dias,
    precoComb: lerPreco($('fPrecoComb').value), precoArla: lerPreco($('fPrecoArla').value),
  });
  const t = res.total;
  $('geradoEm').textContent = 'Consumo da frota em ' + new Date().toLocaleDateString('pt-BR') + ' (últimos ' + dados.dias + ' dias)';

  $('kKm').textContent = t.kmRod > 0 ? fmtNum(t.kmRod) : '—';
  $('kMedia').textContent = t.kml != null ? fmtNum(t.kml, 2) : '—';
  $('kComb').textContent = t.litros > 0 ? fmtNum(t.litros) : '—';
  $('kArla').textContent = t.arla > 0 ? fmtNum(t.arla) : '—';
  $('kAlerta').textContent = t.emAlerta;

  const termo = semAcento(filtros.busca.trim());
  let linhas = res.linhas.filter((l) =>
    (!filtros.soAlerta || l.alertas.length) &&
    (!termo || semAcento([l.v.numero, l.v.placa, l.v.marca, l.v.modelo].join(' ')).includes(termo)));
  linhas = ordenar(linhas);

  const corpo = $('corpo');
  corpo.innerHTML = '';
  linhas.forEach((l) => {
    const a = l.atual;
    const v = l.v;
    const sem = a.n === 0;
    const marcaMod = [v.marca, v.modelo].filter(Boolean).join(' ');
    const aviso = a.descartados > 0
      ? ` <span class="nota" title="${a.descartados} lançamento(s) com média impossível ficaram fora da conta">*</span>` : '';
    const arla = a.arla > 0
      ? fmtNum(a.arla) + (a.arlaPct != null ? ` <span class="nota">· ${fmtNum(a.arlaPct, 1)}%</span>` : '') : VAZIO;
    const alertas = l.alertas.length
      ? '<div class="alertas-celula">' + l.alertas.map((x) => `<span class="badge badge-alerta">${escaparHtml(x.texto)}</span>`).join('') + '</div>'
      : (sem ? '<span class="nota">Sem abastecimento no período</span>' : '<span class="nota">—</span>');
    const modelo = l.modelo
      ? celulaVariacao(l.modelo.dif) + ` <span class="nota" title="Média dos outros ${l.modelo.outros} do mesmo modelo">(${fmtNum(l.modelo.kml, 2)})</span>` : VAZIO;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>Veículo ${escaparHtml(v.numero)}</strong> <span class="placa">${escaparHtml(v.placa)}</span><div class="nota">${escaparHtml(marcaMod)}</div></td>
      <td class="n">${a.kmRod > 0 ? fmtNum(a.kmRod) : '—'}</td>
      <td class="n">${a.litros > 0 ? fmtNum(a.litros) : '—'}</td>
      <td class="n">${a.kml != null ? '<strong>' + fmtNum(a.kml, 2) + '</strong>' + aviso : '—'}</td>
      <td class="n">${celulaVariacao(l.variacao)}</td>
      <td class="n">${modelo}</td>
      <td class="n">${arla}</td>
      <td class="n">${l.custoKm != null ? fmtMoeda(l.custoKm) : '—'}</td>
      <td>${alertas}</td>`;
    tr.addEventListener('click', () => { window.location.href = 'frota.html'; });
    corpo.appendChild(tr);
  });

  const vazio = linhas.length === 0;
  $('vazio').style.display = vazio ? 'block' : 'none';
  if (vazio) {
    const filtrando = filtros.soAlerta || termo;
    $('vazioTitulo').textContent = filtrando ? 'Nada encontrado' : 'Nenhum veículo ativo';
    $('vazioTexto').textContent = filtrando ? 'Nenhum veículo combina com o filtro.' : 'Cadastre veículos em Frota para acompanhar o consumo.';
  }

  const nota = $('notaDescartados');
  nota.style.display = t.descartados > 0 ? '' : 'none';
  nota.textContent = t.descartados > 0
    ? `${t.descartados} ${t.descartados === 1 ? 'lançamento ficou' : 'lançamentos ficaram'} fora da conta por ter média impossível (marcados com *). Confira o KM e os litros na aba Abastecimento da Frota.`
    : '';
}

const guardados = lerPrecosGuardados();
$('fPrecoComb').value = guardados.comb || '';
$('fPrecoArla').value = guardados.arla || '';

$('fPeriodo').addEventListener('change', (ev) => { filtros.dias = Number(ev.target.value); carregar(); });
$('fOrdem').addEventListener('change', (ev) => { filtros.ordem = ev.target.value; renderizar(); });
$('fBusca').addEventListener('input', (ev) => { filtros.busca = ev.target.value; renderizar(); });
$('fSoAlerta').addEventListener('change', (ev) => { filtros.soAlerta = ev.target.checked; renderizar(); });
['fPrecoComb', 'fPrecoArla'].forEach((id) => $(id).addEventListener('input', () => { guardarPrecos(); renderizar(); }));
$('btnImprimir').addEventListener('click', () => window.print());

carregar();
