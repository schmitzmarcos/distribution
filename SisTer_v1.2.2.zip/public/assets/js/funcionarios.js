exigirLogin();

const $ = (id) => document.getElementById(id);

const usuario = Api.usuario();
if (usuario) {
  $('nomeUsuario').textContent = usuario.nome;
  $('perfilUsuario').textContent = usuario.perfil;
  $('avatarUsuario').textContent = usuario.nome.charAt(0).toUpperCase();
  if (usuario.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

// --- Estado da tela ---
let paginaAtual = 1;
const itensPorPagina = 20;
let termoBusca = '';
let somenteAtivos = true;
let carregandoLista = false;
let temporizadorBusca = null;
let idAtual = null;
let veiculosFrota = [];

const corpoTabela = $('corpoTabela');
const estadoVazio = $('estadoVazio');
const contadorFuncionarios = $('contadorFuncionarios');
const textoPaginacao = $('textoPaginacao');
const btnAnterior = $('btnAnterior');
const btnProximo = $('btnProximo');

function escaparHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto || '';
  return div.innerHTML;
}

function mostrarToast(mensagem) {
  const toast = $('avisoToast');
  toast.textContent = mensagem;
  toast.classList.add('visivel');
  setTimeout(() => toast.classList.remove('visivel'), 2600);
}

function statusVencimento(dataISO, rotulo) {
  if (!dataISO) return null;
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  const venc = new Date(dataISO + 'T00:00:00');
  const diffDias = Math.round((venc - hoje) / 86400000);
  if (diffDias < 0) return { texto: `${rotulo} vencida`, classe: 'badge-perigo' };
  if (diffDias <= 30) return { texto: `${rotulo} vence em ${diffDias}d`, classe: 'badge-alerta' };
  return null;
}

function renderizarBadgesVencimento(f) {
  const badges = [
    statusVencimento(f.data_vencimento_cnh, 'CNH'),
    statusVencimento(f.data_vencimento_exame_saude, 'Exame'),
  ].filter(Boolean);
  if (badges.length === 0) return '<span style="color:var(--tinta-suave); font-size:12.5px;">Em dia</span>';
  return badges.map((b) => `<span class="badge ${b.classe}">${b.texto}</span>`).join(' ');
}

async function carregarFuncionarios() {
  if (carregandoLista) return;
  carregandoLista = true;
  try {
    const query = new URLSearchParams({
      busca: termoBusca,
      somente_ativos: somenteAtivos ? '1' : '0',
      pagina: paginaAtual,
      itens_por_pagina: itensPorPagina,
    });
    const resp = await Api.get('/funcionarios?' + query.toString());
    corpoTabela.innerHTML = '';

    if (resp.dados.length === 0) {
      estadoVazio.style.display = 'block';
    } else {
      estadoVazio.style.display = 'none';
      resp.dados.forEach((f) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td class="cod">${f.id_funcionario}</td>
          <td><strong>${escaparHtml(f.nome)}</strong>${f.apelido ? '<br><span style="color:var(--tinta-suave); font-size:12.5px;">"' + escaparHtml(f.apelido) + '"</span>' : ''}</td>
          <td>${escaparHtml(formatarCpfCnpj(f.cpf)) || '—'}</td>
          <td>${escaparHtml(f.tipo) || '—'}</td>
          <td>${escaparHtml(f.telefone_celular) || '—'}</td>
          <td><span class="badge ${f.situacao === 'A' ? 'badge-ativo' : 'badge-inativo'}">${f.situacao === 'A' ? 'Ativo' : 'Inativo'}</span></td>
          <td><div class="badges-vencimento">${renderizarBadgesVencimento(f)}</div></td>
        `;
        tr.addEventListener('click', () => abrirPainelEdicao(f.id_funcionario));
        corpoTabela.appendChild(tr);
      });
    }

    const totalPaginas = Math.max(1, Math.ceil(resp.total / itensPorPagina));
    contadorFuncionarios.textContent = resp.total + (resp.total === 1 ? ' funcionário cadastrado' : ' funcionários cadastrados');
    textoPaginacao.textContent = `Página ${paginaAtual} de ${totalPaginas}`;
    btnAnterior.disabled = paginaAtual <= 1;
    btnProximo.disabled = paginaAtual >= totalPaginas;
  } catch (e) {
    mostrarToast(e.message);
  } finally {
    carregandoLista = false;
  }
}

$('campoBusca').addEventListener('input', (ev) => {
  clearTimeout(temporizadorBusca);
  temporizadorBusca = setTimeout(() => {
    termoBusca = ev.target.value;
    paginaAtual = 1;
    carregarFuncionarios();
  }, 350);
});
$('checkSomenteAtivos').addEventListener('change', (ev) => {
  somenteAtivos = ev.target.checked;
  paginaAtual = 1;
  carregarFuncionarios();
});
btnAnterior.addEventListener('click', () => { paginaAtual--; carregarFuncionarios(); });
btnProximo.addEventListener('click', () => { paginaAtual++; carregarFuncionarios(); });

// ---------------------------------------------------------------- CPF (mesmo padrão de Clientes/Agenda)
const campoCpf = $('campoCpf');
const erroCpf = $('erroCpf');

campoCpf.addEventListener('input', (ev) => {
  const posicaoAntes = ev.target.selectionStart;
  const tamanhoAntes = ev.target.value.length;
  const digitos = somenteDigitos(ev.target.value).slice(0, 11);
  ev.target.value = formatarCpfCnpj(digitos);
  const diferenca = ev.target.value.length - tamanhoAntes;
  const novaPosicao = Math.max(0, posicaoAntes + diferenca);
  ev.target.setSelectionRange(novaPosicao, novaPosicao);
  limparErroCpf();
});

function limparErroCpf() {
  campoCpf.classList.remove('campo-invalido');
  erroCpf.style.display = 'none';
}
function mostrarErroCpf(mensagem) {
  campoCpf.classList.add('campo-invalido');
  erroCpf.textContent = mensagem;
  erroCpf.style.display = 'block';
}
campoCpf.addEventListener('blur', () => {
  const digitos = somenteDigitos(campoCpf.value);
  if (digitos.length === 0) { limparErroCpf(); return; }
  if (digitos.length !== 11) { mostrarErroCpf('CPF precisa ter 11 dígitos.'); return; }
  if (!validarCPF(campoCpf.value)) { mostrarErroCpf('CPF inválido.'); return; }
  limparErroCpf();
});

// ---------------------------------------------------------------- Foto (upload + redimensionamento)
$('campoFotoArquivo').addEventListener('change', (ev) => {
  const arquivo = ev.target.files[0];
  if (!arquivo) return;

  const leitor = new FileReader();
  leitor.onload = (e) => {
    const img = new Image();
    img.onload = () => {
      const MAX = 320;
      let { width, height } = img;
      if (width > height && width > MAX) { height *= MAX / width; width = MAX; }
      else if (height > MAX) { width *= MAX / height; height = MAX; }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      canvas.getContext('2d').drawImage(img, 0, 0, width, height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);

      $('campoFotoBase64').value = dataUrl;
      aplicarPreviewFoto(dataUrl);
      marcarAlterado();
    };
    img.src = e.target.result;
  };
  leitor.readAsDataURL(arquivo);
});

function aplicarPreviewFoto(dataUrlOuVazio) {
  const img = $('previewFoto');
  const vazia = $('fotoVazia');
  $('btnRemoverFoto').style.display = dataUrlOuVazio ? '' : 'none';
  if (dataUrlOuVazio) {
    img.src = dataUrlOuVazio;
    img.style.display = 'block';
    vazia.style.display = 'none';
  } else {
    img.removeAttribute('src');
    img.style.display = 'none';
    vazia.style.display = 'flex';
  }
}

// Remover foto: limpa o preview e o valor enviado; a foto so e apagada de fato ao clicar em Salvar
$('btnRemoverFoto').addEventListener('click', () => {
  $('campoFotoArquivo').value = '';
  $('campoFotoBase64').value = '';
  aplicarPreviewFoto('');
  mostrarToast('Foto removida. Clique em Salvar para confirmar.');
});

// Clicar na foto (ou Enter/Espaço com ela focada) abre a seleção de arquivo
$('fotoClicavel').addEventListener('click', () => $('campoFotoArquivo').click());
$('fotoClicavel').addEventListener('keydown', (ev) => {
  if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); $('campoFotoArquivo').click(); }
});

// ---------------------------------------------------------------- abas do painel
let abaAtual = 'pessoais';
function ativarAba(nome) {
  abaAtual = nome;
  document.querySelectorAll('#abas .aba').forEach((b) => b.classList.toggle('ativa', b.dataset.aba === nome));
  document.querySelectorAll('.painel-corpo [data-pane]').forEach((p) =>
    p.classList.toggle('ativo', p.dataset.pane === nome));
  if (nome === 'historico') renderHistorico();
}
document.querySelectorAll('#abas .aba').forEach((b) => b.addEventListener('click', () => ativarAba(b.dataset.aba)));

// ---------------------------------------------------------------- painel: abrir/fechar
const painelFundo = $('painelFundo');
const painelLateral = $('painelLateral');

let alterado = false;
const marcarAlterado = () => { alterado = true; };
$('formFuncionario').addEventListener('input', marcarAlterado);
$('formFuncionario').addEventListener('change', marcarAlterado);

function abrirPainel(titulo) {
  $('tituloPainel').textContent = titulo;
  alterado = false;
  painelFundo.classList.add('aberto');
  painelLateral.classList.add('aberto');
}
function fecharPainel() {
  alterado = false;
  painelFundo.classList.remove('aberto');
  painelLateral.classList.remove('aberto');
}
// Cancelar, ✕ e clique no fundo: pedem confirmação se houver alterações não salvas
function tentarFecharPainel() {
  if (alterado && !confirm('Há alterações não salvas. Deseja descartá-las e fechar?')) return;
  fecharPainel();
}
$('btnFecharPainel').addEventListener('click', tentarFecharPainel);
$('btnCancelarPainel').addEventListener('click', tentarFecharPainel);
painelFundo.addEventListener('click', tentarFecharPainel);

const camposTexto = [
  'campoNome', 'campoApelido', 'campoRg', 'campoDataExpedicaoRg', 'campoDataNascimento',
  'campoTelefoneResidencial', 'campoTelefoneCelular', 'campoEmail', 'campoEndereco', 'campoCidade',
  'campoUf', 'campoCep', 'campoNomeMae', 'campoNomePai', 'campoNomeConjuge',
  'campoContatoEmergenciaNome', 'campoContatoEmergenciaTelefone', 'campoContatoEmergenciaEndereco',
  'campoDataAdmissao', 'campoDataRescisao', 'campoNumeroMei', 'campoObservacoes', 'campoNumeroCnh',
  'campoDataVencimentoCnh', 'campoDataVencimentoCnhInternacional', 'campoDataVencimentoExameSaude',
  'campoDataVencimentoSenac', 'campoCelularPlano', 'campoCelularModelo', 'campoNumeroChip',
  'campoCelularDataEntrega', 'campoCelularDataDevolucao', 'campoEstadoCivil', 'campoGrauEscolaridade',
];
const camposNumero = ['campoQtdFilhos', 'campoNumeroRegistro', 'campoSalario'];

function limparFormulario() {
  camposTexto.forEach((id) => { $(id).value = ''; });
  camposNumero.forEach((id) => { $(id).value = ''; });
  $('campoTipo').value = 'Motorista';
  $('campoSituacao').value = 'A';
  $('campoFotoArquivo').value = '';
  $('campoFotoBase64').value = '';
  aplicarPreviewFoto('');
  limparErroCpf();
  campoCpf.value = '';
}

$('btnNovo').addEventListener('click', () => {
  idAtual = null;
  limparFormulario();
  ativarAba('pessoais');
  document.getElementById('painelLateral').dataset.novo = '1';
  abrirPainel('Novo funcionário');
});

async function abrirPainelEdicao(id) {
  try {
    const f = await Api.get('/funcionarios/' + id);
    idAtual = id;

    $('campoNome').value = f.nome || '';
    $('campoApelido').value = f.apelido || '';
    campoCpf.value = formatarCpfCnpj(f.cpf || '');
    $('campoRg').value = f.rg || '';
    $('campoDataExpedicaoRg').value = f.data_expedicao_rg || '';
    $('campoDataNascimento').value = f.data_nascimento || '';
    $('campoEstadoCivil').value = f.estado_civil || '';
    $('campoGrauEscolaridade').value = f.grau_escolaridade || '';

    $('campoTelefoneResidencial').value = f.telefone_residencial || '';
    $('campoTelefoneCelular').value = f.telefone_celular || '';
    $('campoEmail').value = f.email || '';
    $('campoEndereco').value = f.endereco || '';
    $('campoCidade').value = f.cidade || '';
    $('campoUf').value = f.uf || '';
    $('campoCep').value = f.cep || '';

    $('campoNomeMae').value = f.nome_mae || '';
    $('campoNomePai').value = f.nome_pai || '';
    $('campoNomeConjuge').value = f.nome_conjuge || '';
    $('campoQtdFilhos').value = f.qtd_filhos || '';

    $('campoContatoEmergenciaNome').value = f.contato_emergencia_nome || '';
    $('campoContatoEmergenciaTelefone').value = f.contato_emergencia_telefone || '';
    $('campoContatoEmergenciaEndereco').value = f.contato_emergencia_endereco || '';

    $('campoTipo').value = f.tipo || 'Motorista';
    $('campoNumeroRegistro').value = f.numero_registro || '';
    $('campoDataAdmissao').value = f.data_admissao || '';
    $('campoDataRescisao').value = f.data_rescisao || '';
    $('campoSalario').value = f.salario || '';
    $('campoNumeroMei').value = f.numero_mei || '';
    $('campoObservacoes').value = f.observacoes || '';
    $('campoSituacao').value = f.situacao || 'A';

    $('campoNumeroCnh').value = f.numero_cnh || '';
    $('campoDataVencimentoCnh').value = f.data_vencimento_cnh || '';
    $('campoDataVencimentoCnhInternacional').value = f.data_vencimento_cnh_internacional || '';
    $('campoDataVencimentoExameSaude').value = f.data_vencimento_exame_saude || '';
    $('campoDataVencimentoSenac').value = f.data_vencimento_senac || '';

    $('campoCelularPlano').value = f.celular_plano || '';
    $('campoCelularModelo').value = f.celular_modelo || '';
    $('campoNumeroChip').value = f.numero_chip || '';
    $('campoCelularDataEntrega').value = f.celular_data_entrega || '';
    $('campoCelularDataDevolucao').value = f.celular_data_devolucao || '';

    $('campoFotoArquivo').value = '';
    $('campoFotoBase64').value = f.foto || '';
    aplicarPreviewFoto(f.foto || '');

    limparErroCpf();
    ativarAba('pessoais');
    document.getElementById('painelLateral').dataset.novo = '0';
    abrirPainel(`Editar funcionário · cód. ${f.id_funcionario}`);
  } catch (e) {
    mostrarToast(e.message);
  }
}

function montarPayload() {
  return {
    nome: $('campoNome').value.trim(),
    apelido: $('campoApelido').value.trim(),
    cpf: somenteDigitos(campoCpf.value),
    rg: $('campoRg').value.trim(),
    data_expedicao_rg: $('campoDataExpedicaoRg').value,
    data_nascimento: $('campoDataNascimento').value,
    estado_civil: $('campoEstadoCivil').value,
    grau_escolaridade: $('campoGrauEscolaridade').value,

    telefone_residencial: $('campoTelefoneResidencial').value.trim(),
    telefone_celular: $('campoTelefoneCelular').value.trim(),
    email: $('campoEmail').value.trim(),
    endereco: $('campoEndereco').value.trim(),
    cidade: $('campoCidade').value.trim(),
    uf: $('campoUf').value.trim().toUpperCase(),
    cep: $('campoCep').value.trim(),

    nome_mae: $('campoNomeMae').value.trim(),
    nome_pai: $('campoNomePai').value.trim(),
    nome_conjuge: $('campoNomeConjuge').value.trim(),
    qtd_filhos: $('campoQtdFilhos').value === '' ? null : Number($('campoQtdFilhos').value),

    contato_emergencia_nome: $('campoContatoEmergenciaNome').value.trim(),
    contato_emergencia_telefone: $('campoContatoEmergenciaTelefone').value.trim(),
    contato_emergencia_endereco: $('campoContatoEmergenciaEndereco').value.trim(),

    tipo: $('campoTipo').value,
    numero_registro: $('campoNumeroRegistro').value === '' ? null : Number($('campoNumeroRegistro').value),
    data_admissao: $('campoDataAdmissao').value,
    data_rescisao: $('campoDataRescisao').value,
    salario: $('campoSalario').value === '' ? null : Number($('campoSalario').value),
    numero_mei: $('campoNumeroMei').value.trim(),
    observacoes: $('campoObservacoes').value.trim(),
    situacao: $('campoSituacao').value || 'A',

    numero_cnh: $('campoNumeroCnh').value.trim(),
    data_vencimento_cnh: $('campoDataVencimentoCnh').value,
    data_vencimento_cnh_internacional: $('campoDataVencimentoCnhInternacional').value,
    data_vencimento_exame_saude: $('campoDataVencimentoExameSaude').value,
    data_vencimento_senac: $('campoDataVencimentoSenac').value,

    celular_plano: $('campoCelularPlano').value.trim(),
    celular_modelo: $('campoCelularModelo').value.trim(),
    numero_chip: $('campoNumeroChip').value.trim(),
    celular_data_entrega: $('campoCelularDataEntrega').value,
    celular_data_devolucao: $('campoCelularDataDevolucao').value,

    foto: $('campoFotoBase64').value,
  };
}

$('btnSalvarFuncionario').addEventListener('click', async () => {
  // Se o campo invalido esta numa aba escondida, o navegador nao consegue focar nem mostrar o aviso
  // ("An invalid form control is not focusable"). Por isso abre primeiro a aba do campo com problema.
  const invalido = $('formFuncionario').querySelector(':invalid');
  if (invalido) {
    const aba = invalido.closest('[data-pane]');
    ativarAba(aba ? aba.dataset.pane : 'pessoais');
    $('formFuncionario').reportValidity();
    return;
  }

  if (!validarCPF(campoCpf.value)) {
    mostrarErroCpf(somenteDigitos(campoCpf.value).length === 11 ? 'CPF inválido.' : 'CPF precisa ter 11 dígitos.');
    ativarAba('pessoais');
    campoCpf.focus();
    return;
  }

  const payload = montarPayload();
  const botao = $('btnSalvarFuncionario');
  botao.disabled = true;
  botao.textContent = 'Salvando...';

  try {
    if (idAtual) {
      await Api.put('/funcionarios/' + idAtual, payload);
      mostrarToast('Funcionário atualizado com sucesso.');
      fecharPainel();
    } else {
      const r = await Api.post('/funcionarios', payload);
      idAtual = r.id_funcionario;
      document.getElementById('painelLateral').dataset.novo = '0';
      alterado = false;
      if (abaAtual === 'historico') renderHistorico();
      $('tituloPainel').textContent = `Editar funcionário · cód. ${idAtual}`;
      mostrarToast('Funcionário cadastrado. Você já pode lançar o histórico.');
    }
    carregarFuncionarios();
  } catch (e) {
    mostrarToast(e.message);
  } finally {
    botao.disabled = false;
    botao.textContent = 'Salvar funcionário';
  }
});

// ---------------------------------------------------------------- Histórico (Viagens / Bonificações)
const fmtMoeda = (n) => (n == null || n === '' ? '—' : Number(n).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
const fmtNum = (n) => (n == null || n === '' || isNaN(n) ? '—' : Number(n).toLocaleString('pt-BR'));
function fmtData(iso) {
  if (!iso) return '—';
  const [a, m, d] = iso.split('-');
  return `${d}/${m}/${a}`;
}

const HIST = {
  bonificacoes: {
    rotulo: 'Bonificações', chave: 'id_bonificacao',
    colunas: [
      { k: 'data', t: 'Data', f: fmtData }, { k: 'descricao', t: 'Descrição' },
      { k: 'valor', t: 'Valor', f: fmtMoeda },
    ],
    campos: [
      { k: 'data', t: 'Data', tipo: 'date', req: true, hoje: true },
      { k: 'descricao', t: 'Descrição', tipo: 'text', req: true, cheio: true },
      { k: 'valor', t: 'Valor (R$)', tipo: 'number' },
    ],
  },
  horas: {
    rotulo: 'Viagens (horas)', chave: 'id_registro',
    colunas: [
      { k: 'data_saida', t: 'Saída', f: fmtData }, { k: 'hora_saida', t: 'Hora' },
      { k: 'placa_veiculo', t: 'Veículo' }, { k: 'km_inicial', t: 'KM inicial', f: fmtNum },
      { k: 'data_volta', t: 'Volta', f: fmtData }, { k: 'hora_volta', t: 'Hora' },
      { k: 'km_final', t: 'KM final', f: fmtNum },
    ],
    campos: [
      { k: 'data_saida', t: 'Data de saída', tipo: 'date', req: true, hoje: true },
      { k: 'hora_saida', t: 'Hora de saída', tipo: 'time' },
      { k: 'placa_veiculo', t: 'Veículo', tipo: 'veiculo' },
      { k: 'km_inicial', t: 'KM inicial', tipo: 'number' },
      { k: 'data_volta', t: 'Data de volta', tipo: 'date' },
      { k: 'hora_volta', t: 'Hora de volta', tipo: 'time' },
      { k: 'km_final', t: 'KM final', tipo: 'number' },
      { k: 'observacoes', t: 'Observações', tipo: 'text', cheio: true },
    ],
  },
};

let histAtual = 'bonificacoes';   // sub-abas em ordem alfabetica: Bonificacoes, depois Viagens (horas)
let histDados = {};
let histEditId = null;

async function carregarVeiculosFrota() {
  try { veiculosFrota = (await Api.get('/frota?somente_ativos=1&itens_por_pagina=200')).dados; }
  catch (e) { veiculosFrota = []; }
}

async function carregarHistorico(recurso) {
  try {
    const r = await Api.get(`/funcionarios/${idAtual}/${recurso}`);
    histDados[recurso] = r.dados;
    if (recurso === histAtual) renderTabelaHist();
  } catch (e) { mostrarToast(e.message); }
}

function renderHistorico() {
  const box = $('historicoConteudo');
  if (!idAtual) {
    box.innerHTML = '<div class="estado-vazio"><div class="fonte-display">Salve o funcionário primeiro</div><p>Depois disso você poderá lançar bonificações e viagens.</p></div>';
    return;
  }

  box.innerHTML =
    '<div class="hist-topo"><div class="sub-abas">' +
    Object.entries(HIST).map(([k, c]) => `<button type="button" class="pilula ${k === histAtual ? 'ativa' : ''}" data-hist="${k}">${c.rotulo}</button>`).join('') +
    '</div>' +
    '<div class="hist-barra"><span class="hist-contagem" id="histContagem"></span>' +
    '<button type="button" class="btn btn-acento" id="btnNovoHistTopo" data-perm="incluir">+ Novo lançamento</button></div>' +
    '</div><div id="histForm"></div><div id="histLista" class="hist-lista"></div>';

  box.querySelectorAll('[data-hist]').forEach((b) => b.addEventListener('click', () => {
    histAtual = b.dataset.hist;
    histEditId = null;
    renderHistorico();
  }));

  $('btnNovoHistTopo').addEventListener('click', () => abrirFormHist(null));

  if (histDados[histAtual] === undefined) {
    $('histLista').innerHTML = '<p style="color:var(--tinta-suave);">Carregando...</p>';
    carregarHistorico(histAtual);
  } else {
    renderTabelaHist();
  }
  fecharFormHist();
}

function renderTabelaHist() {
  const cfg = HIST[histAtual];
  const linhas = histDados[histAtual] || [];
  const lista = $('histLista');
  if (!lista) return;

  const contagem = $('histContagem');
  if (contagem) contagem.textContent = linhas.length ? `${linhas.length} ${linhas.length === 1 ? 'lançamento' : 'lançamentos'}` : '';

  if (!linhas.length) {
    lista.innerHTML = '<p style="color:var(--tinta-suave); font-size:13.5px; margin:8px 0 16px;">Nenhum lançamento ainda. Use “+ Novo lançamento”.</p>';
    return;
  }

  lista.innerHTML =
    '<table class="tabela-mini"><thead><tr>' + cfg.colunas.map((c) => `<th>${c.t}</th>`).join('') + '</tr></thead><tbody>' +
    linhas.map((r) =>
      `<tr data-id="${r[cfg.chave]}" class="${r[cfg.chave] === histEditId ? 'editando' : ''}">` +
      cfg.colunas.map((c) => {
        const v = c.f ? c.f(r[c.k]) : (r[c.k] == null || r[c.k] === '' ? '—' : r[c.k]);
        return `<td>${escaparHtml(v)}</td>`;
      }).join('') + '</tr>').join('') +
    '</tbody></table>';

  lista.querySelectorAll('tbody tr').forEach((tr) => tr.addEventListener('click', () => {
    const linha = linhas.find((r) => String(r[cfg.chave]) === tr.dataset.id);
    abrirFormHist(linha);
  }));

  const selecionada = lista.querySelector('tr.editando');
  if (selecionada) selecionada.scrollIntoView({ block: 'nearest' });
}

// Abre o formulario (no topo, acima da lista): linha = editar; null = novo lancamento.
function abrirFormHist(linha) {
  const cfg = HIST[histAtual];
  histEditId = linha ? linha[cfg.chave] : null;
  renderTabelaHist();
  renderFormHist(linha);
  const form = $('formHist');
  form.scrollIntoView({ block: 'nearest' });
  // o formulario aberto encolhe a lista: garante que a linha em edicao continue aparecendo nela
  const emEdicao = $('histLista').querySelector('tr.editando');
  if (emEdicao) emEdicao.scrollIntoView({ block: 'nearest' });
  const primeiro = form.querySelector('input:not([disabled]), select:not([disabled])');
  if (primeiro) primeiro.focus();
}

function fecharFormHist() {
  histEditId = null;
  const box = $('histForm');
  if (box) box.innerHTML = '';
  if ($('histLista') && histDados[histAtual] !== undefined) renderTabelaHist(); // se ainda esta carregando, a propria carga desenha
}

function renderFormHist(linha) {
  const cfg = HIST[histAtual];
  const hoje = new Date().toISOString().slice(0, 10);

  const campos = cfg.campos.map((c) => {
    let val = linha ? linha[c.k] : (c.hoje ? hoje : '');
    if (val == null) val = '';
    let input;
    if (c.tipo === 'veiculo') {
      input = `<input list="listaVeiculosHist" data-h="${c.k}" value="${escaparHtml(val)}" placeholder="Placa do veículo">`;
    } else {
      input = `<input data-h="${c.k}" type="${c.tipo}" ${c.tipo === 'number' ? 'step="any"' : ''} ${c.req ? 'required' : ''} value="${escaparHtml(val)}">`;
    }
    return `<div class="campo" ${c.cheio ? 'style="grid-column:1/-1;"' : ''}><label>${c.t}${c.req ? ' *' : ''}</label>${input}</div>`;
  }).join('');

  $('histForm').innerHTML =
    `<datalist id="listaVeiculosHist">${veiculosFrota.map((v) => `<option value="${escaparHtml(v.placa)}">`).join('')}</datalist>
     <form id="formHist" class="caixa-form-hist" autocomplete="off" data-perm-form="sub">
       <div class="hist-form-titulo">${linha ? 'Editar lançamento' : 'Novo lançamento'} · ${cfg.rotulo}</div>
       <div class="grade-2">${campos}</div>
       <div class="hist-form-acoes">
         ${linha ? '<button type="button" class="btn btn-perigo" id="btnExcluirHist" data-perm="excluir">Excluir</button>' : ''}
         <span style="flex:1"></span>
         <button type="button" class="btn btn-secundario" id="btnCancelarHist">Cancelar</button>
         <button type="submit" class="btn btn-primario" data-perm="salvar-sub">${linha ? 'Salvar alterações' : 'Lançar'}</button>
       </div>
     </form>`;

  $('formHist').addEventListener('submit', salvarHist);
  $('btnCancelarHist').addEventListener('click', fecharFormHist);
  if (linha) $('btnExcluirHist').addEventListener('click', excluirHist);
}

async function salvarHist(ev) {
  ev.preventDefault();
  const cfg = HIST[histAtual];
  const form = $('formHist');
  if (!form.reportValidity()) return;

  const payload = {};
  cfg.campos.forEach((c) => {
    const v = form.querySelector(`[data-h="${c.k}"]`).value;
    payload[c.k] = (c.tipo === 'number') ? (v === '' ? null : Number(v)) : v.trim();
  });

  const eraEdicao = !!histEditId;
  try {
    const base = `/funcionarios/${idAtual}/${histAtual}`;
    if (eraEdicao) await Api.put(`${base}/${histEditId}`, payload);
    else await Api.post(base, payload);
    mostrarToast(eraEdicao ? 'Lançamento atualizado.' : 'Lançamento registrado.');
    histEditId = null;
    await carregarHistorico(histAtual);
    if (eraEdicao) fecharFormHist();
    else abrirFormHist(null); // segue aberto e em branco: da para lancar varios em sequencia
  } catch (e) { mostrarToast(e.message); }
}

async function excluirHist() {
  if (!confirm('Excluir este lançamento?')) return;
  try {
    await Api.del(`/funcionarios/${idAtual}/${histAtual}/${histEditId}`);
    mostrarToast('Lançamento excluído.');
    histEditId = null;
    await carregarHistorico(histAtual);
    fecharFormHist();
  } catch (e) { mostrarToast(e.message); }
}

// ---------------------------------------------------------------- início
carregarVeiculosFrota();
carregarFuncionarios();

// ---------------------------------------------------------------- Salario (permissao propria)
// So aparece com "Salarios > ver" no perfil; so e editavel com "Salarios > editar".
// (o servidor tambem nao envia nem grava o salario sem essas permissoes)
function ajustarSalario() {
  const caixa = $('campoSalarioBox');
  if (!caixa) return;
  caixa.style.display = Permissoes.pode('salarios', 'ver') ? '' : 'none';
  $('campoSalario').disabled = !Permissoes.pode('salarios', 'editar');
}
ajustarSalario();
Permissoes.pronto.then(ajustarSalario);
