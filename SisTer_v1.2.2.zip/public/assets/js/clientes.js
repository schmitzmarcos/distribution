exigirLogin();

const usuario = Api.usuario();
if (usuario) {
  document.getElementById('nomeUsuario').textContent = usuario.nome;
  document.getElementById('perfilUsuario').textContent = usuario.perfil;
  document.getElementById('avatarUsuario').textContent = usuario.nome.charAt(0).toUpperCase();
  if (usuario.perfil === 'Administrador') document.getElementById('navAdministracao').style.display = '';
}
document.getElementById('btnSair').addEventListener('click', () => Api.sair());

// --- Estado da tela ---
let paginaAtual = 1;
const itensPorPagina = 20;
let termoBusca = '';
let somenteAtivos = true;
let carregandoLista = false;
let temporizadorBusca = null;

const corpoTabela = document.getElementById('corpoTabela');
const estadoVazio = document.getElementById('estadoVazio');
const contadorClientes = document.getElementById('contadorClientes');
const textoPaginacao = document.getElementById('textoPaginacao');
const btnAnterior = document.getElementById('btnAnterior');
const btnProximo = document.getElementById('btnProximo');

function escaparHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto || '';
  return div.innerHTML;
}

function mostrarToast(mensagem) {
  const toast = document.getElementById('avisoToast');
  toast.textContent = mensagem;
  toast.classList.add('visivel');
  setTimeout(() => toast.classList.remove('visivel'), 2600);
}

async function carregarClientes() {
  if (carregandoLista) return;
  carregandoLista = true;

  try {
    const query = new URLSearchParams({
      busca: termoBusca,
      somente_ativos: somenteAtivos ? '1' : '0',
      pagina: paginaAtual,
      itens_por_pagina: itensPorPagina,
    });

    const resp = await Api.get('/clientes?' + query.toString());

    corpoTabela.innerHTML = '';

    if (resp.dados.length === 0) {
      estadoVazio.style.display = 'block';
    } else {
      estadoVazio.style.display = 'none';
      resp.dados.forEach((c) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td class="cod">${c.id_cliente}</td>
          <td><strong>${escaparHtml(c.nome)}</strong>${c.nome_fantasia ? '<br><span style="color:var(--tinta-suave); font-size:12.5px;">' + escaparHtml(c.nome_fantasia) + '</span>' : ''}</td>
          <td>${escaparHtml(c.cnpj_cpf) || '—'}</td>
          <td>${escaparHtml(c.cidade) || '—'}${c.uf ? '/' + escaparHtml(c.uf) : ''}</td>
          <td>${escaparHtml(c.celular || c.telefone) || '—'}</td>
          <td><span class="badge ${c.situacao === 'A' ? 'badge-ativo' : 'badge-inativo'}">${c.situacao === 'A' ? 'Ativo' : 'Inativo'}</span></td>
        `;
        tr.addEventListener('click', () => abrirPainelEdicao(c.id_cliente));
        corpoTabela.appendChild(tr);
      });
    }

    const totalPaginas = Math.max(1, Math.ceil(resp.total / itensPorPagina));
    contadorClientes.textContent = resp.total + (resp.total === 1 ? ' cliente cadastrado' : ' clientes cadastrados');
    textoPaginacao.textContent = `Página ${paginaAtual} de ${totalPaginas}`;
    btnAnterior.disabled = paginaAtual <= 1;
    btnProximo.disabled = paginaAtual >= totalPaginas;
  } catch (e) {
    mostrarToast(e.message);
  } finally {
    carregandoLista = false;
  }
}

document.getElementById('campoBusca').addEventListener('input', (ev) => {
  clearTimeout(temporizadorBusca);
  temporizadorBusca = setTimeout(() => {
    termoBusca = ev.target.value;
    paginaAtual = 1;
    carregarClientes();
  }, 350); // debounce - evita bater na API a cada tecla
});

document.getElementById('checkSomenteAtivos').addEventListener('change', (ev) => {
  somenteAtivos = ev.target.checked;
  paginaAtual = 1;
  carregarClientes();
});

btnAnterior.addEventListener('click', () => { paginaAtual--; carregarClientes(); });
btnProximo.addEventListener('click', () => { paginaAtual++; carregarClientes(); });

// --- Painel lateral (criar/editar) ---
const painelFundo = document.getElementById('painelFundo');
const painelLateral = document.getElementById('painelLateral');
const formCliente = document.getElementById('formCliente');
const campoCnpjCpf = document.getElementById('campoCnpjCpf');
const erroCnpjCpf = document.getElementById('erroCnpjCpf');

// Formata enquanto digita (000.000.000-00 ou 00.000.000/0000-00, conforme
// a quantidade de dígitos) e ajusta o tipo PF/PJ automaticamente.
campoCnpjCpf.addEventListener('input', (ev) => {
  const posicaoAntes = ev.target.selectionStart;
  const tamanhoAntes = ev.target.value.length;

  ev.target.value = formatarCpfCnpj(ev.target.value);

  // Mantém o cursor razoavelmente no lugar mesmo com a máscara mudando o
  // tamanho do texto (soma a diferença de caracteres inseridos pela máscara).
  const diferenca = ev.target.value.length - tamanhoAntes;
  const novaPosicao = Math.max(0, posicaoAntes + diferenca);
  ev.target.setSelectionRange(novaPosicao, novaPosicao);

  const digitos = somenteDigitos(ev.target.value);
  if (digitos.length === 11) document.getElementById('campoTipoCliente').value = 'PF';
  else if (digitos.length === 14) document.getElementById('campoTipoCliente').value = 'PJ';

  limparErroCnpjCpf();
});

function limparErroCnpjCpf() {
  campoCnpjCpf.classList.remove('campo-invalido');
  erroCnpjCpf.style.display = 'none';
}

function mostrarErroCnpjCpf(mensagem) {
  campoCnpjCpf.classList.add('campo-invalido');
  erroCnpjCpf.textContent = mensagem;
  erroCnpjCpf.style.display = 'block';
}

// Valida ao sair do campo, com a mensagem certa pro tamanho digitado.
campoCnpjCpf.addEventListener('blur', () => {
  const digitos = somenteDigitos(campoCnpjCpf.value);
  if (digitos.length === 0) { limparErroCnpjCpf(); return; }

  if (digitos.length !== 11 && digitos.length !== 14) {
    mostrarErroCnpjCpf('CPF precisa ter 11 dígitos, CNPJ precisa ter 14.');
    return;
  }

  if (!validarCpfCnpj(campoCnpjCpf.value)) {
    mostrarErroCnpjCpf(digitos.length === 11 ? 'CPF inválido.' : 'CNPJ inválido.');
    return;
  }

  limparErroCnpjCpf();
});

const campos = [
  'idCliente', 'campoNome', 'campoNomeFantasia', 'campoTipoCliente', 'campoCnpjCpf',
  'campoInscricaoEstadual', 'campoEndereco', 'campoBairro', 'campoCidade', 'campoUf',
  'campoTelefone', 'campoCelular', 'campoEmail', 'campoObservacoes', 'campoSituacao',
  'campoDataNascimento', 'campoDataCadastro',
];

function hojeISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function limparFormulario() {
  campos.forEach((id) => { document.getElementById(id).value = ''; });
  document.getElementById('campoTipoCliente').value = 'PF';
  document.getElementById('campoSituacao').value = 'A';
  document.getElementById('campoDataCadastro').value = hojeISO(); // igual ao sistema antigo: pré-preenche com hoje, mas é editável
  limparErroCnpjCpf();
}

function abrirPainel(titulo) {
  document.getElementById('tituloPainel').textContent = titulo;
  painelFundo.classList.add('aberto');
  painelLateral.classList.add('aberto');
}

function fecharPainel() {
  painelFundo.classList.remove('aberto');
  painelLateral.classList.remove('aberto');
}

document.getElementById('btnNovo').addEventListener('click', () => {
  limparFormulario();
  document.getElementById('campoSituacaoBloco').style.display = 'none';
  document.getElementById('painelLateral').dataset.novo = '1';
  abrirPainel('Novo cliente');
});

document.getElementById('btnFecharPainel').addEventListener('click', fecharPainel);
document.getElementById('btnCancelarPainel').addEventListener('click', fecharPainel);
painelFundo.addEventListener('click', fecharPainel);

async function abrirPainelEdicao(id) {
  try {
    const c = await Api.get('/clientes/' + id);

    document.getElementById('idCliente').value = c.id_cliente;
    document.getElementById('campoNome').value = c.nome || '';
    document.getElementById('campoNomeFantasia').value = c.nome_fantasia || '';
    document.getElementById('campoTipoCliente').value = c.tipo_cliente || 'PF';
    document.getElementById('campoCnpjCpf').value = c.cnpj_cpf || '';
    document.getElementById('campoInscricaoEstadual').value = c.inscricao_estadual || '';
    document.getElementById('campoEndereco').value = c.endereco || '';
    document.getElementById('campoBairro').value = c.bairro || '';
    document.getElementById('campoCidade').value = c.cidade || '';
    document.getElementById('campoUf').value = c.uf || '';
    document.getElementById('campoTelefone').value = c.telefone || '';
    document.getElementById('campoCelular').value = c.celular || '';
    document.getElementById('campoEmail').value = c.email || '';
    document.getElementById('campoObservacoes').value = c.observacoes || '';
    document.getElementById('campoSituacao').value = c.situacao || 'A';
    document.getElementById('campoDataNascimento').value = c.data_nascimento || '';
    document.getElementById('campoDataCadastro').value = c.data_cadastro || '';

    document.getElementById('campoSituacaoBloco').style.display = 'block';
    limparErroCnpjCpf();
    document.getElementById('painelLateral').dataset.novo = '0';
    abrirPainel(`Editar cliente · cód. ${c.id_cliente}`);
  } catch (e) {
    mostrarToast(e.message);
  }
}

function montarPayload() {
  return {
    nome: document.getElementById('campoNome').value.trim(),
    nome_fantasia: document.getElementById('campoNomeFantasia').value.trim(),
    tipo_cliente: document.getElementById('campoTipoCliente').value,
    cnpj_cpf: document.getElementById('campoCnpjCpf').value.trim(),
    inscricao_estadual: document.getElementById('campoInscricaoEstadual').value.trim(),
    endereco: document.getElementById('campoEndereco').value.trim(),
    bairro: document.getElementById('campoBairro').value.trim(),
    cidade: document.getElementById('campoCidade').value.trim(),
    uf: document.getElementById('campoUf').value.trim().toUpperCase(),
    telefone: document.getElementById('campoTelefone').value.trim(),
    celular: document.getElementById('campoCelular').value.trim(),
    email: document.getElementById('campoEmail').value.trim(),
    observacoes: document.getElementById('campoObservacoes').value.trim(),
    situacao: document.getElementById('campoSituacao').value || 'A',
    data_nascimento: document.getElementById('campoDataNascimento').value,
    data_cadastro: document.getElementById('campoDataCadastro').value,
  };
}

document.getElementById('btnSalvarCliente').addEventListener('click', async () => {
  if (!formCliente.reportValidity()) return;

  if (!validarCpfCnpj(campoCnpjCpf.value)) {
    const digitos = somenteDigitos(campoCnpjCpf.value);
    mostrarErroCnpjCpf(
      digitos.length === 11 ? 'CPF inválido.' :
      digitos.length === 14 ? 'CNPJ inválido.' :
      'CPF precisa ter 11 dígitos, CNPJ precisa ter 14.'
    );
    campoCnpjCpf.focus();
    return;
  }

  const id = document.getElementById('idCliente').value;
  const payload = montarPayload();
  const botao = document.getElementById('btnSalvarCliente');

  botao.disabled = true;
  botao.textContent = 'Salvando...';

  try {
    if (id) {
      await Api.put('/clientes/' + id, payload);
      mostrarToast('Cliente atualizado com sucesso.');
    } else {
      await Api.post('/clientes', payload);
      mostrarToast('Cliente cadastrado com sucesso.');
    }

    fecharPainel();
    carregarClientes();
  } catch (e) {
    mostrarToast(e.message);
  } finally {
    botao.disabled = false;
    botao.textContent = 'Salvar cliente';
  }
});

carregarClientes();
