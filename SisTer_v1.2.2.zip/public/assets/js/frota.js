exigirLogin();

const $ = (id) => document.getElementById(id);

const usuario = Api.usuario();
if (usuario) {
  $('nomeUsuario').textContent = usuario.nome;
  $('perfilUsuario').textContent = usuario.perfil;
  $('avatarUsuario').textContent = usuario.nome.charAt(0).toUpperCase();
  if (usuario.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

// ---------------------------------------------------------------- helpers
function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3000);
}

function diasAte(iso) {
  if (!iso) return null;
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  return Math.round((new Date(iso + 'T00:00:00') - hoje) / 86400000);
}

function fmtData(iso) {
  if (!iso) return '—';
  const [a, m, d] = iso.split('-');
  return `${d}/${m}/${a}`;
}
const fmtMoeda = (n) => (n == null || n === '' ? '—' : Number(n).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
const fmtNum = (n) => (n == null || n === '' || isNaN(n) ? '—' : Number(n).toLocaleString('pt-BR', { maximumFractionDigits: 2 }));

// ---------------------------------------------------------------- configuração
const DOCS = [
  ['venc_vistoria', 'Laudo de vistoria'],
  ['venc_lic_turismo', 'Licença de turismo'],
  ['venc_lic_fretamento', 'Licença de fretamento'],
  ['venc_inmetro_nacional', 'Inmetro nacional'],
  ['venc_inmetro_internacional', 'Inmetro internacional'],
  ['venc_ipva', 'IPVA'],
  ['venc_consulado_argentina', 'Consulado Argentina'],
  ['venc_consulado_uruguai', 'Consulado Uruguai'],
  ['venc_consulado_chile', 'Consulado Chile'],
  ['venc_embratur', 'Embratur'],
  ['venc_metroplan', 'Laudo Metroplan'],
  ['venc_antt_nacional', 'Laudo ANTT nacional'],
  ['venc_antt_internacional', 'Laudo ANTT internacional'],
  ['venc_receftur', 'RecefTur'],
  ['venc_apolice', 'Apólice de seguro'],
  ['venc_grade_daer', 'Grade horária DAER'],
  ['venc_extintor', 'Extintor'],
  ['venc_tacografo', 'Tacógrafo'],
];

const SELECTS = [
  ['tipo_veiculo', 'Tipo de veículo', ['2 eixos', '3 eixos', '4 eixos', 'Micro', 'Van']],
  ['motor_posicao', 'Motor', ['Dianteiro', 'Traseiro']],
  ['tipo_poltrona', 'Poltronas', ['Leito c/ descanso de pernas', 'Leito turismo c/ descanso de pernas', 'Leito turismo s/ descanso de pernas', 'Executiva']],
  ['porta', 'Porta', ['Dianteira', 'Central', 'Traseira']],
  ['tipo_roda', 'Rodas', ['Ferro', 'Alumínio']],
  ['tipo_tacografo', 'Tacógrafo', ['Analógico', 'Digital']],
];

// Históricos: cada um vira uma sub-aba com tabela + formulário, tudo a partir desta configuração.
const HIST = {
  manutencoes: {
    rotulo: 'Manutenção', chave: 'id_manutencao',
    colunas: [
      { k: 'data', t: 'Data', f: fmtData }, { k: 'descricao', t: 'Descrição' },
      { k: 'km', t: 'KM', f: fmtNum }, { k: 'quantidade', t: 'Qtde' },
      { k: 'valor', t: 'Valor', f: fmtMoeda }, { k: 'funcionario_nome', t: 'Autorizado por' },
    ],
    campos: [
      { k: 'data', t: 'Data', tipo: 'date', req: true, hoje: true },
      { k: 'descricao', t: 'Descrição', tipo: 'text', req: true },
      { k: 'km', t: 'KM', tipo: 'number' }, { k: 'quantidade', t: 'Quantidade', tipo: 'number' },
      { k: 'valor', t: 'Valor (R$)', tipo: 'number' }, { k: 'id_funcionario', t: 'Autorizado por', tipo: 'funcionario' },
    ],
  },
  preventivas: {
    rotulo: 'Preventiva', chave: 'id_preventiva',
    colunas: [
      { k: 'descricao', t: 'Descrição' }, { k: 'km_troca', t: 'KM da troca', f: fmtNum },
      { k: 'proxima_troca', t: 'Próxima troca (KM)', f: fmtNum },
    ],
    campos: [
      { k: 'descricao', t: 'Descrição', tipo: 'text', req: true },
      { k: 'km_troca', t: 'KM da troca', tipo: 'number' }, { k: 'proxima_troca', t: 'Próxima troca (KM)', tipo: 'number' },
    ],
  },
  medias: {
    rotulo: 'Abastecimento', chave: 'id_media',
    colunas: [
      { k: 'data', t: 'Data', f: fmtData }, { k: 'local_abastecimento', t: 'Local' },
      { k: 'km_inicial', t: 'KM inicial', f: fmtNum }, { k: 'km_final', t: 'KM final', f: fmtNum },
      { k: 'litros', t: 'Combustível (L)', f: fmtNum }, { k: 'litros_arla', t: 'Arla (L)', f: fmtNum },
      { t: 'KM rodados', calc: (r) => (r.km_final != null && r.km_inicial != null ? fmtNum(r.km_final - r.km_inicial) : '—') },
      { t: 'Média km/l', calc: (r) => (r.litros > 0 && r.km_final != null && r.km_inicial != null ? fmtNum((r.km_final - r.km_inicial) / r.litros) : '—') },
    ],
    campos: [
      { k: 'data', t: 'Data', tipo: 'date', req: true, hoje: true }, { k: 'local_abastecimento', t: 'Local', tipo: 'text' },
      { k: 'km_inicial', t: 'KM inicial', tipo: 'number' }, { k: 'km_final', t: 'KM final', tipo: 'number' },
      { k: 'litros', t: 'Combustível (L)', tipo: 'number' }, { k: 'litros_arla', t: 'Arla (L)', tipo: 'number' },
    ],
  },
  multas: {
    rotulo: 'Multas', chave: 'id_multa',
    colunas: [
      { k: 'data', t: 'Data', f: fmtData }, { k: 'descricao', t: 'Descrição' },
      { k: 'funcionario_nome', t: 'Motorista' }, { k: 'valor', t: 'Valor', f: fmtMoeda }, { k: 'pontos', t: 'Pontos' },
    ],
    campos: [
      { k: 'data', t: 'Data', tipo: 'date', req: true, hoje: true }, { k: 'descricao', t: 'Descrição', tipo: 'text', req: true },
      { k: 'id_funcionario', t: 'Motorista', tipo: 'funcionario' }, { k: 'valor', t: 'Valor (R$)', tipo: 'number' },
      { k: 'pontos', t: 'Pontos', tipo: 'number' },
    ],
  },
  acidentes: {
    rotulo: 'Acidentes', chave: 'id_acidente',
    colunas: [{ k: 'data', t: 'Data', f: fmtData }, { k: 'funcionario_nome', t: 'Motorista' }, { k: 'descricao', t: 'Descrição' }],
    campos: [
      { k: 'data', t: 'Data', tipo: 'date', req: true, hoje: true }, { k: 'id_funcionario', t: 'Motorista', tipo: 'funcionario' },
      { k: 'descricao', t: 'Descrição', tipo: 'text', req: true, cheio: true },
    ],
  },
};

// ---------------------------------------------------------------- estado
let veiculos = [];
let busca = '';
let somenteAtivos = true;
let idAtual = null;
let funcionarios = [];
// sub-abas do histórico em ordem alfabética pelo rótulo (pt-BR)
const HIST_ORDEM = Object.keys(HIST).sort((a, b) => HIST[a].rotulo.localeCompare(HIST[b].rotulo, 'pt-BR'));
let histAtual = HIST_ORDEM[0];
let histDados = {};
let histEditId = null;

// ---------------------------------------------------------------- documentos / vencimentos
function resumoDocs(v) {
  const vencidos = [];
  const vencendo = [];
  let comData = 0;
  DOCS.forEach(([k, rotulo]) => {
    const d = diasAte(v[k]);
    if (d === null) return;
    comData++;
    if (d < 0) vencidos.push(`${rotulo} (${fmtData(v[k])})`);
    else if (d <= 30) vencendo.push(`${rotulo} (${d}d)`);
  });
  return { vencidos, vencendo, comData };
}

function badgesDocs(v) {
  const r = resumoDocs(v);
  const html = [];
  if (r.vencidos.length) html.push(`<span class="badge badge-perigo" title="${escaparHtml(r.vencidos.join('\n'))}">${r.vencidos.length} vencido${r.vencidos.length > 1 ? 's' : ''}</span>`);
  if (r.vencendo.length) html.push(`<span class="badge badge-alerta" title="${escaparHtml(r.vencendo.join('\n'))}">${r.vencendo.length} a vencer</span>`);
  if (!html.length) html.push(r.comData ? '<span class="badge badge-ativo">Em dia</span>' : '<span style="color:var(--tinta-suave); font-size:12.5px;">Sem datas</span>');
  return `<div class="badges-docs">${html.join('')}</div>`;
}

// ---------------------------------------------------------------- lista
async function carregar() {
  try {
    const q = new URLSearchParams({ somente_ativos: somenteAtivos ? '1' : '0', itens_por_pagina: '200' });
    const r = await Api.get('/frota?' + q.toString());
    veiculos = r.dados;
    renderizar();
  } catch (e) {
    mostrarToast(e.message);
  }
}

function renderizar() {
  const termo = busca.trim().toLowerCase();
  const lista = veiculos.filter((v) => !termo || [v.numero, v.placa, v.marca, v.modelo].join(' ').toLowerCase().includes(termo));

  const corpo = $('corpoTabela');
  corpo.innerHTML = '';
  $('estadoVazio').style.display = lista.length ? 'none' : 'block';

  lista.forEach((v) => {
    const tr = document.createElement('tr');
    const anos = [v.ano_fabricacao, v.ano_modelo].filter(Boolean).join('/');
    tr.innerHTML = `
      <td class="cod">${v.id_veiculo}</td>
      <td><strong>${escaparHtml(v.numero)}</strong></td>
      <td><span class="placa">${escaparHtml(v.placa)}</span></td>
      <td>${escaparHtml([v.marca, v.modelo].filter(Boolean).join(' ')) || '—'}<br>
          <span style="color:var(--tinta-suave); font-size:12.5px;">${escaparHtml(anos)}${v.lotacao ? ' · ' + v.lotacao + ' lugares' : ''}</span></td>
      <td>${escaparHtml(v.tipo_veiculo) || '—'}</td>
      <td><span class="badge ${v.situacao === 'A' ? 'badge-ativo' : 'badge-inativo'}">${v.situacao === 'A' ? 'Ativo' : 'Inativo'}</span></td>
      <td>${badgesDocs(v)}</td>`;
    tr.addEventListener('click', () => abrirEdicao(v.id_veiculo));
    corpo.appendChild(tr);
  });

  // KPIs sobre os veículos ativos carregados
  const ativos = veiculos.filter((v) => v.situacao === 'A');
  let vencidos = 0;
  let vencendo = 0;
  ativos.forEach((v) => {
    const r = resumoDocs(v);
    vencidos += r.vencidos.length;
    vencendo += r.vencendo.length;
  });
  $('kpiAtivos').textContent = ativos.length;
  $('kpiVencidos').textContent = vencidos;
  $('kpiVencendo').textContent = vencendo;
  $('contadorVeiculos').textContent = `${veiculos.length} ${veiculos.length === 1 ? 'veículo' : 'veículos'} ${somenteAtivos ? 'ativos' : 'cadastrados'}`;
}

$('campoBusca').addEventListener('input', (ev) => { busca = ev.target.value; renderizar(); });
$('checkSomenteAtivos').addEventListener('change', (ev) => { somenteAtivos = ev.target.checked; carregar(); });

// ---------------------------------------------------------------- montagem dos campos gerados
$('gradeDocs').innerHTML = DOCS.map(([k, r]) =>
  `<div class="campo"><label for="${k}">${r}</label><input type="date" id="${k}" data-campo="${k}"><span class="status-doc" id="st_${k}"></span></div>`).join('');

$('gradeSelects').innerHTML = SELECTS.map(([k, r, ops]) =>
  `<div class="campo"><label>${r}</label><select data-campo="${k}"><option value="">— não informado —</option>${ops.map((o) => `<option>${o}</option>`).join('')}</select></div>`).join('');

function atualizarStatusDocs() {
  DOCS.forEach(([k]) => {
    const el = $(k);
    const st = $('st_' + k);
    el.classList.remove('doc-vencido', 'doc-alerta');
    st.className = 'status-doc';
    const d = diasAte(el.value);
    if (d === null) { st.textContent = ''; return; }
    if (d < 0) { el.classList.add('doc-vencido'); st.classList.add('perigo'); st.textContent = `Vencido há ${-d} dia${-d > 1 ? 's' : ''}`; }
    else if (d <= 30) { el.classList.add('doc-alerta'); st.classList.add('alerta'); st.textContent = d === 0 ? 'Vence hoje' : `Vence em ${d} dia${d > 1 ? 's' : ''}`; }
    else st.textContent = 'Em dia';
  });
}
$('gradeDocs').addEventListener('change', atualizarStatusDocs);

// placa: sempre maiúscula e sem hífen/espaço
$('campoPlaca').addEventListener('input', (ev) => {
  ev.target.value = ev.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
});


// ---------------------------------------------------------------- equipamentos (cadastro editável)
let catalogo = [];                 // [{ id_equipamento, nome, situacao, qtd_veiculos }]
let equipMarcados = new Set();     // ids marcados no veículo aberto (sobrevive a recarregar o catálogo)

async function carregarCatalogo() {
  try {
    const r = await Api.get('/equipamentos');
    catalogo = r.dados || [];
  } catch (e) { mostrarToast(e.message); }
  renderEquip();
  renderGerenciar();
}

function renderEquip() {
  // inativos so aparecem nos veiculos que ja os tem
  const visiveis = catalogo.filter((e) => e.situacao === 'A' || equipMarcados.has(e.id_equipamento));
  $('gradeEquip').innerHTML = visiveis.map((e) =>
    `<label class="chip"><input type="checkbox" data-equip="${e.id_equipamento}"${equipMarcados.has(e.id_equipamento) ? ' checked' : ''}> ${escaparHtml(e.nome)}${e.situacao !== 'A' ? ' <small>(inativo)</small>' : ''}</label>`).join('');
  $('equipVazio').style.display = visiveis.length ? 'none' : '';
}
$('gradeEquip').addEventListener('change', (ev) => {
  const cb = ev.target.closest('[data-equip]');
  if (!cb) return;
  const id = Number(cb.dataset.equip);
  if (cb.checked) equipMarcados.add(id); else equipMarcados.delete(id);
});

function renderGerenciar() {
  $('equipLista').innerHTML = catalogo.map((e) => {
    const inativo = e.situacao !== 'A';
    const uso = e.qtd_veiculos ? `usado em ${e.qtd_veiculos} ${e.qtd_veiculos === 1 ? 'veículo' : 'veículos'}` : 'sem uso';
    return `<li data-id="${e.id_equipamento}" class="${inativo ? 'inativo' : ''}">
      <span class="eq-nome">${escaparHtml(e.nome)}</span>
      ${inativo ? '<span class="badge badge-inativo">Inativo</span>' : ''}
      <small>${uso}</small>
      <span class="eq-acoes">
        <button type="button" data-acao="renomear" data-perm="editar">Renomear</button>
        ${inativo ? '<button type="button" data-acao="reativar" data-perm="editar">Reativar</button>' : ''}
        <button type="button" data-acao="excluir" data-perm="excluir">Excluir</button>
      </span></li>`;
  }).join('') || '<li class="vazio">Nenhum equipamento cadastrado.</li>';
}

async function adicionarEquipamento() {
  const campo = $('equipNovoNome');
  const nome = campo.value.trim();
  if (!nome) { campo.focus(); return; }
  try {
    const r = await Api.post('/equipamentos', { nome });
    campo.value = '';
    equipMarcados.add(r.id_equipamento);   // o novo ja vem marcado no veiculo aberto
    await carregarCatalogo();
    mostrarToast(`Equipamento "${nome}" adicionado.`);
    campo.focus();
  } catch (e) { mostrarToast(e.message); }
}
$('btnEquipAdd').addEventListener('click', adicionarEquipamento);
$('equipNovoNome').addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); adicionarEquipamento(); } });

$('equipLista').addEventListener('click', async (ev) => {
  const botao = ev.target.closest('[data-acao]');
  const li = ev.target.closest('li[data-id]');
  if (!botao || !li) return;
  const id = Number(li.dataset.id);
  const eq = catalogo.find((x) => x.id_equipamento === id);
  if (!eq) return;
  try {
    if (botao.dataset.acao === 'renomear') {
      const span = li.querySelector('.eq-nome');
      const campo = document.createElement('input');
      campo.value = eq.nome; campo.maxLength = 40; campo.className = 'eq-edita';
      span.replaceWith(campo);
      campo.focus(); campo.select();
      campo.addEventListener('keydown', async (k) => {
        if (k.key === 'Escape') { renderGerenciar(); return; }
        if (k.key !== 'Enter') return;
        k.preventDefault();
        try {
          await Api.put(`/equipamentos/${id}`, { nome: campo.value.trim(), situacao: eq.situacao });
          await carregarCatalogo();
        } catch (e) { mostrarToast(e.message); }
      });
      campo.addEventListener('blur', () => setTimeout(renderGerenciar, 150));
    } else if (botao.dataset.acao === 'reativar') {
      await Api.put(`/equipamentos/${id}`, { nome: eq.nome, situacao: 'A' });
      await carregarCatalogo();
    } else if (botao.dataset.acao === 'excluir') {
      if (!confirm(`Excluir "${eq.nome}"?\n\nSe algum veículo usa este equipamento, ele será apenas inativado (continua nos veículos que o têm, mas deixa de ser oferecido nos outros).`)) return;
      const r = await Api.del(`/equipamentos/${id}`);
      if (r && r.acao === 'excluido') equipMarcados.delete(id);
      await carregarCatalogo();
      mostrarToast(r && r.acao === 'inativado' ? `"${eq.nome}" está em uso em ${r.veiculos} ${r.veiculos === 1 ? 'veículo' : 'veículos'} e foi inativado.` : `"${eq.nome}" excluído.`);
    }
  } catch (e) { mostrarToast(e.message); }
});

// ---------------------------------------------------------------- formulário do veículo
function preencher(v) {
  document.querySelectorAll('#formVeiculo [data-campo]').forEach((el) => {
    const val = v ? v[el.dataset.campo] : undefined;
    if (el.type === 'checkbox') el.checked = el.dataset.sn ? val === 'S' : Number(val) === 1;
    else el.value = val == null ? '' : val;
  });
  equipMarcados = new Set(v && v.equipamentos ? v.equipamentos.map(Number) : []);
  renderEquip();
}

function coletar() {
  const dados = {};
  document.querySelectorAll('#formVeiculo [data-campo]').forEach((el) => {
    const k = el.dataset.campo;
    if (el.type === 'checkbox') dados[k] = el.dataset.sn ? (el.checked ? 'S' : 'N') : (el.checked ? 1 : 0);
    else if (el.type === 'number') dados[k] = el.value === '' ? null : Number(el.value);
    else dados[k] = el.value.trim();
  });
  dados.equipamentos = [...equipMarcados];
  return dados;
}

// ---------------------------------------------------------------- painel e abas
function abrirPainel(titulo) {
  $('tituloPainel').textContent = titulo;
  $('painelFundo').classList.add('aberto');
  $('painelLateral').classList.add('aberto');
}
function fecharPainel() {
  $('painelFundo').classList.remove('aberto');
  $('painelLateral').classList.remove('aberto');
}

function ativarAba(nome) {
  document.querySelectorAll('.aba').forEach((b) => b.classList.toggle('ativa', b.dataset.aba === nome));
  document.querySelectorAll('.pane').forEach((p) => p.classList.toggle('ativo', p.dataset.pane === nome));
  const historico = nome === 'historico';
  $('btnSalvarVeiculo').style.display = historico ? 'none' : '';
  $('btnCancelarPainel').textContent = historico ? 'Fechar' : 'Cancelar';
  if (historico) renderHistorico();
}
document.querySelectorAll('.aba').forEach((b) => b.addEventListener('click', () => ativarAba(b.dataset.aba)));

$('btnFecharPainel').addEventListener('click', fecharPainel);
$('btnCancelarPainel').addEventListener('click', fecharPainel);
$('painelFundo').addEventListener('click', fecharPainel);

$('btnNovo').addEventListener('click', () => {
  idAtual = null;
  histDados = {};
  histEditId = null;
  preencher(null);
  $('blocoSituacao').style.display = 'none';
  atualizarStatusDocs();
  document.getElementById('painelLateral').dataset.novo = '1';
  abrirPainel('Novo veículo');
  ativarAba('veiculo');
});

async function abrirEdicao(id, aba = 'veiculo') {
  try {
    const v = await Api.get('/frota/' + id);
    idAtual = id;
    histDados = {};
    histEditId = null;
    preencher(v);
    $('blocoSituacao').style.display = 'block';
    atualizarStatusDocs();
    document.getElementById('painelLateral').dataset.novo = '0';
    abrirPainel(`Veículo ${v.numero} · ${v.placa} · cód. ${v.id_veiculo}`);
    ativarAba(aba);
  } catch (e) {
    mostrarToast(e.message);
  }
}

$('btnSalvarVeiculo').addEventListener('click', async () => {
  const form = $('formVeiculo');
  // abre antes a aba do campo invalido: em aba escondida o navegador nao consegue mostrar o aviso
  const invalido = form.querySelector(':invalid');
  if (invalido) {
    const aba = invalido.closest('[data-pane]');
    ativarAba(aba ? aba.dataset.pane : 'veiculo');
    form.reportValidity();
    return;
  }

  const payload = coletar();
  if (!idAtual) payload.situacao = 'A';
  const botao = $('btnSalvarVeiculo');
  botao.disabled = true;
  botao.textContent = 'Salvando...';

  try {
    if (idAtual) {
      await Api.put('/frota/' + idAtual, payload);
      mostrarToast('Veículo atualizado com sucesso.');
    } else {
      await Api.post('/frota', payload);
      mostrarToast('Veículo cadastrado com sucesso.');
    }
    // Sempre fecha ao salvar (criar ou editar). Pra lançar o histórico
    // (manutenção, multas...) de um veículo recém-criado, é só abrir ele de
    // novo na lista - aí entra como edição e a aba Histórico já funciona.
    fecharPainel();
    carregar();
  } catch (e) {
    mostrarToast(e.message);
  } finally {
    botao.disabled = false;
    botao.textContent = 'Salvar veículo';
  }
});

// ---------------------------------------------------------------- históricos
async function carregarFuncionarios() {
  try {
    const r = await Api.get('/funcionarios?somente_ativos=1&itens_por_pagina=200');
    funcionarios = r.dados;
  } catch (e) {
    funcionarios = []; // sem permissão no módulo Funcionários: os campos de motorista ficam vazios
  }
}

async function carregarHistorico(recurso) {
  try {
    const r = await Api.get(`/frota/${idAtual}/${recurso}`);
    histDados[recurso] = r.dados;
    if (recurso === histAtual) { renderTabelaHist(); }
  } catch (e) {
    mostrarToast(e.message);
  }
}

function renderHistorico() {
  const box = $('historicoConteudo');

  if (!idAtual) {
    box.innerHTML = '<div class="estado-vazio"><div class="fonte-display">Salve o veículo primeiro</div><p>Depois disso você poderá lançar manutenções, multas, abastecimentos e mais.</p></div>';
    return;
  }

  box.innerHTML =
    '<div class="hist-topo"><div class="sub-abas">' +
    HIST_ORDEM.map((k) => `<button type="button" class="pilula ${k === histAtual ? 'ativa' : ''}" data-hist="${k}">${HIST[k].rotulo}</button>`).join('') +
    '</div>' +
    '<div class="hist-barra"><span class="hist-contagem" id="histContagem"></span>' +
    '<button type="button" class="btn btn-acento" id="btnNovoHistTopo" data-perm="incluir">+ Novo lançamento</button></div>' +
    '</div><div id="histForm"></div><div id="histLista" class="hist-lista"></div>';

  box.querySelectorAll('[data-hist]').forEach((b) => b.addEventListener('click', () => {
    histAtual = b.dataset.hist;
    histEditId = null;
    renderHistorico();
  }));

  $('btnNovoHistTopo').addEventListener('click', () => abrirFormHist(null));

  if (histDados[histAtual] === undefined) {
    $('histLista').innerHTML = '<p style="color:var(--tinta-suave);">Carregando...</p>';
    carregarHistorico(histAtual);
  } else {
    renderTabelaHist();
  }
  fecharFormHist();
}

function renderTabelaHist() {
  const cfg = HIST[histAtual];
  const linhas = histDados[histAtual] || [];
  const lista = $('histLista');
  if (!lista) return;

  const contagem = $('histContagem');
  if (contagem) contagem.textContent = linhas.length ? `${linhas.length} ${linhas.length === 1 ? 'lançamento' : 'lançamentos'}` : '';

  if (!linhas.length) {
    lista.innerHTML = '<p style="color:var(--tinta-suave); font-size:13.5px; margin:8px 0 16px;">Nenhum lançamento ainda. Use “+ Novo lançamento”.</p>';
    return;
  }

  lista.innerHTML =
    '<table class="tabela-mini"><thead><tr>' + cfg.colunas.map((c) => `<th>${c.t}</th>`).join('') + '</tr></thead><tbody>' +
    linhas.map((r) =>
      `<tr data-id="${r[cfg.chave]}" class="${r[cfg.chave] === histEditId ? 'editando' : ''}">` +
      cfg.colunas.map((c) => {
        const v = c.calc ? c.calc(r) : (c.f ? c.f(r[c.k]) : (r[c.k] == null || r[c.k] === '' ? '—' : r[c.k]));
        return `<td>${escaparHtml(v)}</td>`;
      }).join('') + '</tr>').join('') +
    '</tbody></table>';

  lista.querySelectorAll('tbody tr').forEach((tr) => tr.addEventListener('click', () => {
    const linha = linhas.find((r) => String(r[cfg.chave]) === tr.dataset.id);
    abrirFormHist(linha);
  }));

  const selecionada = lista.querySelector('tr.editando');
  if (selecionada) selecionada.scrollIntoView({ block: 'nearest' });
}

// Abre o formulario (no topo, acima da lista): linha = editar; null = novo lancamento.
function abrirFormHist(linha) {
  const cfg = HIST[histAtual];
  histEditId = linha ? linha[cfg.chave] : null;
  renderTabelaHist();
  renderFormHist(linha);
  const form = $('formHist');
  form.scrollIntoView({ block: 'nearest' });
  // o formulario aberto encolhe a lista: garante que a linha em edicao continue aparecendo nela
  const emEdicao = $('histLista').querySelector('tr.editando');
  if (emEdicao) emEdicao.scrollIntoView({ block: 'nearest' });
  const primeiro = form.querySelector('input:not([disabled]), select:not([disabled])');
  if (primeiro) primeiro.focus();
}

function fecharFormHist() {
  histEditId = null;
  const box = $('histForm');
  if (box) box.innerHTML = '';
  if ($('histLista') && histDados[histAtual] !== undefined) renderTabelaHist(); // se ainda esta carregando, a propria carga desenha
}

function renderFormHist(linha) {
  const cfg = HIST[histAtual];
  const hoje = new Date().toISOString().slice(0, 10);

  const campos = cfg.campos.map((c) => {
    let val = linha ? linha[c.k] : (c.hoje ? hoje : '');
    if (val == null) val = '';
    let input;
    if (c.tipo === 'funcionario') {
      input = `<select data-h="${c.k}"><option value="">—</option>` +
        funcionarios.map((f) => `<option value="${f.id_funcionario}" ${String(val) === String(f.id_funcionario) ? 'selected' : ''}>${escaparHtml(f.nome)}</option>`).join('') + '</select>';
    } else {
      input = `<input data-h="${c.k}" type="${c.tipo}" ${c.tipo === 'number' ? 'step="any"' : ''} ${c.req ? 'required' : ''} value="${escaparHtml(val)}">`;
    }
    return `<div class="campo" ${c.cheio ? 'style="grid-column:1/-1;"' : ''}><label>${c.t}${c.req ? ' *' : ''}</label>${input}</div>`;
  }).join('');

  $('histForm').innerHTML =
    `<form id="formHist" class="caixa-form-hist" autocomplete="off" data-perm-form="sub">
       <div class="hist-form-titulo">${linha ? 'Editar lançamento' : 'Novo lançamento'} · ${cfg.rotulo}</div>
       <div class="grade-2">${campos}</div>
       <div class="hist-form-acoes">
         ${linha ? '<button type="button" class="btn btn-perigo" id="btnExcluirHist" data-perm="excluir">Excluir</button>' : ''}
         <span style="flex:1"></span>
         <button type="button" class="btn btn-secundario" id="btnCancelarHist">Cancelar</button>
         <button type="submit" class="btn btn-primario" data-perm="salvar-sub">${linha ? 'Salvar alterações' : 'Lançar'}</button>
       </div>
     </form>`;

  $('formHist').addEventListener('submit', salvarHist);
  $('btnCancelarHist').addEventListener('click', fecharFormHist);
  if (linha) $('btnExcluirHist').addEventListener('click', excluirHist);
}

async function salvarHist(ev) {
  ev.preventDefault();
  const cfg = HIST[histAtual];
  const form = $('formHist');
  if (!form.reportValidity()) return;

  const payload = {};
  cfg.campos.forEach((c) => {
    const v = form.querySelector(`[data-h="${c.k}"]`).value;
    payload[c.k] = (c.tipo === 'number' || c.tipo === 'funcionario') ? (v === '' ? null : Number(v)) : v.trim();
  });

  const eraEdicao = !!histEditId;
  try {
    const base = `/frota/${idAtual}/${histAtual}`;
    if (eraEdicao) await Api.put(`${base}/${histEditId}`, payload);
    else await Api.post(base, payload);
    mostrarToast(eraEdicao ? 'Lançamento atualizado.' : 'Lançamento registrado.');
    histEditId = null;
    await carregarHistorico(histAtual);
    if (eraEdicao) fecharFormHist();
    else abrirFormHist(null); // segue aberto e em branco: da para lancar varios em sequencia
  } catch (e) {
    mostrarToast(e.message);
  }
}

async function excluirHist() {
  if (!confirm('Excluir este lançamento?')) return;
  try {
    await Api.del(`/frota/${idAtual}/${histAtual}/${histEditId}`);
    mostrarToast('Lançamento excluído.');
    histEditId = null;
    await carregarHistorico(histAtual);
    fecharFormHist();
  } catch (e) {
    mostrarToast(e.message);
  }
}

// ---------------------------------------------------------------- início
carregarFuncionarios();
carregarCatalogo();
carregar();
