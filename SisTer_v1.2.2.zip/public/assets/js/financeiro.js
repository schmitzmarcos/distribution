exigirLogin();

const $ = (id) => document.getElementById(id);

const usuario = Api.usuario();
if (usuario) {
  $('nomeUsuario').textContent = usuario.nome;
  $('perfilUsuario').textContent = usuario.perfil;
  $('avatarUsuario').textContent = usuario.nome.charAt(0).toUpperCase();
  if (usuario.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3600);
}
const pad = (n) => String(n).padStart(2, '0');
function hojeISO() { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function fmtDataCurta(s) { if (!s) return ''; const [, m, d] = s.split('-'); return `${d}/${m}`; }
function fmtDataBR(s) { if (!s) return '—'; const [a, m, d] = s.split('-'); return `${d}/${m}/${a}`; }
const fmtMoeda = (n) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

// ---------------------------------------------------------------- abas da página
document.querySelectorAll('.aba-pagina').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('.aba-pagina').forEach((x) => x.classList.toggle('ativa', x === b));
  document.querySelectorAll('[data-secao-conteudo]').forEach((s) => s.classList.toggle('ativa', s.dataset.secaoConteudo === b.dataset.secao));
  if (b.dataset.secao === 'contas') carregarContas();
  if (b.dataset.secao === 'resumo') carregarResumo();
}));

// ---------------------------------------------------------------- contas (compartilhado)
let contas = [];
async function carregarListaContas() {
  try {
    contas = (await Api.get('/contas-caixa')).dados;
  } catch (e) { contas = []; }
  const opts = contas.map((c) => `<option value="${c.id_conta}">${escaparHtml(c.descricao)}</option>`).join('');
  $('filtroConta').innerHTML = '<option value="">Todas as contas</option>' + opts;
  $('selConta').innerHTML = opts;
}

// ================================================================= LANÇAMENTOS
async function carregarLancamentos() {
  const q = new URLSearchParams();
  if ($('campoBusca').value.trim()) q.set('busca', $('campoBusca').value.trim());
  if ($('filtroTipo').value) q.set('tipo', $('filtroTipo').value);
  if ($('filtroConta').value) q.set('id_conta', $('filtroConta').value);
  if ($('filtroDe').value) q.set('de', $('filtroDe').value);
  if ($('filtroAte').value) q.set('ate', $('filtroAte').value);

  try {
    const r = await Api.get('/caixa?' + q.toString());
    renderLancamentos(r.dados);
  } catch (e) { mostrarToast(e.message); }
}

function renderLancamentos(lista) {
  const corpo = $('corpoLancamentos');
  corpo.innerHTML = '';
  $('vazioLancamentos').style.display = lista.length ? 'none' : 'block';

  const rotuloTipo = { E: 'Entrada', S: 'Saída', A: 'Em aberto' };
  const classeTipo = { E: 'valor-e', S: 'valor-s', A: 'valor-a' };

  lista.forEach((l) => {
    const tr = document.createElement('tr');
    const pago = l.tipo === 'E' ? (l.data_pagamento ? '' : ' <span class="badge badge-alerta">a receber</span>') : '';
    tr.innerHTML = `
      <td>${fmtDataBR(l.data_movimento)}</td>
      <td>${escaparHtml(l.descricao) || '—'}${pago}</td>
      <td>${escaparHtml(l.conta_descricao) || '—'}</td>
      <td>${escaparHtml(l.nome_pagador) || '—'}</td>
      <td>${rotuloTipo[l.tipo] || l.tipo}</td>
      <td class="${classeTipo[l.tipo] || ''}">${l.tipo === 'S' ? '−' : ''}${fmtMoeda(l.valor)}</td>`;
    tr.addEventListener('click', () => abrirEdicaoLancamento(l.id_lancamento));
    corpo.appendChild(tr);
  });
}

['campoBusca'].forEach((id) => $(id).addEventListener('input', () => { clearTimeout(window._tBusca); window._tBusca = setTimeout(carregarLancamentos, 350); }));
['filtroTipo', 'filtroConta', 'filtroDe', 'filtroAte'].forEach((id) => $(id).addEventListener('change', carregarLancamentos));

// ---- painel de lançamento
const painelFundo = $('painelFundo');
const painelLateral = $('painelLateral');
let idLancAtual = null;

function abrirPainelLanc(titulo) { $('tituloPainel').textContent = titulo; painelFundo.classList.add('aberto'); painelLateral.classList.add('aberto'); }
function fecharPainelLanc() { painelFundo.classList.remove('aberto'); painelLateral.classList.remove('aberto'); }
$('btnFecharPainel').addEventListener('click', fecharPainelLanc);
$('btnCancelarPainel').addEventListener('click', fecharPainelLanc);
painelFundo.addEventListener('click', fecharPainelLanc);

function preencherLancamento(l) {
  document.querySelectorAll('#formLancamento [data-campo]').forEach((el) => {
    const val = l ? l[el.dataset.campo] : undefined;
    if (el.type === 'checkbox') el.checked = l ? Number(val) === 1 : true;
    else el.value = val == null ? '' : val;
  });
  const tipo = (l && l.tipo) || 'E';
  document.querySelectorAll('input[name="tipo"]').forEach((r) => { r.checked = r.value === tipo; });
}

function coletarLancamento() {
  const d = {};
  document.querySelectorAll('#formLancamento [data-campo]').forEach((el) => {
    const k = el.dataset.campo;
    if (el.type === 'checkbox') d[k] = el.checked ? 1 : 0;
    else if (el.type === 'number' || el.dataset.int) d[k] = el.value === '' ? null : Number(el.value);
    else d[k] = el.value.trim();
  });
  const r = document.querySelector('input[name="tipo"]:checked');
  d.tipo = r ? r.value : 'E';
  return d;
}

$('btnNovoLancamento').addEventListener('click', () => {
  idLancAtual = null;
  preencherLancamento({ data_movimento: hojeISO() });
  $('btnExcluirLancamento').style.display = 'none';
  document.getElementById('painelLateral').dataset.novo = '1';
  abrirPainelLanc('Novo lançamento');
});

async function abrirEdicaoLancamento(id) {
  try {
    const l = await Api.get('/caixa/' + id);
    idLancAtual = id;
    preencherLancamento(l);
    $('btnExcluirLancamento').style.display = '';
    document.getElementById('painelLateral').dataset.novo = '0';
    abrirPainelLanc(`Lançamento ${l.id_lancamento}`);
  } catch (e) { mostrarToast(e.message); }
}

async function salvarLancamento(forcar) {
  if (!$('formLancamento').reportValidity()) return;
  const payload = coletarLancamento();
  const botao = $('btnSalvarLancamento');
  botao.disabled = true;
  botao.textContent = 'Salvando...';

  try {
    const sufixo = forcar ? '?forcar=1' : '';
    if (idLancAtual) await Api.put('/caixa/' + idLancAtual + sufixo, payload);
    else await Api.post('/caixa' + sufixo, payload);

    mostrarToast(idLancAtual ? 'Lançamento atualizado.' : 'Lançamento registrado.');
    fecharPainelLanc();
    carregarLancamentos();
    carregarListaContas();
  } catch (e) {
    if (e.status === 409 && e.corpo && e.corpo.limite) {
      if (confirm(e.message + '\n\nContinuar mesmo assim?')) { await salvarLancamento(true); return; }
    } else {
      mostrarToast(e.message);
    }
  } finally {
    botao.disabled = false;
    botao.textContent = 'Salvar lançamento';
  }
}
$('btnSalvarLancamento').addEventListener('click', () => salvarLancamento(false));

$('btnExcluirLancamento').addEventListener('click', async () => {
  if (!idLancAtual || !confirm('Excluir este lançamento definitivamente?')) return;
  try {
    await Api.del('/caixa/' + idLancAtual);
    mostrarToast('Lançamento excluído.');
    fecharPainelLanc();
    carregarLancamentos();
    carregarListaContas();
  } catch (e) { mostrarToast(e.message); }
});

// ================================================================= CONTAS DO CAIXA
async function carregarContas() {
  try {
    contas = (await Api.get('/contas-caixa')).dados;
  } catch (e) { mostrarToast(e.message); return; }

  $('gradeContas').innerHTML = contas.map((c) => {
    const limite = Number(c.limite_mensal) || 0;
    const usado = Number(c.usado_mes) || 0;
    const pct = limite > 0 ? Math.min(100, (usado / limite) * 100) : 0;
    const barra = limite > 0
      ? `<div class="barra-progresso ${usado > limite ? 'estourou' : ''}"><div style="width:${pct}%"></div></div>
         <div class="meta">${fmtMoeda(usado)} de ${fmtMoeda(limite)} usados este mês</div>`
      : `<div class="meta">Sem limite mensal</div>`;
    return `<div class="cartao cartao-conta" data-id="${c.id_conta}">
      <div class="cabecalho"><strong>${escaparHtml(c.descricao)}</strong>
        <div class="acoes"><button class="btn btn-icone btn-editar-conta" type="button" title="Editar">✎</button></div>
      </div>${barra}</div>`;
  }).join('') || '<p style="color:var(--tinta-suave);">Nenhuma conta cadastrada ainda.</p>';
}

$('gradeContas').addEventListener('click', (ev) => {
  const card = ev.target.closest('[data-id]');
  if (card) abrirEdicaoConta(Number(card.dataset.id));
});

const painelFundoConta = $('painelFundoConta');
const painelLateralConta = $('painelLateralConta');
let idContaAtual = null;

function abrirPainelConta(titulo) { $('tituloPainelConta').textContent = titulo; painelFundoConta.classList.add('aberto'); painelLateralConta.classList.add('aberto'); }
function fecharPainelConta() { painelFundoConta.classList.remove('aberto'); painelLateralConta.classList.remove('aberto'); }
$('btnFecharPainelConta').addEventListener('click', fecharPainelConta);
$('btnCancelarPainelConta').addEventListener('click', fecharPainelConta);
painelFundoConta.addEventListener('click', fecharPainelConta);

$('btnNovaConta').addEventListener('click', () => {
  idContaAtual = null;
  $('campoDescricaoConta').value = '';
  $('campoLimiteConta').value = '';
  $('btnExcluirConta').style.display = 'none';
  document.getElementById('painelLateralConta').dataset.novo = '1';
  abrirPainelConta('Nova conta do caixa');
});

function abrirEdicaoConta(id) {
  const c = contas.find((x) => x.id_conta === id);
  if (!c) return;
  idContaAtual = id;
  $('campoDescricaoConta').value = c.descricao || '';
  $('campoLimiteConta').value = c.limite_mensal == null ? '' : c.limite_mensal;
  $('btnExcluirConta').style.display = '';
  document.getElementById('painelLateralConta').dataset.novo = '0';
  abrirPainelConta(`Editar conta · cód. ${id}`);
}

$('btnSalvarConta').addEventListener('click', async () => {
  if (!$('formConta').reportValidity()) return;
  const payload = {
    descricao: $('campoDescricaoConta').value.trim(),
    limite_mensal: $('campoLimiteConta').value === '' ? null : Number($('campoLimiteConta').value),
  };
  try {
    if (idContaAtual) await Api.put('/contas-caixa/' + idContaAtual, payload);
    else await Api.post('/contas-caixa', payload);
    mostrarToast('Conta salva.');
    fecharPainelConta();
    carregarContas();
    carregarListaContas();
  } catch (e) { mostrarToast(e.message); }
});

$('btnExcluirConta').addEventListener('click', async () => {
  if (!idContaAtual || !confirm('Excluir esta conta?')) return;
  try {
    await Api.del('/contas-caixa/' + idContaAtual);
    mostrarToast('Conta excluída.');
    fecharPainelConta();
    carregarContas();
    carregarListaContas();
  } catch (e) { mostrarToast(e.message); }
});

// ================================================================= RESUMO
function primeiroUltimoDiaMes() {
  const d = new Date();
  const ini = new Date(d.getFullYear(), d.getMonth(), 1);
  const fim = new Date(d.getFullYear(), d.getMonth() + 1, 0);
  const f = (x) => `${x.getFullYear()}-${pad(x.getMonth() + 1)}-${pad(x.getDate())}`;
  return [f(ini), f(fim)];
}
const [iniMes, fimMes] = primeiroUltimoDiaMes();
$('resumoDe').value = iniMes;
$('resumoAte').value = fimMes;
$('btnResumoMesAtual').addEventListener('click', () => { $('resumoDe').value = iniMes; $('resumoAte').value = fimMes; carregarResumo(); });
$('resumoDe').addEventListener('change', carregarResumo);
$('resumoAte').addEventListener('change', carregarResumo);

async function carregarResumo() {
  const de = $('resumoDe').value;
  const ate = $('resumoAte').value;
  if (!de || !ate) return;

  try {
    const r = await Api.get(`/financeiro/resumo?de=${de}&ate=${ate}`);
    const entradasPeriodo = r.dias.reduce((s, d) => s + Number(d.entradas), 0);
    const saidasPeriodo = r.dias.reduce((s, d) => s + Number(d.saidas), 0);

    $('kpiSaldoAnterior').textContent = fmtMoeda(r.saldo_anterior);
    $('kpiSaldoPeriodo').textContent = fmtMoeda(entradasPeriodo - saidasPeriodo);
    $('kpiPrevisto').textContent = fmtMoeda(r.previsto);

    const max = Math.max(1, ...r.dias.map((d) => Math.max(Number(d.entradas), Number(d.saidas))));
    $('graficoDias').innerHTML = r.dias.length
      ? r.dias.map((d) => `<div class="barra-dia" title="${fmtDataBR(d.data)} · entradas ${fmtMoeda(d.entradas)} · saídas ${fmtMoeda(d.saidas)}">
          <div style="display:flex; align-items:flex-end; gap:2px; height:110px;">
            <div class="col e" style="height:${(Number(d.entradas) / max) * 100}%"></div>
            <div class="col s" style="height:${(Number(d.saidas) / max) * 100}%"></div>
          </div>
          <div class="rot">${fmtDataCurta(d.data)}</div></div>`).join('')
      : '<p style="color:var(--tinta-suave); font-size:13px;">Sem movimento no período.</p>';

    $('vazioResumo').style.display = r.contas.length ? 'none' : 'block';
    $('corpoResumoContas').innerHTML = r.contas.map((c) => `<tr>
        <td>${escaparHtml(c.descricao)}</td>
        <td class="valor-e">${fmtMoeda(c.entradas)}</td>
        <td class="valor-s">${fmtMoeda(c.saidas)}</td>
        <td>${fmtMoeda(Number(c.entradas) - Number(c.saidas))}</td>
      </tr>`).join('');
  } catch (e) { mostrarToast(e.message); }
}

// ---------------------------------------------------------------- início
carregarListaContas();
carregarLancamentos();
