// Rentabilidade por viagem (GET /api/rentabilidade). O servidor so junta os numeros de cada viagem;
// os totais, a margem e os agrupamentos (cliente, veiculo, mes) sao calculados aqui.
exigirLogin();

const $ = (id) => document.getElementById(id);

const usuarioLogado = Api.usuario();
if (usuarioLogado) {
  $('nomeUsuario').textContent = usuarioLogado.nome;
  $('perfilUsuario').textContent = usuarioLogado.perfil;
  $('avatarUsuario').textContent = usuarioLogado.nome.charAt(0).toUpperCase();
  if (usuarioLogado.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML;
}
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3600);
}

const brl = (n) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const pct = (n) => (n == null ? '—' : n.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%');
const fmtKm = (n) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: 0 });
const fmtData = (iso) => (iso ? String(iso).slice(0, 10).split('-').reverse().join('/') : '—');
const semAcento = (t) => String(t == null ? '' : t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const isoLocal = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const plural = (n, s, p) => (n === 1 ? s : p);

// ---------------------------------------------------------------- calculo
// Uma viagem do servidor -> viagem com receita liquida, custo, lucro e margem.
function calcular(l) {
  const receita = (Number(l.receita_bruta) || 0) - (Number(l.impostos) || 0);
  const custo = (Number(l.terceiros) || 0) + (Number(l.despesas) || 0);
  return { ...l, receita, custo, lucro: receita - custo, semAcerto: l.tem_acerto ? 0 : 1 };
}

// Soma um conjunto de viagens (ja calculadas). Margem so existe se houve receita.
function somar(linhas) {
  const t = { viagens: linhas.length, receita: 0, terceiros: 0, despesas: 0, custo: 0, lucro: 0, km: 0, semAcerto: 0 };
  linhas.forEach((l) => {
    t.receita += l.receita; t.terceiros += Number(l.terceiros) || 0; t.despesas += Number(l.despesas) || 0;
    t.custo += l.custo; t.lucro += l.lucro; t.km += Number(l.km) || 0; t.semAcerto += l.semAcerto;
  });
  t.margem = t.receita > 0 ? (t.lucro / t.receita) * 100 : null;
  t.receitaKm = t.km > 0 ? t.receita / t.km : null;
  t.custoKm = t.km > 0 ? t.custo / t.km : null;
  return t;
}

function chaveDoGrupo(modo, l) {
  if (modo === 'cliente') return { chave: l.cliente || '(sem cliente)', rotulo: l.cliente || '(sem cliente)' };
  if (modo === 'veiculo') {
    return l.id_veiculo
      ? { chave: `V${l.id_veiculo}`, rotulo: `Veículo ${l.veiculo_numero} · ${l.placa}` }
      : { chave: 'V0', rotulo: 'Sem veículo próprio (terceiros)' };
  }
  const ym = String(l.data_saida || '').slice(0, 7);   // AAAA-MM
  return { chave: ym, rotulo: ym ? `${ym.slice(5, 7)}/${ym.slice(0, 4)}` : '(sem data)' };
}

function agrupar(modo, linhas) {
  const mapa = new Map();
  linhas.forEach((l) => {
    const g = chaveDoGrupo(modo, l);
    if (!mapa.has(g.chave)) mapa.set(g.chave, { chave: g.chave, rotulo: g.rotulo, itens: [] });
    mapa.get(g.chave).itens.push(l);
  });
  return Array.from(mapa.values()).map((g) => ({ chave: g.chave, rotulo: g.rotulo, ...somar(g.itens) }));
}

// ---------------------------------------------------------------- estado e tela
let viagens = [];            // ja calculadas
let truncado = false;
const estado = { modo: 'viagem', busca: '', ordem: { campo: 'data', dir: -1 } };

const ORDEM_PADRAO = { viagem: { campo: 'data', dir: -1 }, cliente: { campo: 'receita', dir: -1 }, veiculo: { campo: 'receita', dir: -1 }, mes: { campo: 'rotulo', dir: -1 } };

const COLUNAS = {
  viagem: [
    { k: 'data', t: 'Data', v: (l) => l.data_saida || '' },
    { k: 'cliente', t: 'Cliente', v: (l) => semAcento(l.cliente) },
    { k: 'rota', t: 'Rota', v: (l) => semAcento(`${l.origem} ${l.destino}`) },
    { k: 'veiculo', t: 'Veículo', v: (l) => semAcento(l.placa || '') },
    { k: 'receita', t: 'Receita líq.', n: 1, v: (l) => l.receita },
    { k: 'terceiros', t: 'Terceiros', n: 1, v: (l) => Number(l.terceiros) || 0 },
    { k: 'despesas', t: 'Despesas', n: 1, v: (l) => Number(l.despesas) || 0 },
    { k: 'lucro', t: 'Lucro', n: 1, v: (l) => l.lucro },
    { k: 'margem', t: 'Margem', n: 1, v: (l) => (l.receita > 0 ? l.lucro / l.receita : -Infinity) },
    { k: 'custokm', t: 'Custo/km', n: 1, v: (l) => ((Number(l.km) || 0) > 0 ? l.custo / l.km : -Infinity) },
  ],
  grupo: [
    { k: 'rotulo', t: 'Grupo', v: (g) => g.chave },
    { k: 'viagens', t: 'Viagens', n: 1, v: (g) => g.viagens },
    { k: 'receita', t: 'Receita líq.', n: 1, v: (g) => g.receita },
    { k: 'custo', t: 'Custos', n: 1, v: (g) => g.custo },
    { k: 'lucro', t: 'Lucro', n: 1, v: (g) => g.lucro },
    { k: 'margem', t: 'Margem', n: 1, v: (g) => (g.margem == null ? -Infinity : g.margem) },
    { k: 'receitakm', t: 'Receita/km', n: 1, v: (g) => (g.receitaKm == null ? -Infinity : g.receitaKm) },
    { k: 'custokm', t: 'Custo/km', n: 1, v: (g) => (g.custoKm == null ? -Infinity : g.custoKm) },
    { k: 'semacerto', t: 'Sem acerto', n: 1, v: (g) => g.semAcerto },
  ],
};

function badgeMargem(margem) {
  if (margem == null) return '<span class="nota">—</span>';
  const cls = margem < 0 ? 'badge-perigo' : margem < 10 ? 'badge-alerta' : 'badge-ativo';
  return `<span class="badge ${cls}">${pct(margem)}</span>`;
}
const valorLucro = (n) => `<span class="${n < 0 ? 'neg' : ''}">${brl(n)}</span>`;

function filtradas() {
  const termo = semAcento(estado.busca.trim());
  if (!termo) return viagens;
  return viagens.filter((l) => semAcento(`${l.cliente} ${l.origem} ${l.destino} ${l.placa || ''} ${l.veiculo_numero || ''}`).includes(termo));
}

function renderizarResumo(linhas) {
  const t = somar(linhas);
  $('kReceita').textContent = brl(t.receita);
  $('kReceitaSub').textContent = `${t.viagens} ${plural(t.viagens, 'viagem', 'viagens')}`;
  $('kCustos').textContent = brl(t.custo);
  $('kLucro').textContent = brl(t.lucro);
  $('cartaoLucro').classList.toggle('perigo', t.lucro < 0);
  $('kLucroSub').textContent = t.semAcerto
    ? `${t.semAcerto} ${plural(t.semAcerto, 'viagem sem acerto', 'viagens sem acerto')}: lucro provisório`
    : 'todas as viagens com acerto lançado';
  $('kMargem').textContent = pct(t.margem);
  $('kMargemSub').textContent = t.km > 0 ? `${fmtKm(t.km)} km · custo ${brl(t.custoKm)}/km` : '';
  return t;
}

function renderizarTabela(linhas, total) {
  const modo = estado.modo;
  const cols = COLUNAS[modo === 'viagem' ? 'viagem' : 'grupo'];
  const itens = modo === 'viagem' ? linhas.slice() : agrupar(modo, linhas);

  const col = cols.find((c) => c.k === estado.ordem.campo) || cols[0];
  itens.sort((a, b) => {
    const x = col.v(a), y = col.v(b);
    const r = typeof x === 'string' ? x.localeCompare(y, 'pt-BR') : x - y;
    return r * estado.ordem.dir;
  });

  $('cabTabela').innerHTML = '<tr>' + cols.map((c) => {
    const seta = c.k === estado.ordem.campo ? (estado.ordem.dir < 0 ? ' ▼' : ' ▲') : '';
    return `<th class="ord${c.n ? ' n' : ''}" data-ordem="${c.k}">${c.t}${seta}</th>`;
  }).join('') + '</tr>';

  const corpo = $('corpoTabela');
  corpo.innerHTML = '';
  itens.forEach((it) => {
    const tr = document.createElement('tr');
    tr.className = 'sem-link';
    if (modo === 'viagem') {
      const pendente = it.status === 'P' ? ' <span class="badge badge-alerta">pendente</span>' : '';
      const acerto = it.tem_acerto ? '' : ' <span class="badge badge-alerta" title="Sem despesas lançadas no acerto de viagem">sem acerto</span>';
      const rota = [it.origem, it.destino].filter(Boolean).join(' → ') || '—';
      const custoKm = (Number(it.km) || 0) > 0 ? brl(it.custo / it.km) : '—';
      tr.innerHTML = `
        <td>${fmtData(it.data_saida)}${pendente}</td>
        <td>${escaparHtml(it.cliente)}</td>
        <td>${escaparHtml(rota)}</td>
        <td>${it.placa ? `<span class="placa">${escaparHtml(it.placa)}</span>` : '<span class="nota">terceiros</span>'}</td>
        <td class="n">${brl(it.receita)}</td>
        <td class="n">${brl(it.terceiros)}</td>
        <td class="n">${brl(it.despesas)}${acerto}</td>
        <td class="n">${valorLucro(it.lucro)}</td>
        <td class="n">${badgeMargem(it.receita > 0 ? (it.lucro / it.receita) * 100 : null)}</td>
        <td class="n">${custoKm}</td>`;
    } else {
      tr.innerHTML = `
        <td><strong>${escaparHtml(it.rotulo)}</strong></td>
        <td class="n">${it.viagens}</td>
        <td class="n">${brl(it.receita)}</td>
        <td class="n">${brl(it.custo)}</td>
        <td class="n">${valorLucro(it.lucro)}</td>
        <td class="n">${badgeMargem(it.margem)}</td>
        <td class="n">${it.receitaKm == null ? '—' : brl(it.receitaKm)}</td>
        <td class="n">${it.custoKm == null ? '—' : brl(it.custoKm)}</td>
        <td class="n">${it.semAcerto || '—'}</td>`;
    }
    corpo.appendChild(tr);
  });

  // rodape com o total do que esta na tela
  if (itens.length) {
    const tf = document.createElement('tr');
    tf.className = 'sem-link';
    tf.style.fontWeight = '600';
    tf.style.background = '#F7F8F5';
    if (modo === 'viagem') {
      tf.innerHTML = `<td colspan="4">Total · ${total.viagens} ${plural(total.viagens, 'viagem', 'viagens')}</td>
        <td class="n">${brl(total.receita)}</td><td class="n">${brl(total.terceiros)}</td><td class="n">${brl(total.despesas)}</td>
        <td class="n">${valorLucro(total.lucro)}</td><td class="n">${badgeMargem(total.margem)}</td>
        <td class="n">${total.custoKm == null ? '—' : brl(total.custoKm)}</td>`;
    } else {
      tf.innerHTML = `<td>Total</td><td class="n">${total.viagens}</td><td class="n">${brl(total.receita)}</td><td class="n">${brl(total.custo)}</td>
        <td class="n">${valorLucro(total.lucro)}</td><td class="n">${badgeMargem(total.margem)}</td>
        <td class="n">${total.receitaKm == null ? '—' : brl(total.receitaKm)}</td><td class="n">${total.custoKm == null ? '—' : brl(total.custoKm)}</td>
        <td class="n">${total.semAcerto || '—'}</td>`;
    }
    corpo.appendChild(tf);
  }
  $('vazio').style.display = itens.length ? 'none' : 'block';
}

function renderizar() {
  const linhas = filtradas();
  const total = renderizarResumo(linhas);
  renderizarTabela(linhas, total);
  const aviso = $('avisoTruncado');
  aviso.style.display = truncado ? 'block' : 'none';
  if (truncado) aviso.textContent = 'O período tem mais viagens do que o limite de 2.000: reduza as datas para ver tudo.';
  $('geradoEm').textContent = `Rentabilidade de ${fmtData($('fDe').value)} a ${fmtData($('fAte').value)} · gerado em ${new Date().toLocaleString('pt-BR')}`;
}

async function carregar() {
  const de = $('fDe').value, ate = $('fAte').value;
  if (!de || !ate) return;
  if (de > ate) { mostrarToast('A data inicial não pode ser depois da final.'); return; }
  const q = new URLSearchParams({ de, ate });
  if ($('fPendentes').checked) q.set('incluir_pendentes', '1');
  try {
    const r = await Api.get('/rentabilidade?' + q.toString());
    viagens = (r.dados || []).map(calcular);
    truncado = !!r.truncado;
  } catch (e) {
    mostrarToast(e.message);
    return;
  }
  renderizar();
}

function definirPeriodo(atalho) {
  const hoje = new Date();
  const ini = new Date(hoje);
  if (atalho === 'ano') ini.setMonth(0, 1); else ini.setDate(ini.getDate() - Number(atalho));
  $('fDe').value = isoLocal(ini);
  $('fAte').value = isoLocal(hoje);
}

document.querySelectorAll('[data-atalho]').forEach((b) => b.addEventListener('click', () => { definirPeriodo(b.dataset.atalho); carregar(); }));
$('fDe').addEventListener('change', carregar);
$('fAte').addEventListener('change', carregar);
$('fPendentes').addEventListener('change', carregar);
$('fBusca').addEventListener('input', (ev) => { estado.busca = ev.target.value; renderizar(); });
$('fAgrupar').addEventListener('change', (ev) => {
  estado.modo = ev.target.value;
  estado.ordem = { ...ORDEM_PADRAO[estado.modo] };
  renderizar();
});
$('cabTabela').addEventListener('click', (ev) => {
  const th = ev.target.closest('th[data-ordem]');
  if (!th) return;
  const campo = th.dataset.ordem;
  estado.ordem = estado.ordem.campo === campo ? { campo, dir: -estado.ordem.dir } : { campo, dir: -1 };
  renderizar();
});
$('btnImprimir').addEventListener('click', () => window.print());

definirPeriodo('90');
carregar();
