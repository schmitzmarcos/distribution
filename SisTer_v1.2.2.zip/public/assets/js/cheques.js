exigirLogin();

const $ = (id) => document.getElementById(id);

const usuario = Api.usuario();
if (usuario) {
  $('nomeUsuario').textContent = usuario.nome;
  $('perfilUsuario').textContent = usuario.perfil;
  $('avatarUsuario').textContent = usuario.nome.charAt(0).toUpperCase();
  if (usuario.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3600);
}
function fmtDataBR(s) { if (!s) return '—'; const [a, m, d] = s.split('-'); return `${d}/${m}/${a}`; }
const fmtMoeda = (n) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

let tipoAtual = 'A';
let cheques = [];
let busca = '';

const COLS = {
  A: [['id_cheque', 'Cód.'], ['data', 'Data'], ['emitente', 'Cheque de'], ['banco', 'Banco'], ['praca', 'Praça'], ['numero', 'Nº'], ['vencimento', 'Vencto.'], ['status', 'Status']],
  T: [['id_cheque', 'Cód.'], ['data', 'Data'], ['recebido_de', 'Recebido de'], ['destino', 'Destino'], ['valor_entrada', 'Vl. entrada'], ['valor_saida', 'Vl. saída'], ['vencimento', 'Vencto.'], ['status', 'Status']],
};

document.querySelectorAll('.aba-pagina').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('.aba-pagina').forEach((x) => x.classList.toggle('ativa', x === b));
  tipoAtual = b.dataset.tipo;
  document.getElementById('camposAgencia').style.display = tipoAtual === 'A' ? '' : 'none';
  document.getElementById('camposTerceiros').style.display = tipoAtual === 'T' ? '' : 'none';
  carregar();
}));

async function carregar() {
  const q = new URLSearchParams({ tipo: tipoAtual });
  if (busca.trim()) q.set('busca', busca.trim());

  try {
    const r = await Api.get('/cheques?' + q.toString());
    cheques = r.dados;
    $('kpiEntrada').textContent = fmtMoeda(r.totais.entrada);
    $('kpiSaida').textContent = fmtMoeda(r.totais.saida);
    render();
  } catch (e) { mostrarToast(e.message); }
}

$('campoBusca').addEventListener('input', (ev) => { busca = ev.target.value; clearTimeout(window._t); window._t = setTimeout(carregar, 350); });

function render() {
  const cols = COLS[tipoAtual];
  document.querySelector('#tabelaCheques thead tr').innerHTML = cols.map((c) => `<th${c[0] === 'id_cheque' ? ' class="cod"' : ''}>${c[1]}</th>`).join('');

  const corpo = $('corpoCheques');
  corpo.innerHTML = '';
  $('estadoVazio').style.display = cheques.length ? 'none' : 'block';

  cheques.forEach((c) => {
    const tr = document.createElement('tr');
    tr.innerHTML = cols.map(([k]) => {
      let v = c[k];
      if (k === 'data' || k === 'vencimento') v = fmtDataBR(v);
      else if (k === 'valor_entrada' || k === 'valor_saida') v = v ? fmtMoeda(v) : '—';
      else v = escaparHtml(v) || '—';
      return `<td${k === 'id_cheque' ? ' class="cod"' : ''}>${v}</td>`;
    }).join('');
    tr.addEventListener('click', () => abrirEdicao(c.id_cheque));
    corpo.appendChild(tr);
  });
}

// ---------------------------------------------------------------- painel
const painelFundo = $('painelFundo');
const painelLateral = $('painelLateral');
let idAtual = null;

function abrirPainel(titulo) { $('tituloPainel').textContent = titulo; painelFundo.classList.add('aberto'); painelLateral.classList.add('aberto'); }
function fecharPainel() { painelFundo.classList.remove('aberto'); painelLateral.classList.remove('aberto'); }
$('btnFecharPainel').addEventListener('click', fecharPainel);
$('btnCancelarPainel').addEventListener('click', fecharPainel);
painelFundo.addEventListener('click', fecharPainel);

document.querySelectorAll('input[name="tipoCheque"]').forEach((r) => r.addEventListener('change', () => {
  document.getElementById('camposAgencia').style.display = r.value === 'A' ? '' : 'none';
  document.getElementById('camposTerceiros').style.display = r.value === 'T' ? '' : 'none';
}));

function preencher(c) {
  document.querySelectorAll('#formCheque [data-campo]').forEach((el) => {
    const val = c ? c[el.dataset.campo] : undefined;
    el.value = val == null ? '' : val;
  });
  const tipo = (c && c.tipo) || tipoAtual;
  document.querySelectorAll('input[name="tipoCheque"]').forEach((r) => { r.checked = r.value === tipo; r.dispatchEvent(new Event('change')); });
}

function coletar() {
  const d = {};
  document.querySelectorAll('#formCheque [data-campo]').forEach((el) => {
    const k = el.dataset.campo;
    d[k] = el.type === 'number' ? (el.value === '' ? null : Number(el.value)) : el.value.trim();
  });
  const r = document.querySelector('input[name="tipoCheque"]:checked');
  d.tipo = r ? r.value : 'A';
  return d;
}

$('btnNovo').addEventListener('click', () => {
  idAtual = null;
  preencher(null);
  $('btnExcluir').style.display = 'none';
  document.getElementById('painelLateral').dataset.novo = '1';
  abrirPainel('Novo cheque');
});

async function abrirEdicao(id) {
  const c = cheques.find((x) => x.id_cheque === id);
  if (!c) return;
  idAtual = id;
  preencher(c);
  $('btnExcluir').style.display = '';
  document.getElementById('painelLateral').dataset.novo = '0';
  abrirPainel(`Cheque${c.numero ? ' nº ' + c.numero : ''} · cód. ${c.id_cheque}`);
}

$('btnSalvar').addEventListener('click', async () => {
  const payload = coletar();
  const botao = $('btnSalvar');
  botao.disabled = true;
  botao.textContent = 'Salvando...';
  try {
    if (idAtual) await Api.put('/cheques/' + idAtual, payload);
    else await Api.post('/cheques', payload);
    mostrarToast(idAtual ? 'Cheque atualizado.' : 'Cheque registrado.');
    fecharPainel();
    carregar();
  } catch (e) { mostrarToast(e.message); }
  finally { botao.disabled = false; botao.textContent = 'Salvar cheque'; }
});

$('btnExcluir').addEventListener('click', async () => {
  if (!idAtual || !confirm('Excluir este cheque?')) return;
  try {
    await Api.del('/cheques/' + idAtual);
    mostrarToast('Cheque excluído.');
    fecharPainel();
    carregar();
  } catch (e) { mostrarToast(e.message); }
});

carregar();
