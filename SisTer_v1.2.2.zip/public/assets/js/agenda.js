exigirLogin();

const $ = (id) => document.getElementById(id);

const usuario = Api.usuario();
if (usuario) {
  $('nomeUsuario').textContent = usuario.nome;
  $('perfilUsuario').textContent = usuario.perfil;
  $('avatarUsuario').textContent = usuario.nome.charAt(0).toUpperCase();
  if (usuario.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

// ---------------------------------------------------------------- helpers
function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3600);
}
const pad = (n) => String(n).padStart(2, '0');
const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const hojeISO = () => iso(new Date());
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const doISO = (s) => new Date(s + 'T00:00:00');
function fmtDataCurta(s) { if (!s) return ''; const [, m, d] = s.split('-'); return `${d}/${m}`; }
const fmtMoeda = (n) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const OPC = [
  ['opc_refrigerante', 'Refrigerante'], ['opc_agua_mineral', 'Água mineral'], ['opc_chocolate_quente', 'Chocolate quente'],
  ['opc_sanduiche', 'Sanduíche'], ['opc_bombom', 'Bombom'], ['opc_balas', 'Balas'], ['opc_tapete', 'Tapete'],
  ['opc_travesseiros', 'Travesseiros'], ['opc_cabeceiras', 'Cabeceiras'], ['opc_salgados', 'Salgados'],
];
$('gradeOpc').innerHTML = OPC.map(([k, r]) => `<label class="chip"><input type="checkbox" data-campo="${k}"> ${r}</label>`).join('');

// ---------------------------------------------------------------- estado
let mes = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
let diaSel = hojeISO();
let viagens = [];
let veiculos = [];
let motoristas = [];
let idAtual = null;

// ---------------------------------------------------------------- carga do mês
function inicioGrade(m) {
  const p = new Date(m.getFullYear(), m.getMonth(), 1);
  return new Date(p.getFullYear(), p.getMonth(), 1 - p.getDay());
}

async function carregarMes() {
  const ini = inicioGrade(mes);
  const fim = new Date(ini.getFullYear(), ini.getMonth(), ini.getDate() + 41);
  try {
    const r = await Api.get(`/faturas?de=${iso(ini)}&ate=${iso(fim)}`);
    viagens = r.dados;
  } catch (e) {
    viagens = [];
    mostrarToast(e.message);
  }
  renderCalendario();
  renderDia();
}

// ---------------------------------------------------------------- calendário
function renderCalendario() {
  $('tituloMes').textContent = cap(mes.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }));

  const porDia = {};
  viagens.forEach((v) => {
    if (!v.data_saida) return;
    if (!porDia[v.data_saida]) porDia[v.data_saida] = [];
    porDia[v.data_saida].push(v.status);
  });

  const ini = inicioGrade(mes);
  const hoje = hojeISO();
  let html = '';
  for (let i = 0; i < 42; i++) {
    const d = new Date(ini.getFullYear(), ini.getMonth(), ini.getDate() + i);
    const s = iso(d);
    const sts = porDia[s] || [];
    const pontos = sts.slice(0, 5).map((x) => `<i class="ponto ${x === 'P' ? 'pend' : ''}"></i>`).join('');
    const mais = sts.length > 5 ? `<span class="mais">+${sts.length - 5}</span>` : '';
    const cls = ['dia', d.getMonth() !== mes.getMonth() ? 'fora' : '', s === hoje ? 'hoje' : '', s === diaSel ? 'sel' : ''].join(' ');
    html += `<button type="button" class="${cls}" data-dia="${s}" aria-label="${s}"><span class="num">${d.getDate()}</span><span class="pontos">${pontos}${mais}</span></button>`;
  }
  $('calDias').innerHTML = html;

  const chave = `${mes.getFullYear()}-${pad(mes.getMonth() + 1)}`;
  const doMes = viagens.filter((v) => v.data_saida && v.data_saida.slice(0, 7) === chave);
  const pend = doMes.filter((v) => v.status === 'P').length;
  $('resumoMes').textContent = `${doMes.length} ${doMes.length === 1 ? 'saída' : 'saídas'} no mês${pend ? ' · ' + pend + ' pendente' + (pend > 1 ? 's' : '') : ''}`;
}

$('calDias').addEventListener('click', (ev) => {
  const b = ev.target.closest('[data-dia]');
  if (!b) return;
  const d = doISO(b.dataset.dia);
  diaSel = b.dataset.dia;
  if (d.getMonth() !== mes.getMonth()) {
    mes = new Date(d.getFullYear(), d.getMonth(), 1);
    carregarMes();
  } else {
    renderCalendario();
    renderDia();
  }
});

function irParaMes(novo) {
  mes = novo;
  const hoje = new Date();
  diaSel = (hoje.getFullYear() === mes.getFullYear() && hoje.getMonth() === mes.getMonth()) ? hojeISO() : iso(mes);
  carregarMes();
}
$('btnMesAnterior').addEventListener('click', () => irParaMes(new Date(mes.getFullYear(), mes.getMonth() - 1, 1)));
$('btnMesProximo').addEventListener('click', () => irParaMes(new Date(mes.getFullYear(), mes.getMonth() + 1, 1)));
$('btnHoje').addEventListener('click', () => irParaMes(new Date(new Date().getFullYear(), new Date().getMonth(), 1)));

// ---------------------------------------------------------------- painel do dia
function cardViagem(v, emAndamento) {
  const rota = [
    [v.origem, v.uf_origem].filter(Boolean).join('/'),
    [v.destino, v.uf_destino].filter(Boolean).join('/'),
  ];
  const roteiro = (rota[0] || rota[1]) ? `${escaparHtml(rota[0] || '—')} → ${escaparHtml(rota[1] || '—')}` : 'Roteiro não informado';

  const volta = [
    v.data_volta && v.data_volta !== v.data_saida ? fmtDataCurta(v.data_volta) : '',
    v.hora_volta || '',
  ].filter(Boolean).join(' ');

  const horario = emAndamento
    ? 'Em viagem'
    : (v.hora_saida || 'Sem horário');
  const detalheHorario = emAndamento
    ? `saiu ${fmtDataCurta(v.data_saida)} · volta ${volta || fmtDataCurta(v.data_volta) || '—'}`
    : (volta ? `volta ${volta}` : '');

  const veic = v.veiculo_numero ? `Nº ${v.veiculo_numero} · ${v.veiculo_placa}` : 'Sem veículo';
  const mot = [v.motorista1_nome, v.motorista2_nome].filter(Boolean).join(' e ') || 'Sem motorista';
  const pend = v.status === 'P';

  return `<button type="button" class="viagem ${pend ? 'pend' : ''} ${emAndamento ? 'andamento' : ''}" data-id="${v.id_fatura}">
    <div class="linha1">
      <span class="horario">${escaparHtml(horario)}</span>
      <span class="badge ${pend ? 'badge-alerta' : 'badge-ativo'}">${pend ? 'Pendente' : 'Confirmada'}</span>
    </div>
    ${detalheHorario ? `<div class="meta" style="margin-bottom:2px;">${escaparHtml(detalheHorario)}</div>` : ''}
    <div class="rota">${roteiro}</div>
    <div class="meta"><span>${escaparHtml(v.cliente_nome || 'Cliente não informado')}</span><span>${escaparHtml(veic)}</span><span>${escaparHtml(mot)}</span></div>
  </button>`;
}

function renderDia() {
  const d = doISO(diaSel);
  $('diaTitulo').textContent = cap(d.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' }));

  const saidas = viagens.filter((v) => v.data_saida === diaSel);
  const andamento = viagens.filter((v) => v.data_saida < diaSel && (v.data_volta || v.data_saida) >= diaSel);
  $('diaSub').textContent = `${saidas.length} ${saidas.length === 1 ? 'saída' : 'saídas'} · ${andamento.length} em viagem`;

  let html = '';
  if (!saidas.length && !andamento.length) {
    html = '<div class="estado-vazio"><div class="fonte-display">Dia livre</div><p>Nenhuma viagem neste dia. Use “+ Nova viagem” para agendar.</p></div>';
  } else {
    if (saidas.length) html += '<div class="grupo-titulo" style="margin-top:0;">SAÍDAS DO DIA</div>' + saidas.map((v) => cardViagem(v, false)).join('');
    if (andamento.length) html += '<div class="grupo-titulo">JÁ EM VIAGEM</div>' + andamento.map((v) => cardViagem(v, true)).join('');
  }
  $('diaConteudo').innerHTML = html;
}

$('diaConteudo').addEventListener('click', (ev) => {
  const b = ev.target.closest('[data-id]');
  if (b) abrirEdicao(Number(b.dataset.id));
});

// ---------------------------------------------------------------- listas (veículos / motoristas)
async function carregarListas() {
  try { veiculos = (await Api.get('/frota?somente_ativos=1&itens_por_pagina=200')).dados; } catch (e) { veiculos = []; }
  try {
    const todos = (await Api.get('/motoristas')).dados;   // lista minima: nao exige acesso ao cadastro de funcionarios
    const soMot = todos.filter((f) => f.tipo === 'Motorista');
    motoristas = soMot.length ? soMot : todos; // se ninguém estiver marcado como Motorista, oferece todos
  } catch (e) { motoristas = []; }

  $('selVeiculo').innerHTML = '<option value="">— sem veículo definido —</option>' +
    veiculos.map((v) => `<option value="${v.id_veiculo}">${escaparHtml(v.numero)} · ${escaparHtml(v.placa)}${v.marca || v.modelo ? ' · ' + escaparHtml([v.marca, v.modelo].filter(Boolean).join(' ')) : ''}</option>`).join('');
  const optMot = '<option value="">—</option>' + motoristas.map((f) => `<option value="${f.id_funcionario}">${escaparHtml(f.nome)}</option>`).join('');
  $('selMot1').innerHTML = optMot;
  $('selMot2').innerHTML = optMot;
}

// garante que um veículo/motorista hoje inativo continue aparecendo ao editar uma viagem antiga
function garantirOpcao(sel, id, texto) {
  if (!id || sel.querySelector(`option[value="${id}"]`)) return;
  const o = document.createElement('option');
  o.value = id;
  o.textContent = texto + ' (inativo)';
  sel.appendChild(o);
}

// ---------------------------------------------------------------- cliente (autocomplete)
let tCliente = null;
const campoClienteTexto = $('campoClienteTexto');
const sugestoes = $('sugestoesCliente');

campoClienteTexto.addEventListener('input', (ev) => {
  $('campoClienteId').value = ''; // texto mudou: a seleção anterior deixa de valer
  clearTimeout(tCliente);
  const t = ev.target.value.trim();
  if (t.length < 2) { sugestoes.style.display = 'none'; return; }
  tCliente = setTimeout(async () => {
    try {
      const r = await Api.get('/clientes?busca=' + encodeURIComponent(t) + '&itens_por_pagina=8');
      sugestoes.innerHTML = r.dados.length
        ? r.dados.map((c) => `<button type="button" data-id="${c.id_cliente}" data-nome="${escaparHtml(c.nome)}">${escaparHtml(c.nome)}<small>${escaparHtml([c.cnpj_cpf, c.cidade].filter(Boolean).join(' · '))}</small></button>`).join('')
        : '<div style="padding:10px 12px; color:var(--tinta-suave); font-size:13px;">Nenhum cliente encontrado.</div>';
      sugestoes.style.display = 'block';
    } catch (e) { sugestoes.style.display = 'none'; }
  }, 250);
});

sugestoes.addEventListener('click', (ev) => {
  const b = ev.target.closest('button[data-id]');
  if (!b) return;
  $('campoClienteId').value = b.dataset.id;
  campoClienteTexto.value = b.dataset.nome;
  sugestoes.style.display = 'none';
});
document.addEventListener('click', (ev) => { if (!ev.target.closest('.autocomplete')) sugestoes.style.display = 'none'; });

// ---------------------------------------------------------------- formulário
function preencher(f) {
  document.querySelectorAll('#formFatura [data-campo]').forEach((el) => {
    const val = f ? f[el.dataset.campo] : undefined;
    if (el.type === 'checkbox') el.checked = Number(val) === 1;
    else el.value = val == null ? '' : val;
  });
  const imp = (f && f.imposto) || '';
  document.querySelectorAll('input[name="imposto"]').forEach((r) => { r.checked = r.value === imp; });
}

function coletar() {
  const d = {};
  document.querySelectorAll('#formFatura [data-campo]').forEach((el) => {
    const k = el.dataset.campo;
    if (el.type === 'checkbox') d[k] = el.checked ? 1 : 0;
    else if (el.type === 'number' || el.dataset.int) d[k] = el.value === '' ? null : Number(el.value);
    else d[k] = el.value.trim();
  });
  const r = document.querySelector('input[name="imposto"]:checked');
  d.imposto = r ? r.value : '';
  return d;
}

// mesma fórmula do back-end (o servidor recalcula e é quem vale)
function calcularLiquido() {
  const nota = Number($('campoValorNota').value) || 0;
  const r = document.querySelector('input[name="imposto"]:checked');
  const aliquotas = { municipal_3: 0.03, municipal_12: 0.12, intermunicipal_12_sobre_20: 0.20 * 0.12, intermunicipal_17: 0.17 };
  const aliq = aliquotas[r ? r.value : ''] || 0;
  const ret = $('chkRetencao').checked ? 0.30 * 0.11 : 0;
  $('valorLiquido').textContent = fmtMoeda(Math.round((nota - nota * aliq - nota * ret) * 100) / 100);
}
$('campoValorNota').addEventListener('input', calcularLiquido);
$('chkRetencao').addEventListener('change', calcularLiquido);
document.querySelectorAll('input[name="imposto"]').forEach((r) => r.addEventListener('change', calcularLiquido));

// ---------------------------------------------------------------- conflitos em tempo real
let tConf = null;
function agendarConflitos() { clearTimeout(tConf); tConf = setTimeout(verificarConflitos, 400); }
['selVeiculo', 'selMot1', 'selMot2'].forEach((id) => $(id).addEventListener('change', agendarConflitos));
['data_saida', 'hora_saida', 'data_volta', 'hora_volta'].forEach((k) =>
  document.querySelector(`[data-campo="${k}"]`).addEventListener('change', agendarConflitos));

function textoConflito(c) {
  const quando = `${fmtDataCurta(c.data_saida)}${c.hora_saida ? ' ' + c.hora_saida : ''}${c.data_volta ? ' → ' + fmtDataCurta(c.data_volta) + (c.hora_volta ? ' ' + c.hora_volta : '') : ''}`;
  return `${escaparHtml(c.cliente_nome || 'viagem')} (${quando}, fatura ${c.id_fatura})`;
}

async function verificarConflitos() {
  const box = $('alertaConflitos');
  box.className = 'alerta-conflito';
  box.innerHTML = '';
  const c = coletar();
  if (!c.data_saida || (!c.id_veiculo && !c.id_funcionario1 && !c.id_funcionario2)) return;

  const q = new URLSearchParams({
    data_saida: c.data_saida, hora_saida: c.hora_saida || '', data_volta: c.data_volta || '', hora_volta: c.hora_volta || '',
    id_veiculo: c.id_veiculo || '', id_funcionario1: c.id_funcionario1 || '', id_funcionario2: c.id_funcionario2 || '',
    excluir: idAtual || '',
  });

  try {
    const resp = await Api.get('/agenda/conflitos?' + q.toString());
    const lista = resp.conflitos || [];
    const avisos = resp.avisos || [];
    if (!lista.length && !avisos.length) return;
    const nome = (sel) => { const o = $(sel).selectedOptions[0]; return o ? o.textContent : 'Motorista'; };
    const CATEG = { mecanica: 'mecânica', eletrica: 'elétrica', pneus: 'pneus', freios: 'freios', ar_condicionado: 'ar-condicionado', lataria: 'lataria e pintura', revisao: 'revisão', outro: 'outro problema' };
    const linhasAviso = avisos.map((x) => `<strong>Veículo parado para manutenção</strong> (${escaparHtml(CATEG[x.categoria] || 'manutenção')}) desde ${fmtDataCurta(String(x.desde).slice(0, 10))}, ` +
      (x.previsao ? `com volta prevista só em ${fmtDataCurta(x.previsao)}, depois da saída` : 'sem previsão de volta') + '. Confirme antes de escalar.');
    const linhas = lista.map((x) => {
      if (x.tipo === 'veiculo') return `<strong>Veículo já ocupado</strong> em ${textoConflito(x)}.`;
      return `<strong>${escaparHtml(nome(x.tipo === 'motorista1' ? 'selMot1' : 'selMot2'))}</strong> já está escalado(a) em ${textoConflito(x)}.`;
    });
    const bloqueia = lista.some((x) => x.tipo === 'veiculo');
    box.className = 'alerta-conflito ' + (bloqueia ? 'bloqueia' : 'aviso');
    box.innerHTML = linhasAviso.concat(linhas).join('<br>') + (bloqueia ? '<br>Não será possível salvar com o veículo em conflito.' : '');
  } catch (e) { /* aviso é só informativo: falha silenciosa */ }
}

// ---------------------------------------------------------------- abas do painel da fatura
function ativarAbaFatura(nome) {
  document.querySelectorAll('#abasFatura .aba').forEach((b) => b.classList.toggle('ativa', b.dataset.aba === nome));
  document.querySelectorAll('.painel-corpo > [data-pane]').forEach((p) => p.classList.toggle('ativo', p.dataset.pane === nome));

  const naViagem = nome === 'viagem';
  $('btnSalvar').style.display = naViagem ? '' : 'none';
  $('btnCancelarPainel').textContent = naViagem ? 'Cancelar' : 'Fechar';

  if (nome === 'passageiros') { $('avisoSalvarPrimeiro').style.display = idAtual ? 'none' : 'block'; $('blocoPassageiros').style.display = idAtual ? '' : 'none'; if (idAtual) carregarPax(); }
  if (nome === 'despesas') { $('avisoSalvarPrimeiroDespesas').style.display = idAtual ? 'none' : 'block'; $('formGastos').style.display = idAtual ? '' : 'none'; if (idAtual) carregarGastos(); }
  if (nome === 'imprimir') {
    $('avisoSalvarPrimeiroImprimir').style.display = idAtual ? 'none' : 'block';
    $('blocoImprimir').style.display = idAtual ? '' : 'none';
    if (idAtual) {
      $('linkListaPax').href = `relatorios/lista-passageiros.html?fatura=${idAtual}`;
      $('linkEtiqueta').href = `relatorios/etiqueta-embarque.html?fatura=${idAtual}`;
      $('linkControle').href = `relatorios/controle-viagem.html?fatura=${idAtual}`;
    }
  }
}
document.querySelectorAll('#abasFatura .aba').forEach((b) => b.addEventListener('click', () => ativarAbaFatura(b.dataset.aba)));

// ---- Passageiros
let paxEditId = null;

async function carregarPax() {
  try {
    const r = await Api.get(`/faturas/${idAtual}/passageiros`);
    renderPax(r.dados);
  } catch (e) { mostrarToast(e.message); }
}

function renderPax(lista) {
  $('corpoPax').innerHTML = lista.length ? lista.map((p) => `
    <tr data-id="${p.id_passageiro}">
      <td>${p.numero_poltrona == null ? '—' : p.numero_poltrona}</td>
      <td>${escaparHtml(p.nome)}</td>
      <td>${escaparHtml(p.identidade || (p.cpf ? formatarCpfCnpj(p.cpf) : '')) || '—'}</td>
      <td>${escaparHtml(p.local_embarque) || '—'}</td>
      <td style="text-align:right;"><button type="button" class="btn btn-icone btn-excluir-pax" title="Excluir" data-perm="excluir">🗑</button></td>
    </tr>`).join('') : '<tr><td colspan="5" style="color:var(--tinta-suave); text-align:center;">Nenhum passageiro lançado ainda.</td></tr>';

  $('corpoPax').querySelectorAll('tr[data-id]').forEach((tr) => {
    tr.addEventListener('click', (ev) => { if (!ev.target.closest('.btn-excluir-pax')) preencherFormPax(lista.find((p) => String(p.id_passageiro) === tr.dataset.id)); });
    tr.querySelector('.btn-excluir-pax').addEventListener('click', async (ev) => {
      ev.stopPropagation();
      if (!confirm('Excluir este passageiro?')) return;
      try { await Api.del(`/faturas/${idAtual}/passageiros/${tr.dataset.id}`); mostrarToast('Passageiro excluído.'); carregarPax(); } catch (e) { mostrarToast(e.message); }
    });
  });
}

// CPF de passageiro é sempre pessoa física (11 dígitos) - mesmo padrão usado
// em Funcionários: trunca antes de formatar pra nunca deslizar pra máscara
// de CNPJ.
const erroPaxCpf = $('erroPaxCpf');

function limparErroPaxCpf() {
  $('paxCpf').classList.remove('campo-invalido');
  erroPaxCpf.style.display = 'none';
}
function mostrarErroPaxCpf(mensagem) {
  $('paxCpf').classList.add('campo-invalido');
  erroPaxCpf.textContent = mensagem;
  erroPaxCpf.style.display = 'block';
}

$('paxCpf').addEventListener('input', (ev) => {
  const posicaoAntes = ev.target.selectionStart;
  const tamanhoAntes = ev.target.value.length;

  const digitos = somenteDigitos(ev.target.value).slice(0, 11);
  ev.target.value = formatarCpfCnpj(digitos);

  const diferenca = ev.target.value.length - tamanhoAntes;
  const novaPosicao = Math.max(0, posicaoAntes + diferenca);
  ev.target.setSelectionRange(novaPosicao, novaPosicao);
  limparErroPaxCpf();
});

// CPF do passageiro é opcional (pode identificar só pelo RG) - só valida o
// dígito verificador quando algo foi digitado, igual ao CNPJ/CPF de Clientes.
$('paxCpf').addEventListener('blur', () => {
  const digitos = somenteDigitos($('paxCpf').value);
  if (digitos.length === 0) { limparErroPaxCpf(); return; }
  if (digitos.length !== 11) { mostrarErroPaxCpf('CPF precisa ter 11 dígitos.'); return; }
  if (!validarCPF($('paxCpf').value)) { mostrarErroPaxCpf('CPF inválido.'); return; }
  limparErroPaxCpf();
});

function preencherFormPax(p) {
  paxEditId = p ? p.id_passageiro : null;
  $('paxPoltrona').value = p && p.numero_poltrona != null ? p.numero_poltrona : '';
  $('paxNome').value = p ? p.nome : '';
  $('paxIdentidade').value = p ? p.identidade || '' : '';
  $('paxCpf').value = p ? formatarCpfCnpj(p.cpf || '') : '';
  $('paxDtNasc').value = p ? p.data_nascimento || '' : '';
  $('paxLocal').value = p ? p.local_embarque || '' : '';
  $('paxSexo').value = p ? p.sexo || '' : '';
  $('paxTipo').value = p ? p.tipo || '' : '';
  $('btnSalvarPax').textContent = p ? 'Salvar alterações' : 'Adicionar passageiro';
  $('btnNovoPax').style.display = p ? '' : 'none';
  limparErroPaxCpf();
}
$('btnNovoPax').addEventListener('click', () => preencherFormPax(null));

$('formPax').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  if (!$('paxNome').value.trim()) return;

  const digitosPaxCpf = somenteDigitos($('paxCpf').value);
  if (digitosPaxCpf.length > 0 && !validarCPF($('paxCpf').value)) {
    mostrarErroPaxCpf(digitosPaxCpf.length === 11 ? 'CPF inválido.' : 'CPF precisa ter 11 dígitos.');
    $('paxCpf').focus();
    return;
  }

  const payload = {
    numero_poltrona: $('paxPoltrona').value === '' ? null : Number($('paxPoltrona').value),
    nome: $('paxNome').value.trim(),
    identidade: $('paxIdentidade').value.trim(),
    cpf: somenteDigitos($('paxCpf').value),
    data_nascimento: $('paxDtNasc').value,
    local_embarque: $('paxLocal').value.trim(),
    sexo: $('paxSexo').value,
    tipo: $('paxTipo').value.trim(),
  };
  try {
    if (paxEditId) await Api.put(`/faturas/${idAtual}/passageiros/${paxEditId}`, payload);
    else await Api.post(`/faturas/${idAtual}/passageiros`, payload);
    mostrarToast('Passageiro salvo.');
    preencherFormPax(null);
    carregarPax();
  } catch (e) { mostrarToast(e.message); }
});

// ---- Despesas da viagem
async function carregarGastos() {
  try {
    const g = await Api.get(`/faturas/${idAtual}/gastos`);
    $('gKmIni').value = g.km_inicial ?? '';
    $('gKmFim').value = g.km_final ?? '';
    $('gLitrosIni').value = g.combustivel_litros_inicial ?? '';
    $('gValorIni').value = g.combustivel_valor_inicial ?? '';
    $('gLitrosFim').value = g.combustivel_litros_final ?? '';
    $('gValorFim').value = g.combustivel_valor_final ?? '';
    $('gPedagio').value = g.pedagio ?? '';
    $('gHotel').value = g.hotel ?? '';
    $('gRefeicao').value = g.refeicao ?? '';
    $('gOutras').value = g.outras_despesas ?? '';
    $('gAdianta').value = g.adiantamento ?? '';
    $('gastosSaldo').textContent = fmtMoeda(g.saldo);
  } catch (e) { mostrarToast(e.message); }
}

$('formGastos').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const payload = {
    km_inicial: $('gKmIni').value, km_final: $('gKmFim').value,
    combustivel_litros_inicial: $('gLitrosIni').value, combustivel_valor_inicial: $('gValorIni').value,
    combustivel_litros_final: $('gLitrosFim').value, combustivel_valor_final: $('gValorFim').value,
    pedagio: $('gPedagio').value, hotel: $('gHotel').value, refeicao: $('gRefeicao').value,
    outras_despesas: $('gOutras').value, adiantamento: $('gAdianta').value,
  };
  try {
    const g = await Api.put(`/faturas/${idAtual}/gastos`, payload);
    $('gastosSaldo').textContent = fmtMoeda(g.saldo);
    mostrarToast('Despesas salvas.');
  } catch (e) { mostrarToast(e.message); }
});

// ---------------------------------------------------------------- painel lateral
function abrirPainel(titulo) {
  $('tituloPainel').textContent = titulo;
  $('painelFundo').classList.add('aberto');
  $('painelLateral').classList.add('aberto');
}
function fecharPainel() {
  $('painelFundo').classList.remove('aberto');
  $('painelLateral').classList.remove('aberto');
}
$('btnFecharPainel').addEventListener('click', fecharPainel);
$('btnCancelarPainel').addEventListener('click', fecharPainel);
$('painelFundo').addEventListener('click', fecharPainel);

$('btnNova').addEventListener('click', () => {
  idAtual = null;
  preencher({ status: 'C', tipo: 'D', internacional: 0, forma_pagamento: 0, retencao_previdenciaria: 0, imposto: '', data_saida: diaSel });
  campoClienteTexto.value = '';
  $('btnExcluir').style.display = 'none';
  $('alertaConflitos').className = 'alerta-conflito';
  calcularLiquido();
  ativarAbaFatura('viagem');
  document.getElementById('painelLateral').dataset.novo = '1';
  abrirPainel('Nova viagem');
});

async function abrirEdicao(id) {
  try {
    const f = await Api.get('/faturas/' + id);
    idAtual = id;
    garantirOpcao($('selVeiculo'), f.id_veiculo, `${f.veiculo_numero || ''} · ${f.veiculo_placa || ''}`);
    garantirOpcao($('selMot1'), f.id_funcionario1, f.motorista1_nome || 'Motorista');
    garantirOpcao($('selMot2'), f.id_funcionario2, f.motorista2_nome || 'Motorista');
    preencher(f);
    campoClienteTexto.value = f.cliente_nome || '';
    $('btnExcluir').style.display = '';
    calcularLiquido();
    ativarAbaFatura('viagem');
    document.getElementById('painelLateral').dataset.novo = '0';
    abrirPainel(`Fatura ${f.id_fatura}${f.duplicata ? ' · Duplicata ' + f.duplicata : ''}`);
    agendarConflitos();
  } catch (e) {
    mostrarToast(e.message);
  }
}

$('btnSalvar').addEventListener('click', async () => {
  if (!$('campoClienteId').value) {
    mostrarToast('Selecione o cliente na lista de sugestões.');
    campoClienteTexto.focus();
    return;
  }
  if (!$('formFatura').reportValidity()) return;

  const payload = coletar();
  const botao = $('btnSalvar');
  botao.disabled = true;
  botao.textContent = 'Salvando...';

  try {
    if (idAtual) {
      await Api.put('/faturas/' + idAtual, payload);
      mostrarToast('Viagem atualizada.');
      fecharPainel();
    } else {
      const r = await Api.post('/faturas', payload);
      idAtual = r.id_fatura;
      document.getElementById('painelLateral').dataset.novo = '0';
      $('tituloPainel').textContent = `Fatura ${idAtual}`;
      $('btnExcluir').style.display = '';
      mostrarToast('Viagem agendada. Você já pode lançar passageiros e despesas.');
      // fica aberto: o usuário pode seguir direto pras abas de Passageiros/Despesas/Imprimir
    }

    // leva o calendário até o dia da saída, para o usuário ver a viagem salva
    const d = doISO(payload.data_saida);
    mes = new Date(d.getFullYear(), d.getMonth(), 1);
    diaSel = payload.data_saida;
    await carregarMes();
  } catch (e) {
    mostrarToast(e.message);
  } finally {
    botao.disabled = false;
    botao.textContent = 'Salvar viagem';
  }
});

$('btnExcluir').addEventListener('click', async () => {
  if (!idAtual || !confirm('Excluir esta viagem definitivamente?')) return;
  try {
    await Api.del('/faturas/' + idAtual);
    mostrarToast('Viagem excluída.');
    fecharPainel();
    await carregarMes();
  } catch (e) {
    mostrarToast(e.message);
  }
});

// ---------------------------------------------------------------- localizar viagem
// Busca em TODAS as datas (o servidor procura em cliente, origem, destino, placa, nº da fatura e duplicata)
// e leva direto para a viagem escolhida: abre o mes dela no calendario e a ficha da viagem.
const campoBuscaViagem = $('campoBuscaViagem');
const caixaBusca = $('resultadosBusca');
let tBusca = null;
let seqBusca = 0;
let resultadosBusca = [];
let idxBusca = -1;
const LIMITE_RESULTADOS_BUSCA = 40;

function fecharBusca() {
  caixaBusca.hidden = true;
  campoBuscaViagem.setAttribute('aria-expanded', 'false');
  idxBusca = -1;
}

function fmtDataCompleta(s) {
  if (!s) return '';
  const [a, m, d] = s.split('-');
  return `${d}/${m}/${a}`;
}

// proximas viagens primeiro (da mais proxima para a mais distante), depois as anteriores (da mais recente para a mais antiga)
function ordenarResultados(lista) {
  const hoje = hojeISO();
  const proximas = lista.filter((v) => (v.data_saida || '') >= hoje).sort((a, b) => (a.data_saida + (a.hora_saida || '')).localeCompare(b.data_saida + (b.hora_saida || '')));
  const anteriores = lista.filter((v) => (v.data_saida || '') < hoje).sort((a, b) => (b.data_saida + (b.hora_saida || '')).localeCompare(a.data_saida + (a.hora_saida || '')));
  return { proximas, anteriores };
}

function itemBusca(v, idx) {
  const rota = [[v.origem, v.uf_origem].filter(Boolean).join('/'), [v.destino, v.uf_destino].filter(Boolean).join('/')];
  const roteiro = (rota[0] || rota[1]) ? `${rota[0] || '—'} → ${rota[1] || '—'}` : 'Roteiro não informado';
  const veic = v.veiculo_numero ? `Nº ${v.veiculo_numero} · ${v.veiculo_placa}` : 'Sem veículo';
  const pend = v.status === 'P';
  return `<button type="button" class="busca-item" role="option" data-idx="${idx}" data-id="${v.id_fatura}">
    <div class="l1"><span class="data">${escaparHtml(fmtDataCompleta(v.data_saida))}${v.hora_saida ? ' ' + escaparHtml(v.hora_saida) : ''}</span>
      <span class="cli">${escaparHtml(v.cliente_nome || 'Cliente não informado')}</span>
      <span class="badge ${pend ? 'badge-alerta' : 'badge-ativo'}">${pend ? 'Pendente' : 'Confirmada'}</span></div>
    <div class="l2">${escaparHtml(roteiro)} · ${escaparHtml(veic)}</div>
  </button>`;
}

function renderResultadosBusca() {
  const { proximas, anteriores } = ordenarResultados(resultadosBusca);
  const total = proximas.length + anteriores.length;
  caixaBusca.hidden = false;
  campoBuscaViagem.setAttribute('aria-expanded', 'true');

  if (!total) {
    caixaBusca.innerHTML = '<div class="busca-vazio">Nenhuma viagem encontrada.<br>Tente o nome do cliente, o destino, a placa ou o nº da fatura.</div>';
    resultadosBusca = [];
    return;
  }

  // a ordem exibida (proximas, depois anteriores) e a ordem do teclado
  resultadosBusca = proximas.concat(anteriores).slice(0, LIMITE_RESULTADOS_BUSCA);
  const nProx = Math.min(proximas.length, LIMITE_RESULTADOS_BUSCA);
  let html = '';
  if (nProx) html += '<div class="busca-grupo">Próximas</div>' + resultadosBusca.slice(0, nProx).map((v, i) => itemBusca(v, i)).join('');
  if (resultadosBusca.length > nProx) html += '<div class="busca-grupo">Anteriores</div>' + resultadosBusca.slice(nProx).map((v, i) => itemBusca(v, nProx + i)).join('');
  if (total > LIMITE_RESULTADOS_BUSCA) html += `<div class="busca-nota">Mostrando ${LIMITE_RESULTADOS_BUSCA} de ${total} viagens. Digite mais detalhes para refinar.</div>`;
  caixaBusca.innerHTML = html;
  idxBusca = -1;
}

async function buscarViagens(texto) {
  const seq = ++seqBusca;
  caixaBusca.hidden = false;
  caixaBusca.innerHTML = '<div class="busca-vazio">Buscando…</div>';
  try {
    const r = await Api.get('/faturas?busca=' + encodeURIComponent(texto));
    if (seq !== seqBusca) return; // chegou uma resposta de uma digitacao antiga
    resultadosBusca = r.dados || [];
    renderResultadosBusca();
  } catch (e) {
    if (seq !== seqBusca) return;
    caixaBusca.innerHTML = `<div class="busca-vazio">${escaparHtml(e.message)}</div>`;
  }
}

async function irParaViagem(id) {
  const v = resultadosBusca.find((x) => x.id_fatura === id);
  fecharBusca();
  campoBuscaViagem.value = '';
  seqBusca++;
  if (v && v.data_saida) {
    const d = doISO(v.data_saida);
    mes = new Date(d.getFullYear(), d.getMonth(), 1);
    diaSel = v.data_saida;
    await carregarMes();
  }
  abrirEdicao(id);
}

function marcarItemBusca(novo) {
  const itens = caixaBusca.querySelectorAll('.busca-item');
  if (!itens.length) return;
  idxBusca = (novo + itens.length) % itens.length;
  itens.forEach((el, i) => el.classList.toggle('ativo', i === idxBusca));
  itens[idxBusca].scrollIntoView({ block: 'nearest' });
}

campoBuscaViagem.addEventListener('input', () => {
  clearTimeout(tBusca);
  const t = campoBuscaViagem.value.trim();
  if (t.length < 2) { seqBusca++; fecharBusca(); return; }
  tBusca = setTimeout(() => buscarViagens(t), 300);
});

campoBuscaViagem.addEventListener('keydown', (ev) => {
  if (ev.key === 'Escape') { fecharBusca(); return; }
  if (caixaBusca.hidden) return;
  if (ev.key === 'ArrowDown') { ev.preventDefault(); marcarItemBusca(idxBusca + 1); }
  else if (ev.key === 'ArrowUp') { ev.preventDefault(); marcarItemBusca(idxBusca - 1); }
  else if (ev.key === 'Enter') {
    const alvo = resultadosBusca[idxBusca >= 0 ? idxBusca : 0];
    if (alvo) { ev.preventDefault(); irParaViagem(alvo.id_fatura); }
  }
});

campoBuscaViagem.addEventListener('focus', () => {
  if (resultadosBusca.length && campoBuscaViagem.value.trim().length >= 2) renderResultadosBusca();
});

caixaBusca.addEventListener('click', (ev) => {
  const b = ev.target.closest('.busca-item');
  if (b) irParaViagem(Number(b.dataset.id));
});

document.addEventListener('click', (ev) => {
  if (!$('buscaViagem').contains(ev.target)) fecharBusca();
});

// ---------------------------------------------------------------- início
carregarListas();
carregarMes();
