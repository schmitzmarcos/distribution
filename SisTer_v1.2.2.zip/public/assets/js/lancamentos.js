// =========================================================================
// SisTer - Lançamentos de campo (celular)
// Fluxo de 3 toques: 1) o que lançar  2) qual veículo  3) confirmar.
// Sem sinal? O lançamento fica guardado no aparelho (com um código único, para não duplicar)
// e é enviado sozinho quando a conexão voltar.
// =========================================================================
(function () {
  'use strict';
  exigirLogin();

  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const p2 = (n) => String(n).padStart(2, '0');

  const ACOES = {
    limpeza: { titulo: 'Limpeza concluída', pergunta: 'Qual veículo foi limpo?' },
    abastecimento: { titulo: 'Abastecimento', pergunta: 'Qual veículo abasteceu?' },
    manutencao: { titulo: 'Manutenção', pergunta: 'Qual veículo?' },
  };
  const CATEGORIAS = {
    mecanica: 'Mecânica', eletrica: 'Elétrica', pneus: 'Pneus', freios: 'Freios',
    ar_condicionado: 'Ar-condicionado', lataria: 'Lataria e pintura', revisao: 'Revisão', outro: 'Outro',
  };
  const LIMPEZAS = { completa: ['Completa', 'por dentro e por fora'], interna: ['Interna', 'só por dentro'], externa: ['Externa', 'só por fora'] };
  const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const DIAS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];

  let ctx = null;            // resposta de /lancamentos/contexto
  let acao = null;           // 'limpeza' | 'abastecimento' | 'manutencao'
  let filtro = 'todos';
  let atual = null;          // { v, modo } veículo no formulário
  let escolha = {};          // valores dos botões de escolha do formulário
  let nivel = 0;             // 0 início · 1 lista de veículos · 2 formulário
  let aoConfirmar = null;

  // ------------------------------------------------------------------ utilitários
  function parseTS(s) {
    const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/.exec(s || '');
    return m ? new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]) : null;
  }
  function agoraTS() {
    const d = new Date();
    return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()) + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes()) + ':' + p2(d.getSeconds());
  }
  const hoje = () => agoraTS().slice(0, 10);
  const hhmm = (s) => (s || '').slice(11, 16);
  const dm = (iso) => (iso && iso.length >= 10 ? iso.slice(8, 10) + '/' + iso.slice(5, 7) : '');
  function relativo(s) {
    const d = parseTS(s);
    if (!d) return '';
    const min = Math.round((Date.now() - d.getTime()) / 60000);
    if (min < 1) return 'agora';
    if (min < 60) return 'há ' + min + ' min';
    const base = new Date(); base.setHours(0, 0, 0, 0);
    const dias = Math.round((base - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 86400000);
    if (dias <= 0) return 'hoje ' + hhmm(s);
    if (dias === 1) return 'ontem ' + hhmm(s);
    return 'há ' + dias + ' dias';
  }
  const fmtNum = (n, dec) => Number(n).toLocaleString('pt-BR', { maximumFractionDigits: dec == null ? 1 : dec });
  function parseNum(s) {
    s = String(s == null ? '' : s).trim().replace(/\s/g, '');
    if (!s) return null;
    if (s.indexOf(',') >= 0) s = s.replace(/\./g, '').replace(',', '.');
    const n = Number(s);
    return isFinite(n) ? n : NaN;
  }
  const norm = (s) => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  function novaChave() {
    if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
    return 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }
  function vibrar(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* aparelho sem vibração */ } }

  let tToast = 0;
  function toast(msg, erro) {
    const t = $('toast');
    t.textContent = msg;
    t.className = 'toast' + (erro ? ' erro' : '');
    t.hidden = false;
    clearTimeout(tToast);
    tToast = setTimeout(() => { t.hidden = true; }, erro ? 6000 : 3200);
  }
  const ehRede = (e) => !e.status && e.message !== 'Sessao expirada';

  // ------------------------------------------------------------------ fila offline
  const CHAVE_FILA = 'sister_fila_lanc';
  const meuId = () => (Api.usuario() || {}).id_usuario;
  function lerFila() { try { return JSON.parse(localStorage.getItem(CHAVE_FILA) || '[]'); } catch (e) { return []; } }
  function gravarFila(l) { try { localStorage.setItem(CHAVE_FILA, JSON.stringify(l)); } catch (e) { /* sem espaço: segue sem guardar */ } }
  const minhaFila = () => lerFila().filter((i) => i.uid === meuId());

  function enfileirar(payload, v) {
    const f = lerFila();
    f.push({ uid: meuId(), numero: v.numero, placa: v.placa, payload });
    gravarFila(f);
    atualizarFaixa();
  }

  let descarregando = false;
  async function descarregarFila() {
    if (descarregando || !minhaFila().length) return;
    descarregando = true;
    atualizarFaixa();
    let enviou = false;
    try {
      for (const item of minhaFila()) {
        try {
          await Api.post('/lancamentos', item.payload);
          enviou = true;
        } catch (e) {
          if (ehRede(e)) break;                       // sem sinal: tenta de novo mais tarde
          toast('Lançamento do veículo ' + item.numero + ' recusado: ' + e.message, true);
        }
        gravarFila(lerFila().filter((x) => x.payload.chave !== item.payload.chave));
      }
    } finally {
      descarregando = false;
      atualizarFaixa();
    }
    if (enviou) carregar(true);
  }

  function atualizarFaixa() {
    const f = $('faixaFila');
    const n = minhaFila().length;
    const offline = navigator.onLine === false;
    if (!n && !offline) { f.hidden = true; return; }
    f.hidden = false;
    f.className = 'faixa' + (descarregando ? ' ok' : '');
    let msg;
    if (descarregando) msg = 'Enviando ' + n + (n === 1 ? ' lançamento…' : ' lançamentos…');
    else if (offline && n) msg = 'Sem conexão. ' + n + (n === 1 ? ' lançamento será enviado' : ' lançamentos serão enviados') + ' quando voltar o sinal.';
    else if (offline) msg = 'Sem conexão. Você ainda pode lançar: enviamos quando o sinal voltar.';
    else msg = n + (n === 1 ? ' lançamento aguardando envio.' : ' lançamentos aguardando envio.');
    f.innerHTML = '<svg class="icone"><use href="#i-aviso"/></svg><span>' + esc(msg) + '</span>';
  }

  // ------------------------------------------------------------------ carregar dados
  async function carregar(silencioso) {
    const b = $('btnAtualizar');
    if (!silencioso) b.classList.add('girando');
    try {
      ctx = await Api.get('/lancamentos/contexto');
      renderInicio();
      if (nivel === 1) renderVeiculos();
    } catch (e) {
      if (e.status === 403) {
        $('acoes').innerHTML = '<div class="aviso perigo">Seu perfil não tem permissão para fazer lançamentos. Fale com o responsável pelo sistema.</div>';
      } else if (!ctx) {
        $('acoes').innerHTML = '<div class="aviso alerta">Não foi possível carregar os veículos. Confira a conexão e toque em atualizar.</div>';
      } else if (!silencioso) {
        toast('Sem conexão. Mostrando os últimos dados carregados.', true);
      }
    } finally {
      b.classList.remove('girando');
    }
  }

  // ------------------------------------------------------------------ situação de cada veículo
  const pendente = (v) => (v.pendencias || []).indexOf('limpeza') >= 0;

  function situacao(v, a) {
    const m = v.manut;
    if (m && (a === 'manutencao' || a === 'abastecimento' || a === 'limpeza')) {
      return { txt: 'Parado desde ' + dm(m.desde) + (m.subtipo ? ' · ' + (CATEGORIAS[m.subtipo] || m.subtipo) : ''), cls: 'sit-manutencao' };
    }
    if (a === 'limpeza') {
      if (v.estado === 'viagem') return { txt: 'Em viagem agora', cls: 'sit-viagem' };
      if (pendente(v)) return { txt: 'Aguardando limpeza', cls: 'sit-pendente' };
      if (v.limpeza_em) return { txt: 'Limpo · ' + relativo(v.limpeza_em), cls: 'sit-ok' };
      return { txt: 'Sem limpeza registrada', cls: 'sit-neutra' };
    }
    if (a === 'abastecimento') {
      if (v.abast_em) return { txt: 'Abastecido ' + relativo(v.abast_em) + (v.abast_km ? ' · ' + fmtNum(v.abast_km, 0) + ' km' : ''), cls: 'sit-neutra' };
      return { txt: 'Sem abastecimento registrado', cls: 'sit-neutra' };
    }
    if (v.estado === 'viagem') return { txt: 'Em viagem agora', cls: 'sit-viagem' };
    return { txt: pendente(v) ? 'Disponível · limpeza pendente' : 'Disponível', cls: 'sit-neutra' };
  }

  const letreiro = (v, mini) => '<span class="letreiro ' + esc(v.estado) + (mini ? ' mini' : '') + '"><b>' + esc(v.numero) + '</b></span>';

  // ------------------------------------------------------------------ tela inicial
  function renderInicio() {
    const u = ctx.usuario || {};
    const d = new Date();
    const h = d.getHours();
    const saud = h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
    const primeiro = String(u.nome || '').trim().split(/\s+/)[0];
    $('saudacao').textContent = saud + (primeiro ? ', ' + primeiro : '');
    $('saudacaoSub').textContent = DIAS[d.getDay()].charAt(0).toUpperCase() + DIAS[d.getDay()].slice(1) + ', ' + d.getDate() + ' de ' + MESES[d.getMonth()] + (u.perfil ? ' · ' + u.perfil : '');

    const veic = ctx.veiculos || [];
    const nPend = veic.filter((v) => pendente(v) && !v.manut).length;
    const nParados = veic.filter((v) => v.manut).length;
    const subs = {
      limpeza: nPend ? { t: nPend + (nPend === 1 ? ' veículo aguardando limpeza' : ' veículos aguardando limpeza'), alerta: true } : { t: 'Nenhum veículo aguardando' },
      abastecimento: { t: 'KM, combustível e arla' },
      manutencao: nParados ? { t: nParados + (nParados === 1 ? ' veículo parado' : ' veículos parados'), alerta: true } : { t: 'Parar ou liberar um veículo' },
    };
    const tipos = (ctx.tipos || []).filter((t) => ACOES[t]);
    $('acoes').innerHTML = tipos.length
      ? tipos.map((t) => '<button type="button" class="acao ' + t + '" data-acao="' + t + '">' +
          '<span class="acao-icone"><svg class="icone"><use href="#i-' + t + '"/></svg></span>' +
          '<span class="acao-texto"><span class="acao-titulo">' + esc(ACOES[t].titulo) + '</span>' +
          '<span class="acao-sub' + (subs[t].alerta ? ' alerta' : '') + '">' + esc(subs[t].t) + '</span></span>' +
          '<svg class="icone acao-seta"><use href="#i-seta"/></svg></button>').join('')
      : '<div class="aviso perigo">Seu perfil não tem nenhum tipo de lançamento liberado.</div>';
    renderMeus();
  }

  const NOMES_TIPO = { limpeza: 'Limpeza', abastecimento: 'Abastecimento', manutencao_entrada: 'Parou para manutenção', manutencao_saida: 'Veículo liberado' };
  function detalhe(i) {
    if (i.tipo === 'limpeza') return (LIMPEZAS[i.subtipo] || LIMPEZAS.completa)[0];
    if (i.tipo === 'abastecimento') return [i.litros ? fmtNum(i.litros) + ' L' : '', i.litros_arla ? fmtNum(i.litros_arla) + ' L de arla' : '', i.km ? fmtNum(i.km, 0) + ' km' : ''].filter(Boolean).join(' · ');
    if (i.tipo === 'manutencao_entrada') return CATEGORIAS[i.subtipo] || '';
    return i.descricao || '';
  }

  function renderMeus() {
    const veic = {};
    (ctx.veiculos || []).forEach((v) => { veic[v.id_veiculo] = v; });
    const itens = [];
    minhaFila().forEach((f) => itens.push({
      fila: true, chave: f.payload.chave, quando: f.payload.ocorrido_em, tipo: f.payload.tipo, numero: f.numero,
      subtipo: f.payload.subtipo, litros: f.payload.litros, litros_arla: f.payload.litros_arla, km: f.payload.km, descricao: f.payload.descricao,
    }));
    (ctx.meus || []).forEach((m) => itens.push({
      id: m.id_ocorrencia, quando: m.data_hora, tipo: m.tipo, numero: m.numero, subtipo: m.subtipo, litros: m.litros,
      litros_arla: m.litros_arla, km: m.km, descricao: m.descricao, cancelado: m.cancelado, pode: m.pode_desfazer,
    }));
    itens.sort((a, b) => (a.quando < b.quando ? 1 : -1));
    if (!itens.length) { $('meus').innerHTML = '<div class="vazio">Nada lançado hoje ainda.</div>'; return; }
    $('meus').innerHTML = itens.map((i) => {
      const det = detalhe(i);
      return '<div class="meu' + (i.cancelado ? ' cancelado' : '') + (i.fila ? ' pendente-envio' : '') + '">' +
        '<div class="meu-hora">' + esc(hhmm(i.quando)) + '</div>' +
        '<div class="meu-texto">' + esc(NOMES_TIPO[i.tipo] || i.tipo) + ' · veículo ' + esc(i.numero) +
        '<small>' + esc(i.fila ? 'Aguardando envio' + (det ? ' · ' + det : '') : (i.cancelado ? 'Desfeito' : det)) + '</small></div>' +
        (i.fila ? '<button type="button" class="btn-desfazer" data-descartar="' + esc(i.chave) + '">Descartar</button>'
          : (i.pode && !i.cancelado ? '<button type="button" class="btn-desfazer" data-desfazer="' + i.id + '">Desfazer</button>' : '')) +
        '</div>';
    }).join('');
  }

  // ------------------------------------------------------------------ lista de veículos
  function abrirVeiculos(a) {
    acao = a;
    const veic = ctx.veiculos || [];
    const nPend = veic.filter((v) => pendente(v) && !v.manut).length;
    filtro = (a === 'limpeza' && nPend > 0) ? 'pendente' : 'todos';
    $('busca').value = '';
    $('tituloVeiculos').textContent = ACOES[a].pergunta;
    mostrarNivel(1, true);
    renderVeiculos();
    window.scrollTo(0, 0);
  }

  function renderVeiculos() {
    const veic = ctx.veiculos || [];
    const nPend = veic.filter((v) => pendente(v) && !v.manut).length;
    const nPar = veic.filter((v) => v.manut).length;
    const pil = [];
    if (acao === 'limpeza') { pil.push(['pendente', 'Aguardando', nPend]); pil.push(['todos', 'Todos', veic.length]); }
    if (acao === 'manutencao') { pil.push(['todos', 'Todos', veic.length]); pil.push(['parados', 'Parados', nPar]); }
    if (!pil.some((p) => p[0] === filtro)) filtro = 'todos';
    $('pilulas').hidden = !pil.length;
    $('pilulas').innerHTML = pil.map((p) => '<button type="button" class="pilula' + (p[0] === filtro ? ' ativa' : '') + '" data-filtro="' + p[0] + '" aria-pressed="' + (p[0] === filtro) + '">' + p[1] + '<b>' + p[2] + '</b></button>').join('');

    const q = norm($('busca').value);
    let lista = veic.filter((v) => {
      if (filtro === 'pendente' && !(pendente(v) && !v.manut)) return false;
      if (filtro === 'parados' && !v.manut) return false;
      if (!q) return true;
      return String(v.numero) === q || norm(v.placa).indexOf(q) >= 0 || norm(v.modelo).indexOf(q) >= 0 || norm(v.marca).indexOf(q) >= 0;
    });
    const peso = (v) => {
      if (acao === 'limpeza') return v.manut ? 2 : v.estado === 'viagem' ? 3 : pendente(v) ? 0 : 1;
      if (acao === 'manutencao') return v.manut ? 0 : 1;
      return v.manut ? 3 : v.estado === 'viagem' ? 2 : 1;
    };
    lista = lista.sort((a, b) => peso(a) - peso(b) || a.numero - b.numero);

    if (!lista.length) {
      $('listaVeiculos').innerHTML = '<div class="vazio">' + (q ? 'Nenhum veículo encontrado. Confira o número ou a placa.' : 'Nenhum veículo nesta lista.') + '</div>';
      return;
    }
    $('listaVeiculos').innerHTML = lista.map((v) => {
      const s = situacao(v, acao);
      const extra = acao === 'manutencao' && v.manut ? '<small class="veiculo-modelo"> · toque para liberar</small>' : '';
      return '<button type="button" class="veiculo" data-veiculo="' + v.id_veiculo + '">' + letreiro(v) +
        '<span class="veiculo-info"><span class="veiculo-linha1"><span class="placa-mini">' + esc(v.placa) + '</span>' +
        '<span class="veiculo-modelo">' + esc([v.marca, v.modelo].filter(Boolean).join(' ')) + (v.lotacao ? ' · ' + v.lotacao + ' lug.' : '') + '</span></span>' +
        '<span class="veiculo-situacao ' + s.cls + '">' + esc(s.txt) + extra + '</span></span>' +
        '<svg class="icone acao-seta"><use href="#i-seta"/></svg></button>';
    }).join('');
  }

  // ------------------------------------------------------------------ navegação (botão Voltar do aparelho funciona)
  function mostrarNivel(n, empurrar) {
    nivel = n;
    $('telaInicio').hidden = n !== 0;
    $('telaVeiculos').hidden = n !== 1 && n !== 2;
    if (n < 2) fecharFolhaVisual();
    if (n < 2) $('sucesso').hidden = true;
    if (empurrar) history.pushState({ n }, '');
  }
  window.addEventListener('popstate', (e) => {
    let n = (e.state && e.state.n) || 0;
    if (n === 2 && !atual) n = 1;
    if (n === 0) { acao = null; mostrarNivel(0); renderInicio(); }
    else mostrarNivel(n);
  });
  history.replaceState({ n: 0 }, '');

  // ------------------------------------------------------------------ folha (formulário / confirmação)
  function abrirFolha(o) {
    $('folhaLetreiro').innerHTML = o.letreiro || '';
    $('folhaTitulo').textContent = o.titulo;
    $('folhaSub').textContent = o.sub || '';
    $('folhaCorpo').innerHTML = o.corpo;
    const b = $('folhaEnviar');
    b.textContent = o.botao;
    b.className = 'btn-grande' + (o.classe ? ' ' + o.classe : '');
    b.disabled = false;
    $('folhaErro').hidden = true;
    aoConfirmar = o.aoConfirmar;
    $('fundo').hidden = false;
    $('folha').hidden = false;
    document.body.style.overflow = 'hidden';
    if (o.foco) setTimeout(() => { const el = $(o.foco); if (el) el.focus(); }, 280);
  }
  function fecharFolhaVisual() {
    $('fundo').hidden = true;
    $('folha').hidden = true;
    document.body.style.overflow = '';
    aoConfirmar = null;
  }
  function fecharFolha() { if (nivel === 2) history.back(); else fecharFolhaVisual(); }

  function erroGeral(msg) {
    const e = $('folhaErro');
    e.textContent = msg;
    e.hidden = false;
  }
  function erroCampo(id, msg) {
    const c = $('c_' + id);
    if (!c) return;
    c.classList.add('erro');
    c.querySelector('.msg-erro').textContent = msg;
  }
  function limparErros() {
    document.querySelectorAll('#folhaCorpo .campo.erro').forEach((c) => c.classList.remove('erro'));
    $('folhaErro').hidden = true;
  }

  const campo = (id, rotulo, inner, dica) => '<div class="campo" id="c_' + id + '"><label for="' + id + '">' + rotulo + (dica ? ' <span class="dica">' + dica + '</span>' : '') + '</label>' + inner + '<div class="msg-erro"></div></div>';
  const segmentos = (grupo, itens, sel, col2) => '<div class="segmentos' + (col2 ? ' col2' : '') + '" role="group">' + itens.map((i) =>
    '<button type="button" class="segmento" data-seg="' + grupo + '" data-valor="' + i[0] + '" aria-pressed="' + (i[0] === sel) + '">' + esc(i[1]) + (i[2] ? '<small>' + esc(i[2]) + '</small>' : '') + '</button>').join('') + '</div>';

  function abrirFormulario(v) {
    const modo = acao === 'manutencao' ? (v.manut ? 'saida' : 'entrada') : acao;
    atual = { v, modo };
    escolha = {};
    let corpo = '', titulo = '', botao = '', classe = '', foco = '';
    const avisos = [];
    if (acao !== 'manutencao' && v.manut) avisos.push('<div class="aviso alerta"><svg class="icone"><use href="#i-aviso"/></svg><span>Este veículo está parado para manutenção desde ' + esc(dm(v.manut.desde)) + '.</span></div>');
    if (v.estado === 'viagem' && acao !== 'manutencao') avisos.push('<div class="aviso info"><svg class="icone"><use href="#i-aviso"/></svg><span>Este veículo está em viagem agora' + (v.viagem && v.viagem.hora_volta ? ' (volta às ' + esc(v.viagem.hora_volta) + ')' : '') + '.</span></div>');

    if (modo === 'limpeza') {
      titulo = 'Limpeza concluída'; botao = 'Confirmar limpeza';
      escolha.subtipo = 'completa';
      corpo = '<div class="campo"><span class="rotulo">Tipo de limpeza</span>' + segmentos('subtipo', Object.keys(LIMPEZAS).map((k) => [k, LIMPEZAS[k][0], LIMPEZAS[k][1]]), 'completa') + '</div>' +
        campo('f_desc', 'Observação', '<textarea id="f_desc" rows="2" maxlength="300" placeholder="Algo que a equipe precisa saber (opcional)"></textarea>');
    } else if (modo === 'abastecimento') {
      titulo = 'Abastecimento'; botao = 'Registrar abastecimento'; foco = 'f_km';
      const ult = v.km_atual ? 'Último KM registrado: ' + fmtNum(v.km_atual, 0) : '';
      corpo = campo('f_km', 'KM do painel', '<div class="sufixo"><input id="f_km" type="text" inputmode="decimal" autocomplete="off" placeholder="0"><span>km</span></div>', ult ? '· ' + ult : '') +
        '<div class="par">' + campo('f_litros', 'Combustível', '<div class="sufixo"><input id="f_litros" type="text" inputmode="decimal" autocomplete="off" placeholder="0"><span>L</span></div>') +
        campo('f_arla', 'Arla', '<div class="sufixo"><input id="f_arla" type="text" inputmode="decimal" autocomplete="off" placeholder="0"><span>L</span></div>', '(opcional)') + '</div>' +
        '<div class="leitura" id="leitura" hidden></div>';
    } else if (modo === 'entrada') {
      titulo = 'Parar para manutenção'; botao = 'Parar veículo'; classe = 'sinal';
      corpo = '<div class="campo" id="c_categoria"><span class="rotulo">Qual o problema?</span>' + segmentos('subtipo', Object.keys(CATEGORIAS).map((k) => [k, CATEGORIAS[k]]), '', true) + '<div class="msg-erro"></div></div>' +
        campo('f_desc', 'O que está acontecendo?', '<textarea id="f_desc" rows="3" maxlength="300" placeholder="Descreva o defeito (opcional)"></textarea>') +
        campo('f_prev', 'Previsão de retorno', '<input id="f_prev" type="date" min="' + hoje() + '">', '(opcional)') +
        campo('f_km', 'KM do painel', '<div class="sufixo"><input id="f_km" type="text" inputmode="decimal" autocomplete="off" placeholder="0"><span>km</span></div>', '(opcional)');
    } else {
      titulo = 'Liberar veículo'; botao = 'Liberar veículo';
      const m = v.manut || {};
      avisos.push('<div class="aviso alerta"><svg class="icone"><use href="#i-aviso"/></svg><span>Parado desde ' + esc(dm(m.desde)) + (m.subtipo ? ' · ' + esc(CATEGORIAS[m.subtipo] || m.subtipo) : '') + (m.descricao ? '. ' + esc(m.descricao) : '') + '</span></div>');
      corpo = campo('f_desc', 'O que foi feito?', '<textarea id="f_desc" rows="3" maxlength="300" placeholder="Serviço realizado (opcional)"></textarea>') +
        '<div class="par">' + campo('f_valor', 'Custo', '<div class="sufixo prefixo"><input id="f_valor" type="text" inputmode="decimal" autocomplete="off" placeholder="0,00"><span>R$</span></div>', '(opcional)') +
        campo('f_km', 'KM do painel', '<div class="sufixo"><input id="f_km" type="text" inputmode="decimal" autocomplete="off" placeholder="0"><span>km</span></div>', '(opcional)') + '</div>';
    }
    abrirFolha({
      letreiro: letreiro(v, true), titulo, sub: v.placa + ' · ' + [v.marca, v.modelo].filter(Boolean).join(' '),
      corpo: avisos.join('') + corpo, botao, classe, foco, aoConfirmar: enviar,
    });
    mostrarNivel(2, true);
    // mostrarNivel(2) nao fecha a folha (so niveis menores): ela ja esta aberta
    ['f_km', 'f_litros'].forEach((id) => { const el = $(id); if (el) el.addEventListener('input', leitura); });
  }

  // média desde o último abastecimento: ajuda a pegar KM ou litros digitados errado
  function leitura() {
    const el = $('leitura');
    if (!el || !atual) return;
    const km = parseNum($('f_km').value), l = parseNum($('f_litros').value), ant = atual.v.abast_km;
    if (!(km > 0) || !(l > 0) || !ant || km <= ant) { el.hidden = true; return; }
    const rodou = km - ant, media = rodou / l;
    const estranha = media < 1.5 || media > 8;
    el.hidden = false;
    el.className = 'leitura' + (estranha ? ' alerta' : '');
    el.innerHTML = 'Desde o último abastecimento: <b>' + fmtNum(rodou, 0) + ' km</b> · média de <b>' + fmtNum(media, 1) + ' km/l</b>' + (estranha ? '<br>Confira o KM e os litros antes de registrar.' : '');
  }

  // ------------------------------------------------------------------ validar e enviar
  function montar() {
    limparErros();
    const v = atual.v, modo = atual.modo;
    const val = (id) => ($(id) ? $(id).value.trim() : '');
    const p = { id_veiculo: v.id_veiculo };
    let ok = true;
    const km = parseNum(val('f_km'));
    const checarKm = (obrigatorio) => {
      if (km == null) { if (obrigatorio) { erroCampo('f_km', 'Informe o KM do painel.'); ok = false; } return; }
      if (isNaN(km) || km <= 0) { erroCampo('f_km', 'KM inválido.'); ok = false; return; }
      if (v.km_atual && km < v.km_atual) { erroCampo('f_km', 'O KM não pode ser menor que o último registrado (' + fmtNum(v.km_atual, 0) + ').'); ok = false; return; }
      if (v.km_atual && km - v.km_atual > 15000) { erroCampo('f_km', 'KM muito acima do último registrado (' + fmtNum(v.km_atual, 0) + '). Confira o número.'); ok = false; return; }
      p.km = km;
    };
    const checarValor = () => {
      const x = parseNum(val('f_valor'));
      if (x == null) return;
      if (isNaN(x) || x < 0) { erroCampo('f_valor', 'Valor inválido.'); ok = false; return; }
      p.valor = x;
    };

    if (modo === 'limpeza') {
      p.tipo = 'limpeza'; p.subtipo = escolha.subtipo || 'completa';
    } else if (modo === 'abastecimento') {
      p.tipo = 'abastecimento';
      checarKm(true);
      const l = parseNum(val('f_litros'));
      if (l == null || isNaN(l) || l <= 0) { erroCampo('f_litros', 'Informe os litros.'); ok = false; }
      else if (l > 2000) { erroCampo('f_litros', 'Litros acima do possível.'); ok = false; }
      else p.litros = l;
      const a = parseNum(val('f_arla'));
      if (a != null) {
        if (isNaN(a) || a <= 0) { erroCampo('f_arla', 'Informe um valor maior que zero ou deixe em branco.'); ok = false; }
        else if (a > 200) { erroCampo('f_arla', 'Arla acima do possível.'); ok = false; }
        else p.litros_arla = a;
      }
    } else if (modo === 'entrada') {
      p.tipo = 'manutencao_entrada';
      if (!escolha.subtipo) { const c = $('c_categoria'); c.classList.add('erro'); c.querySelector('.msg-erro').textContent = 'Escolha o tipo do problema.'; ok = false; }
      else p.subtipo = escolha.subtipo;
      checarKm(false);
      if (val('f_prev')) {
        if (val('f_prev') < hoje()) { erroCampo('f_prev', 'A previsão não pode ser anterior a hoje.'); ok = false; }
        else p.previsao_retorno = val('f_prev');
      }
    } else {
      p.tipo = 'manutencao_saida';
      checarKm(false); checarValor();
    }
    if (val('f_desc')) p.descricao = val('f_desc');
    if (!ok) { vibrar([40, 40, 40]); const e = document.querySelector('#folhaCorpo .campo.erro'); if (e) e.scrollIntoView({ block: 'center', behavior: 'smooth' }); return null; }
    return p;
  }

  async function enviar() {
    const payload = montar();
    if (!payload) return;
    payload.chave = novaChave();
    payload.ocorrido_em = agoraTS();
    const b = $('folhaEnviar');
    const rotulo = b.textContent;
    b.disabled = true; b.textContent = 'Enviando…';
    const v = atual.v;
    try {
      await Api.post('/lancamentos', payload);
      concluido(payload, v, false);
    } catch (e) {
      if (ehRede(e)) { enfileirar(payload, v); concluido(payload, v, true); return; }
      erroGeral(e.message || 'Não foi possível registrar. Tente de novo.');
      b.disabled = false; b.textContent = rotulo;
      vibrar([60, 40, 60]);
    }
  }

  // atualiza a tela na hora, sem esperar o servidor (o servidor confirma no recarregamento)
  function aplicarLocal(p, v) {
    if (p.km) v.km_atual = Math.max(v.km_atual || 0, p.km);
    if (p.tipo === 'limpeza') { v.limpeza_em = p.ocorrido_em; v.pendencias = []; if (v.estado === 'pendente') v.estado = 'pronto'; }
    else if (p.tipo === 'abastecimento') { v.abast_em = p.ocorrido_em; v.abast_km = p.km; v.abast_litros = p.litros; v.abast_arla = p.litros_arla || null; }
    else if (p.tipo === 'manutencao_entrada') { v.estado = 'manutencao'; v.manut = { desde: p.ocorrido_em, subtipo: p.subtipo, descricao: p.descricao || '', previsao: p.previsao_retorno || '' }; }
    else if (p.tipo === 'manutencao_saida') { v.manut = null; v.estado = pendente(v) ? 'pendente' : 'pronto'; }
  }

  const TEXTOS_OK = {
    limpeza: ['Limpeza lançada', 'Lançar outra limpeza'],
    abastecimento: ['Abastecimento registrado', 'Registrar outro abastecimento'],
    manutencao_entrada: ['Veículo parado para manutenção', 'Lançar outro veículo'],
    manutencao_saida: ['Veículo liberado', 'Lançar outro veículo'],
  };
  function concluido(p, v, guardado) {
    aplicarLocal(p, v);
    vibrar(guardado ? [30, 60, 30] : 40);
    const t = TEXTOS_OK[p.tipo];
    const s = $('sucesso');
    s.className = 'sucesso' + (guardado ? ' guardado' : '');
    $('sucessoTitulo').textContent = guardado ? 'Guardado no aparelho' : t[0];
    $('sucessoSub').textContent = guardado
      ? 'Sem conexão agora. O lançamento será enviado sozinho quando o sinal voltar.'
      : 'Veículo ' + v.numero + ' · ' + v.placa + ' · ' + hhmm(p.ocorrido_em);
    $('sucessoLetreiro').innerHTML = letreiro(v);
    $('sucessoOutro').textContent = t[1];
    s.hidden = false;
    fecharFolhaVisual();
    atual = null;
    renderInicio();
    if (!guardado) setTimeout(() => carregar(true), 600);
  }

  // ------------------------------------------------------------------ desfazer / descartar
  function confirmarDesfazer(id) {
    const m = (ctx.meus || []).find((x) => x.id_ocorrencia === id);
    if (!m) return;
    abrirFolha({
      titulo: 'Desfazer este lançamento?',
      sub: (NOMES_TIPO[m.tipo] || m.tipo) + ' · veículo ' + m.numero + ' · ' + hhmm(m.data_hora),
      corpo: '<div class="aviso alerta"><svg class="icone"><use href="#i-aviso"/></svg><span>O lançamento fica marcado como desfeito e some do histórico do veículo.</span></div>',
      botao: 'Sim, desfazer', classe: 'perigo',
      aoConfirmar: async () => {
        const b = $('folhaEnviar');
        b.disabled = true; b.textContent = 'Desfazendo…';
        try {
          await Api.post('/lancamentos/' + id + '/desfazer', { motivo: '' });
          fecharFolhaVisual();
          toast('Lançamento desfeito.');
          carregar(true);
        } catch (e) {
          erroGeral(e.message || 'Não foi possível desfazer.');
          b.disabled = false; b.textContent = 'Sim, desfazer';
        }
      },
    });
  }
  function descartar(chave) {
    gravarFila(lerFila().filter((x) => x.payload.chave !== chave));
    atualizarFaixa();
    renderMeus();
    toast('Lançamento descartado.');
  }

  // ------------------------------------------------------------------ eventos
  document.addEventListener('click', (ev) => {
    const alvo = ev.target.closest('button');
    if (!alvo) return;
    if (alvo.dataset.acao) { abrirVeiculos(alvo.dataset.acao); return; }
    if (alvo.dataset.filtro) { filtro = alvo.dataset.filtro; renderVeiculos(); return; }
    if (alvo.dataset.veiculo) {
      const v = (ctx.veiculos || []).find((x) => String(x.id_veiculo) === alvo.dataset.veiculo);
      if (v) abrirFormulario(v);
      return;
    }
    if (alvo.dataset.seg) {
      escolha[alvo.dataset.seg] = alvo.dataset.valor;
      alvo.parentElement.querySelectorAll('.segmento').forEach((b) => b.setAttribute('aria-pressed', String(b === alvo)));
      const c = $('c_categoria'); if (c) c.classList.remove('erro');
      return;
    }
    if (alvo.dataset.desfazer) { confirmarDesfazer(Number(alvo.dataset.desfazer)); return; }
    if (alvo.dataset.descartar) { descartar(alvo.dataset.descartar); return; }
  });
  $('fundo').addEventListener('click', fecharFolha);
  $('folhaFechar').addEventListener('click', fecharFolha);
  $('folhaEnviar').addEventListener('click', () => { if (aoConfirmar) aoConfirmar(); });
  document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && !$('folha').hidden) fecharFolha(); });
  $('btnVoltar').addEventListener('click', () => history.back());
  $('busca').addEventListener('input', renderVeiculos);
  $('btnAtualizar').addEventListener('click', () => { descarregarFila(); carregar(false); });
  $('btnSair').addEventListener('click', () => {
    if (minhaFila().length) { toast('Espere o envio dos lançamentos pendentes antes de sair.', true); return; }
    Api.sair();
  });
  $('sucessoOutro').addEventListener('click', () => { $('sucesso').hidden = true; history.back(); });
  $('sucessoFim').addEventListener('click', () => { $('sucesso').hidden = true; history.go(-2); });

  window.addEventListener('online', () => { atualizarFaixa(); descarregarFila(); carregar(true); });
  window.addEventListener('offline', atualizarFaixa);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { descarregarFila(); carregar(true); } });
  setInterval(() => { if (!document.hidden && nivel < 2 && $('sucesso').hidden) { descarregarFila(); carregar(true); } }, 60000);

  atualizarFaixa();
  carregar(false).then(descarregarFila);
})();
