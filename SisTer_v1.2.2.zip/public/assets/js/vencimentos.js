// Painel de vencimentos: documentos da frota e dos funcionarios + preventivas por km (GET /api/vencimentos).
exigirLogin();

const $ = (id) => document.getElementById(id);

const usuarioLogado = Api.usuario();
if (usuarioLogado) {
  $('nomeUsuario').textContent = usuarioLogado.nome;
  $('perfilUsuario').textContent = usuarioLogado.perfil;
  $('avatarUsuario').textContent = usuarioLogado.nome.charAt(0).toUpperCase();
  if (usuarioLogado.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML;
}
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3600);
}

// O servidor devolve o NOME da coluna ("campo"); aqui ele vira o rotulo que a pessoa le.
const ROTULOS = {
  venc_vistoria: 'Laudo de vistoria', venc_lic_turismo: 'Licença de turismo', venc_lic_fretamento: 'Licença de fretamento',
  venc_inmetro_nacional: 'Inmetro nacional', venc_inmetro_internacional: 'Inmetro internacional', venc_ipva: 'IPVA',
  venc_consulado_argentina: 'Consulado Argentina', venc_consulado_uruguai: 'Consulado Uruguai', venc_consulado_chile: 'Consulado Chile',
  venc_embratur: 'Embratur', venc_metroplan: 'Laudo Metroplan', venc_antt_nacional: 'Laudo ANTT nacional',
  venc_antt_internacional: 'Laudo ANTT internacional', venc_receftur: 'RecefTur', venc_apolice: 'Apólice de seguro',
  venc_grade_daer: 'Grade horária DAER', venc_extintor: 'Extintor', venc_tacografo: 'Tacógrafo',
  data_vencimento_cnh: 'CNH', data_vencimento_exame_saude: 'Exame de saúde',
  data_vencimento_cnh_internacional: 'CNH internacional', data_vencimento_senac: 'Curso SENAC',
};

const plural = (n, s, p) => (n === 1 ? s : p);
const fmtData = (iso) => (iso ? String(iso).slice(0, 10).split('-').reverse().join('/') : '—');
const fmtKm = (n) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: 0 });
const semAcento = (t) => String(t == null ? '' : t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

function textoPrazo(dias) {
  if (dias < 0) return `Vencido há ${-dias} ${plural(-dias, 'dia', 'dias')}`;
  if (dias === 0) return 'Vence hoje';
  if (dias === 1) return 'Vence amanhã';
  return `Vence em ${dias} dias`;
}
function classePrazo(dias) {
  if (dias <= 7) return 'badge-perigo';
  if (dias <= 30) return 'badge-alerta';
  return 'badge-ativo';
}

let docs = [];
let preventivas = [];
let acesso = { frota: true, funcionarios: true };
const filtros = { dias: 60, tipo: '', busca: '', antigos: false };

async function carregar() {
  const q = new URLSearchParams({ dias: filtros.dias, vencidos_ate: filtros.antigos ? 3650 : 365 });
  try {
    const r = await Api.get('/vencimentos?' + q.toString());
    docs = r.dados || [];
    preventivas = r.preventivas || [];
    acesso = { frota: !!r.acesso_frota, funcionarios: !!r.acesso_funcionarios };
  } catch (e) {
    mostrarToast(e.message);
    $('vazioDocsTitulo').textContent = 'Não foi possível carregar';
    $('vazioDocsTexto').textContent = e.message;
    $('vazioDocs').style.display = 'block';
    return;
  }
  renderizar();
}

function casaBusca(texto) {
  const termo = semAcento(filtros.busca.trim());
  return !termo || semAcento(texto).includes(termo);
}

function renderizar() {
  $('geradoEm').textContent = 'Vencimentos em ' + new Date().toLocaleDateString('pt-BR') + ' (próximos ' + filtros.dias + ' dias)';

  // ---- cartoes de resumo (sempre sobre tudo o que veio do servidor)
  $('kVencidos').textContent = docs.filter((d) => d.dias < 0).length;
  $('kSemana').textContent = docs.filter((d) => d.dias >= 0 && d.dias <= 7).length;
  $('kMes').textContent = docs.filter((d) => d.dias > 7 && d.dias <= 30).length;
  $('kPrev').textContent = acesso.frota ? preventivas.length : '—';

  // ---- documentos
  const mostrarDocs = filtros.tipo !== 'preventiva';
  $('blocoDocs').style.display = mostrarDocs ? '' : 'none';
  const lista = docs.filter((d) =>
    (!filtros.tipo || d.tipo === filtros.tipo) &&
    casaBusca(`${d.nome} ${d.numero == null ? '' : d.numero} ${ROTULOS[d.campo] || d.campo}`));

  const corpo = $('corpoDocs');
  corpo.innerHTML = '';
  lista.forEach((d) => {
    const ehVeiculo = d.tipo === 'veiculo';
    const item = ehVeiculo
      ? `<strong>Veículo ${escaparHtml(d.numero)}</strong> <span class="placa">${escaparHtml(d.nome)}</span>`
      : `<strong>${escaparHtml(d.nome)}</strong> <span class="nota">funcionário</span>`;
    const n = d.viagens_afetadas || 0;
    const impacto = n > 0
      ? `<span class="badge badge-perigo">${n} ${plural(n, 'viagem', 'viagens')} · 1ª em ${fmtData(d.primeira_viagem)}</span>`
      : '<span class="nota">—</span>';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><span class="badge ${classePrazo(d.dias)}">${textoPrazo(d.dias)}</span></td>
      <td>${item}</td>
      <td>${escaparHtml(ROTULOS[d.campo] || d.campo)}</td>
      <td>${fmtData(d.vencimento)}</td>
      <td>${impacto}</td>`;
    tr.addEventListener('click', () => { window.location.href = ehVeiculo ? 'frota.html' : 'funcionarios.html'; });
    corpo.appendChild(tr);
  });

  const semAlgumAcesso = !acesso.frota || !acesso.funcionarios;
  const vazio = mostrarDocs && lista.length === 0;
  $('vazioDocs').style.display = vazio ? 'block' : 'none';
  if (vazio) {
    const filtrando = filtros.tipo || filtros.busca.trim();
    $('vazioDocsTitulo').textContent = filtrando ? 'Nada encontrado' : 'Tudo em dia';
    $('vazioDocsTexto').textContent = filtrando
      ? 'Nenhum documento combina com o filtro.'
      : `Nenhum documento vencido ou vencendo nos próximos ${filtros.dias} dias.` +
        (semAlgumAcesso ? ' (Seu perfil não vê ' + (!acesso.frota ? 'a frota' : 'os funcionários') + '.)' : '');
  }

  // ---- preventivas por km
  const mostrarPrev = acesso.frota && (filtros.tipo === '' || filtros.tipo === 'preventiva');
  $('blocoPrev').style.display = mostrarPrev ? '' : 'none';
  const listaPrev = preventivas.filter((p) => casaBusca(`${p.placa} ${p.numero} ${p.descricao}`));
  const corpoPrev = $('corpoPrev');
  corpoPrev.innerHTML = '';
  listaPrev.forEach((p) => {
    const faltam = Math.round(p.faltam_km);
    const situacao = faltam <= 0
      ? `<span class="badge badge-perigo">Passou ${fmtKm(-faltam)} km</span>`
      : `<span class="badge badge-alerta">Faltam ${fmtKm(faltam)} km</span>`;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>Veículo ${escaparHtml(p.numero)}</strong> <span class="placa">${escaparHtml(p.placa)}</span></td>
      <td>${escaparHtml(p.descricao || '—')}</td>
      <td class="n">${fmtKm(p.km_atual)}</td>
      <td class="n">${fmtKm(p.proxima_troca)}</td>
      <td>${situacao}</td>`;
    tr.addEventListener('click', () => { window.location.href = 'frota.html'; });
    corpoPrev.appendChild(tr);
  });
  $('vazioPrev').style.display = mostrarPrev && listaPrev.length === 0 ? 'block' : 'none';
}

$('fJanela').addEventListener('change', (ev) => { filtros.dias = Number(ev.target.value); carregar(); });
$('fAntigos').addEventListener('change', (ev) => { filtros.antigos = ev.target.checked; carregar(); });
$('fTipo').addEventListener('change', (ev) => { filtros.tipo = ev.target.value; renderizar(); });
$('fBusca').addEventListener('input', (ev) => { filtros.busca = ev.target.value; renderizar(); });
$('btnImprimir').addEventListener('click', () => window.print());

carregar();
