// Formatação e validação de CPF/CNPJ - só com JS puro, sem biblioteca externa.
// Algoritmos de dígito verificador são públicos (Receita Federal).

function somenteDigitos(valor) {
  return (valor || '').replace(/\D/g, '');
}

function formatarCpfCnpj(valor) {
  const digitos = somenteDigitos(valor).slice(0, 14);

  if (digitos.length <= 11) {
    // CPF: 000.000.000-00
    return digitos
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  }

  // CNPJ: 00.000.000/0000-00
  return digitos
    .replace(/(\d{2})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1/$2')
    .replace(/(\d{4})(\d{1,2})$/, '$1-$2');
}

function validarCPF(valorFormatado) {
  const cpf = somenteDigitos(valorFormatado);
  if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false;

  let soma = 0;
  for (let i = 0; i < 9; i++) soma += parseInt(cpf[i], 10) * (10 - i);
  let resto = (soma * 10) % 11;
  if (resto === 10 || resto === 11) resto = 0;
  if (resto !== parseInt(cpf[9], 10)) return false;

  soma = 0;
  for (let i = 0; i < 10; i++) soma += parseInt(cpf[i], 10) * (11 - i);
  resto = (soma * 10) % 11;
  if (resto === 10 || resto === 11) resto = 0;
  if (resto !== parseInt(cpf[10], 10)) return false;

  return true;
}

function validarCNPJ(valorFormatado) {
  const cnpj = somenteDigitos(valorFormatado);
  if (cnpj.length !== 14 || /^(\d)\1{13}$/.test(cnpj)) return false;

  const calcularDigito = (base) => {
    let pos = base.length - 7;
    let soma = 0;
    for (let i = base.length; i >= 1; i--) {
      soma += parseInt(base.charAt(base.length - i), 10) * pos--;
      if (pos < 2) pos = 9;
    }
    const resultado = soma % 11 < 2 ? 0 : 11 - (soma % 11);
    return resultado;
  };

  const digito1 = calcularDigito(cnpj.substring(0, 12));
  if (digito1 !== parseInt(cnpj.charAt(12), 10)) return false;

  const digito2 = calcularDigito(cnpj.substring(0, 13));
  if (digito2 !== parseInt(cnpj.charAt(13), 10)) return false;

  return true;
}

// Valida CPF (11 dígitos) ou CNPJ (14 dígitos) conforme o tamanho digitado.
// Campo vazio é considerado válido (o campo não é obrigatório no cadastro).
function validarCpfCnpj(valorFormatado) {
  const digitos = somenteDigitos(valorFormatado);
  if (digitos.length === 0) return true;
  if (digitos.length === 11) return validarCPF(digitos);
  if (digitos.length === 14) return validarCNPJ(digitos);
  return false; // quantidade de dígitos incompleta/errada
}
