exigirLogin();

const $ = (id) => document.getElementById(id);

const usuario = Api.usuario();
if (usuario) {
  $('nomeUsuario').textContent = usuario.nome;
  $('perfilUsuario').textContent = usuario.perfil;
  $('avatarUsuario').textContent = usuario.nome.charAt(0).toUpperCase();
  if (usuario.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

// ---------------------------------------------------------------- helpers
function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
// display inline: o atributo hidden perde para o display de .btn/.aba
function exibir(el, visivel) { el.style.display = visivel ? '' : 'none'; }
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3400);
}
const fmtDataBR = (s) => { if (!s) return '—'; const [a, m, d] = String(s).slice(0, 10).split('-'); return `${d}/${m}/${a}`; };
const fmtMoeda = (n) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const fmtQtd = (n) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: 3 });
const fmtSinal = (n) => (n > 0 ? '+' : n < 0 ? '−' : '') + fmtQtd(Math.abs(n));
const arred3 = (n) => Math.round(Number(n) * 1000) / 1000;
function hojeISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
const num = (v) => (v === '' || v == null ? null : Number(v));

// ---------------------------------------------------------------- lista
const params = new URLSearchParams(location.search);
let pagina = 1;
const itensPorPagina = 50;
let busca = params.get('busca') || '';
let filtro = ['repor', 'zerado'].includes(params.get('filtro')) ? params.get('filtro') : '';
let categoria = '';
let somenteAtivos = true;
let categoriasConhecidas = [];
let opcoes = { fornecedores: [], veiculos: [] };
let temporizador = null;
$('campoBusca').value = busca;

function nivelBarra(i) {
  const saldo = Number(i.saldo), min = Number(i.estoque_minimo);
  let pct;
  if (min > 0) pct = Math.max(0, Math.min(100, (saldo / (min * 2)) * 100));
  else pct = saldo > 0 ? 100 : 0;
  return `<div class="nivel nivel-${i.nivel}"><div class="nivel-fill" style="width:${pct.toFixed(0)}%"></div>${min > 0 ? '<span class="nivel-min"></span>' : ''}</div>`;
}

async function carregar() {
  try {
    const q = new URLSearchParams({ busca, filtro, categoria, somente_ativos: somenteAtivos ? '1' : '0', pagina, itens_por_pagina: itensPorPagina });
    const r = await Api.get('/estoque?' + q.toString());
    categoriasConhecidas = r.categorias || [];
    renderCategorias();
    renderResumo(r.resumo);
    renderTabela(r.dados);

    const inicio = r.total === 0 ? 0 : (r.pagina - 1) * r.itens_por_pagina + 1;
    const fim = Math.min(r.pagina * r.itens_por_pagina, r.total);
    $('contador').textContent = `${r.total} ${r.total === 1 ? 'item' : 'itens'} na lista`;
    $('textoPaginacao').textContent = r.total ? `Mostrando ${inicio}–${fim} de ${r.total}` : '';
    $('btnAnterior').disabled = r.pagina <= 1;
    $('btnProximo').disabled = fim >= r.total;
  } catch (e) { mostrarToast(e.message); }
}

function renderResumo(s) {
  $('kItens').textContent = s.itens;
  $('kRepor').textContent = s.repor;
  $('kZerados').textContent = s.zerados;
  $('kValor').textContent = fmtMoeda(s.valor_estoque);
  $('kpiRepor').classList.toggle('alerta', s.repor > 0);
  $('kpiZerados').classList.toggle('perigo', s.zerados > 0);
  document.querySelectorAll('button.kpi').forEach((b) => b.classList.toggle('selecionado', b.dataset.filtro === filtro));
}

function renderCategorias() {
  const sel = $('filtroCategoria');
  sel.innerHTML = '<option value="">Todas as categorias</option>' +
    categoriasConhecidas.map((c) => `<option value="${escaparHtml(c)}"${c === categoria ? ' selected' : ''}>${escaparHtml(c)}</option>`).join('');
  $('listaCategorias').innerHTML = categoriasConhecidas.map((c) => `<option value="${escaparHtml(c)}"></option>`).join('');
}

function renderTabela(dados) {
  const corpo = $('corpoTabela');
  corpo.innerHTML = '';
  $('estadoVazio').style.display = dados.length ? 'none' : 'block';

  dados.forEach((i) => {
    const subs = [i.referencia, i.categoria, i.localizacao].filter(Boolean).join(' · ');
    const selo = i.nivel === 'zerado' ? '<span class="selo selo-zerado">Sem saldo</span>' : i.nivel === 'repor' ? '<span class="selo selo-repor">Repor</span>' : '';
    const inativo = i.situacao !== 'A' ? ' <span class="badge badge-inativo">Inativo</span>' : '';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="cod">${i.id_item}</td>
      <td><div class="nome-item">${escaparHtml(i.descricao)}${inativo}</div>${subs ? `<div class="sub-item">${escaparHtml(subs)}</div>` : ''}</td>
      <td class="saldo-celula"><span class="saldo-valor">${fmtQtd(i.saldo)} <small>${escaparHtml(i.unidade)}</small></span>${selo}${nivelBarra(i)}</td>
      <td class="num col-esconde">${Number(i.estoque_minimo) > 0 ? fmtQtd(i.estoque_minimo) : '—'}</td>
      <td class="num col-esconde">${i.custo_medio == null ? '—' : fmtMoeda(i.custo_medio)}</td>
      <td class="col-esconde">${fmtDataBR(i.ultima_movimentacao)}</td>
      <td><div class="acoes-linha">
        <button type="button" class="btn-mov entrada" data-mov="E" data-perm="incluir" title="Registrar entrada">+ Entrada</button>
        <button type="button" class="btn-mov saida" data-mov="S" data-perm="incluir" title="Registrar saída">− Saída</button>
      </div></td>`;
    tr.addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-mov]');
      if (b) abrirDialogo(i, b.dataset.mov, null);
      else abrirItem(i.id_item, 'mov');
    });
    corpo.appendChild(tr);
  });
}

$('campoBusca').addEventListener('input', (ev) => {
  clearTimeout(temporizador);
  temporizador = setTimeout(() => { busca = ev.target.value.trim(); pagina = 1; carregar(); }, 300);
});
$('filtroCategoria').addEventListener('change', (ev) => { categoria = ev.target.value; pagina = 1; carregar(); });
$('checkSomenteAtivos').addEventListener('change', (ev) => { somenteAtivos = ev.target.checked; pagina = 1; carregar(); });
document.querySelectorAll('button.kpi').forEach((b) => b.addEventListener('click', () => {
  filtro = filtro === b.dataset.filtro ? '' : b.dataset.filtro;
  pagina = 1;
  carregar();
}));
$('btnAnterior').addEventListener('click', () => { if (pagina > 1) { pagina--; carregar(); } });
$('btnProximo').addEventListener('click', () => { pagina++; carregar(); });

async function carregarOpcoes() {
  try { opcoes = await Api.get('/estoque-opcoes'); } catch (e) { /* seletores ficam vazios */ }
  const opt = (v, t) => `<option value="${v}">${escaparHtml(t)}</option>`;
  $('iFornecedor').innerHTML = '<option value="">— nenhum —</option>' + opcoes.fornecedores.map((f) => opt(f.id_fornecedor, f.nome)).join('');
  $('mFornecedor').innerHTML = '<option value="">— não informado —</option>' + opcoes.fornecedores.map((f) => opt(f.id_fornecedor, f.nome)).join('');
  $('mVeiculo').innerHTML = '<option value="">— não informado —</option>' +
    opcoes.veiculos.map((v) => opt(v.id_veiculo, `${v.numero} · ${v.placa}${v.modelo ? ' · ' + v.modelo : ''}`)).join('');
}

// ---------------------------------------------------------------- painel do item
const painelFundo = $('painelFundo');
const painelLateral = $('painelLateral');
let itemAtual = null;   // item aberto (null = novo)
let movimentos = [];

function abrirPainel() { painelFundo.classList.add('aberto'); painelLateral.classList.add('aberto'); }
function fecharPainel() { painelFundo.classList.remove('aberto'); painelLateral.classList.remove('aberto'); }
$('btnFecharPainel').addEventListener('click', fecharPainel);
$('btnCancelarPainel').addEventListener('click', fecharPainel);
painelFundo.addEventListener('click', fecharPainel);
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && !$('dlgMov').open) fecharPainel(); });

function mostrarAba(nome) {
  document.querySelectorAll('#abas .aba').forEach((a) => a.classList.toggle('ativa', a.dataset.aba === nome));
  document.querySelectorAll('.painel-corpo .pane').forEach((p) => p.classList.toggle('ativo', p.dataset.pane === nome));
  exibir($('btnSalvar'), nome === 'dados');
  exibir($('btnInativar'), nome === 'dados' && !!itemAtual && itemAtual.situacao === 'A');
  if (nome === 'mov') carregarMovimentos();
}
$('abas').addEventListener('click', (ev) => { const a = ev.target.closest('.aba'); if (a && a.style.display !== 'none') mostrarAba(a.dataset.aba); });

function preencherItem(i) {
  $('iDescricao').value = i ? i.descricao : '';
  $('iReferencia').value = i ? i.referencia : '';
  $('iCategoria').value = i ? i.categoria : '';
  $('iUnidade').value = i ? i.unidade : 'UN';
  $('iMinimo').value = i && Number(i.estoque_minimo) > 0 ? i.estoque_minimo : '';
  $('iLocalizacao').value = i ? i.localizacao : '';
  $('iFornecedor').value = i && i.id_fornecedor ? String(i.id_fornecedor) : '';
  $('iObservacoes').value = i ? i.observacoes : '';
  $('iSituacao').value = i ? i.situacao : 'A';
  $('iQtdInicial').value = '';
  $('iValorInicial').value = '';
}

function configurarPainel(edicao) {
  document.querySelectorAll('#abas [data-so-edicao]').forEach((a) => exibir(a, edicao));
  exibir($('blocoSituacao'), edicao);
  exibir($('blocoInicial'), !edicao);
  painelLateral.dataset.novo = edicao ? '0' : '1';
}

$('btnNovo').addEventListener('click', () => {
  itemAtual = null;
  movimentos = [];
  preencherItem(null);
  configurarPainel(false);
  $('tituloPainel').textContent = 'Novo item';
  $('subtituloPainel').textContent = '';
  mostrarAba('dados');
  abrirPainel();
  $('iDescricao').focus();
});

async function abrirItem(id, aba) {
  try {
    itemAtual = await Api.get('/estoque/' + id);
    preencherItem(itemAtual);
    configurarPainel(true);
    $('tituloPainel').textContent = itemAtual.descricao;
    $('subtituloPainel').textContent = `Código ${itemAtual.id_item}`;
    mostrarAba(aba || 'dados');
    abrirPainel();
  } catch (e) { mostrarToast(e.message); }
}

async function recarregarItemAberto() {
  if (!itemAtual) return;
  try {
    itemAtual = await Api.get('/estoque/' + itemAtual.id_item);
    renderTotais();
    await carregarMovimentos();
  } catch (e) { mostrarToast(e.message); }
}

function coletarItem() {
  return {
    descricao: $('iDescricao').value.trim(),
    referencia: $('iReferencia').value.trim(),
    categoria: $('iCategoria').value.trim(),
    unidade: $('iUnidade').value.trim().toUpperCase() || 'UN',
    estoque_minimo: num($('iMinimo').value) ?? 0,
    localizacao: $('iLocalizacao').value.trim(),
    id_fornecedor: num($('iFornecedor').value),
    observacoes: $('iObservacoes').value.trim(),
    ...(itemAtual ? { situacao: $('iSituacao').value || 'A' } : {}),
  };
}

$('btnSalvar').addEventListener('click', async () => {
  if (!$('formItem').reportValidity()) return;
  const botao = $('btnSalvar');
  botao.disabled = true;
  botao.textContent = 'Salvando...';
  try {
    const dados = coletarItem();
    if (itemAtual) {
      await Api.put('/estoque/' + itemAtual.id_item, dados);
      mostrarToast('Item atualizado.');
    } else {
      const criado = await Api.post('/estoque', dados);
      const qtd = num($('iQtdInicial').value);
      if (qtd && qtd > 0) {
        try {
          await Api.post(`/estoque/${criado.id_item}/movimentos`, {
            tipo: 'E', data: hojeISO(), quantidade: qtd, valor_unitario: num($('iValorInicial').value),
            id_fornecedor: dados.id_fornecedor, documento: '', observacao: 'Saldo inicial',
          });
        } catch (e) { mostrarToast('Item criado, mas o saldo inicial não foi lançado: ' + e.message); }
      }
      mostrarToast(`Item cadastrado (código ${criado.id_item}).`);
    }
    fecharPainel();
    carregar();
  } catch (e) { mostrarToast(e.message); }
  finally { botao.disabled = false; botao.textContent = 'Salvar item'; }
});

$('btnInativar').addEventListener('click', async () => {
  if (!itemAtual) return;
  const aviso = Number(itemAtual.saldo) > 0 ? `Este item ainda tem saldo de ${fmtQtd(itemAtual.saldo)} ${itemAtual.unidade}. ` : '';
  if (!confirm(`${aviso}Inativar este item? O histórico é mantido e você pode reativá-lo depois.`)) return;
  try {
    await Api.del('/estoque/' + itemAtual.id_item);
    mostrarToast('Item inativado.');
    fecharPainel();
    carregar();
  } catch (e) { mostrarToast(e.message); }
});

// ---------------------------------------------------------------- livro de movimentacoes
function renderTotais() {
  $('tEntrada').textContent = fmtQtd(itemAtual.entradas);
  $('tSaida').textContent = fmtQtd(itemAtual.saidas);
  $('tSaldo').textContent = `${fmtQtd(itemAtual.saldo)} ${itemAtual.unidade}`;
}

const ROTULO_TIPO = { E: ['Entrada', 'badge-ativo'], S: ['Saída', 'badge-perigo'], A: ['Ajuste', 'badge-alerta'] };

async function carregarMovimentos() {
  if (!itemAtual) return;
  renderTotais();
  try {
    const r = await Api.get(`/estoque/${itemAtual.id_item}/movimentos`);
    movimentos = r.dados || [];
    renderMovimentos();
  } catch (e) { mostrarToast(e.message); }
}

function renderMovimentos() {
  if (!movimentos.length) {
    $('movLista').innerHTML = '<p class="vazio-aba">Nenhuma movimentação ainda. Registre a primeira entrada para formar o saldo.</p>';
    return;
  }
  $('movLista').innerHTML = `<div class="hist-lista" style="max-height:none;"><table class="tabela-mini">
    <thead><tr><th>Data</th><th>Tipo</th><th class="num">Qtde</th><th class="num">Vl. unit.</th><th>Detalhe</th><th class="num">Saldo após</th></tr></thead>
    <tbody>${movimentos.map((m) => {
      const [rot, cls] = ROTULO_TIPO[m.tipo] || [m.tipo, 'badge-inativo'];
      const efeito = m.tipo === 'S' ? -Number(m.quantidade) : Number(m.quantidade);
      const det = [
        m.fornecedor_nome,
        m.veiculo_placa ? `Veículo ${m.veiculo_numero} (${m.veiculo_placa})` : '',
        m.documento ? `Doc. ${m.documento}` : '',
        m.observacao,
      ].filter(Boolean).map(escaparHtml).join(' · ');
      return `<tr data-id="${m.id_movimento}">
        <td>${fmtDataBR(m.data)}</td>
        <td><span class="badge ${cls}">${rot}</span></td>
        <td class="num ${efeito < 0 ? 'qtd-neg' : 'qtd-pos'}">${fmtSinal(efeito)}</td>
        <td class="num">${m.valor_unitario == null ? '—' : fmtMoeda(m.valor_unitario)}</td>
        <td class="detalhe-mov">${det || '—'}${m.usuario ? `<div>${escaparHtml(m.usuario)}</div>` : ''}</td>
        <td class="num"><strong>${fmtQtd(m.saldo_apos)}</strong></td>
      </tr>`;
    }).join('')}</tbody></table></div>`;
}
$('movLista').addEventListener('click', (ev) => {
  const tr = ev.target.closest('tr[data-id]');
  if (!tr || !itemAtual) return;
  const m = movimentos.find((x) => x.id_movimento === Number(tr.dataset.id));
  if (m) abrirDialogo(itemAtual, m.tipo, m);
});
$('btnPEntrada').addEventListener('click', () => abrirDialogo(itemAtual, 'E', null));
$('btnPSaida').addEventListener('click', () => abrirDialogo(itemAtual, 'S', null));
$('btnPContagem').addEventListener('click', () => abrirDialogo(itemAtual, 'A', null));

// ---------------------------------------------------------------- janela de movimentacao
const dlg = $('dlgMov');
let estado = { item: null, tipo: 'E', mov: null };

function abrirDialogo(item, tipo, mov) {
  estado = { item, tipo, mov };
  const edicao = !!mov;
  $('dlgItem').textContent = `${item.id_item} · ${item.descricao} — saldo atual: ${fmtQtd(item.saldo)} ${item.unidade}`;
  $('dlgErro').style.display = 'none';
  exibir($('dlgTipos'), !edicao);
  exibir($('mExcluir'), edicao);

  $('mData').max = hojeISO();
  $('mData').value = edicao ? mov.data : hojeISO();
  $('mQtd').value = edicao ? mov.quantidade : '';
  $('mValor').value = edicao && mov.valor_unitario != null ? mov.valor_unitario : '';
  $('mValor').placeholder = item.custo_medio ? `custo médio ${fmtMoeda(item.custo_medio)}` : '';
  $('mFornecedor').value = edicao ? (mov.id_fornecedor ? String(mov.id_fornecedor) : '') : (item.id_fornecedor ? String(item.id_fornecedor) : '');
  $('mVeiculo').value = edicao && mov.id_veiculo ? String(mov.id_veiculo) : '';
  $('mDocumento').value = edicao ? mov.documento : '';
  $('mObs').value = edicao ? mov.observacao : '';

  $('mSalvar').dataset.perm = edicao ? 'editar' : 'incluir';
  $('mSalvar').textContent = edicao ? 'Salvar alterações' : 'Registrar';
  aplicarTipo();
  Permissoes.aplicar();
  dlg.showModal();
  $('mQtd').focus();
}

function aplicarTipo() {
  const { tipo, mov } = estado;
  document.querySelectorAll('#dlgTipos .pilula').forEach((p) => p.classList.toggle('ativa', p.dataset.tipo === tipo));
  exibir($('gruposEntrada'), tipo === 'E');
  exibir($('gruposSaida'), tipo === 'S');
  exibir($('gruposDocumento'), tipo !== 'A');
  $('rotuloDoc').textContent = tipo === 'E' ? 'Nota fiscal / documento' : 'O.S. / documento';
  $('dlgTitulo').textContent = (mov ? 'Editar ' : 'Registrar ') + { E: 'entrada', S: 'saída', A: mov ? 'ajuste de inventário' : 'contagem de inventário' }[tipo];
  $('rotuloQtd').textContent = tipo === 'A' ? (mov ? 'Ajuste (+ sobra / − falta)' : 'Quantidade contada (o que existe agora)') : 'Quantidade';
  $('mQtd').min = tipo === 'A' && mov ? '' : '0';
  atualizarPrevia();
}
$('dlgTipos').addEventListener('click', (ev) => {
  const p = ev.target.closest('.pilula');
  if (!p || estado.mov) return;
  estado.tipo = p.dataset.tipo;
  aplicarTipo();
});
$('mQtd').addEventListener('input', atualizarPrevia);
$('mValor').addEventListener('input', atualizarPrevia);

function atualizarPrevia() {
  const { item, tipo, mov } = estado;
  const alvo = $('dlgPrevia');
  const q = num($('mQtd').value);
  const un = item.unidade;
  alvo.className = 'previa';
  if (q == null || Number.isNaN(q)) { alvo.textContent = `Saldo atual: ${fmtQtd(item.saldo)} ${un}`; return; }

  const efeitoAntigo = mov ? (mov.tipo === 'S' ? -Number(mov.quantidade) : Number(mov.quantidade)) : 0;
  const base = arred3(Number(item.saldo) - efeitoAntigo);

  if (tipo === 'A' && !mov) {
    const dif = arred3(q - Number(item.saldo));
    if (q < 0) { alvo.className = 'previa ruim'; alvo.textContent = 'A quantidade contada não pode ser negativa.'; return; }
    if (dif === 0) { alvo.textContent = 'A contagem confere com o saldo do sistema: nada será lançado.'; return; }
    alvo.className = 'previa atencao';
    alvo.textContent = `Saldo do sistema ${fmtQtd(item.saldo)} → contado ${fmtQtd(q)}: ${dif > 0 ? 'sobra' : 'falta'} de ${fmtQtd(Math.abs(dif))} ${un} será ajustada.`;
    return;
  }

  const efeito = tipo === 'S' ? -q : q;
  const depois = arred3(base + efeito);
  let texto = `Saldo: ${fmtQtd(item.saldo)} → ${fmtQtd(depois)} ${un}`;
  if (tipo === 'E' && num($('mValor').value) > 0) texto += `  ·  total ${fmtMoeda(q * num($('mValor').value))}`;
  alvo.textContent = texto;
  if (depois < 0) { alvo.className = 'previa ruim'; alvo.textContent = `Saldo insuficiente: ficaria em ${fmtQtd(depois)} ${un}.`; }
  else if (Number(item.estoque_minimo) > 0 && depois <= Number(item.estoque_minimo)) alvo.className = 'previa atencao';
}

function erroDialogo(msg) { const e = $('dlgErro'); e.textContent = msg; e.style.display = 'block'; }
$('mCancelar').addEventListener('click', () => dlg.close());
// Enter num campo salva (em vez de fechar a janela, que e o padrao de <form method="dialog">)
$('formMov').addEventListener('submit', (ev) => { ev.preventDefault(); $('mSalvar').click(); });

$('mSalvar').addEventListener('click', async () => {
  const { item, tipo, mov } = estado;
  const q = num($('mQtd').value);
  if (q == null || Number.isNaN(q)) return erroDialogo('Informe a quantidade.');
  if (!$('mData').value) return erroDialogo('Informe a data.');
  const botao = $('mSalvar');
  botao.disabled = true;
  try {
    let msg;
    if (tipo === 'A' && !mov) {
      const r = await Api.post(`/estoque/${item.id_item}/inventario`, { quantidade_contada: q, data: $('mData').value, observacao: $('mObs').value.trim() });
      msg = Number(r.diferenca) === 0 ? 'Contagem confere com o saldo. Nada a ajustar.' : `Inventário registrado: ajuste de ${fmtSinal(r.diferenca)} ${item.unidade}.`;
    } else {
      const dados = {
        tipo, data: $('mData').value, quantidade: q,
        valor_unitario: num($('mValor').value), id_fornecedor: num($('mFornecedor').value), id_veiculo: num($('mVeiculo').value),
        documento: $('mDocumento').value.trim(), observacao: $('mObs').value.trim(),
      };
      if (mov) await Api.put(`/estoque/${item.id_item}/movimentos/${mov.id_movimento}`, dados);
      else await Api.post(`/estoque/${item.id_item}/movimentos`, dados);
      msg = mov ? 'Movimentação atualizada.' : { E: 'Entrada registrada.', S: 'Saída registrada.', A: 'Ajuste registrado.' }[tipo];
    }
    dlg.close();
    mostrarToast(msg);
    carregar();
    recarregarItemAberto();
  } catch (e) { erroDialogo(e.message); }
  finally { botao.disabled = false; }
});

$('mExcluir').addEventListener('click', async () => {
  const { item, mov } = estado;
  if (!mov || !confirm('Excluir esta movimentação? O saldo será recalculado.')) return;
  try {
    await Api.del(`/estoque/${item.id_item}/movimentos/${mov.id_movimento}`);
    dlg.close();
    mostrarToast('Movimentação excluída.');
    carregar();
    recarregarItemAberto();
  } catch (e) { erroDialogo(e.message); }
});

// ---------------------------------------------------------------- inicio
(async function iniciar() {
  await carregarOpcoes();
  await carregar();
  const abrir = Number(params.get('item'));
  if (abrir) abrirItem(abrir, 'mov');
})();
