  document.getElementById('formLogin').addEventListener('submit', async (ev) => {
    ev.preventDefault();

    const btn = document.getElementById('btnEntrar');
    const msgErro = document.getElementById('msgErro');
    msgErro.style.display = 'none';
    btn.textContent = 'Entrando...';
    btn.disabled = true;

    try {
      const resp = await Api.post('/auth/login', {
        login: document.getElementById('login').value,
        senha: document.getElementById('senha').value,
      });

      Api.salvarSessao(resp.token, resp.usuario);
      if (resp.usuario.precisa_trocar_senha) { window.location.href = 'trocar-senha.html'; return; }
      // quem so lanca pelo celular (limpeza, garagem) entra direto na tela de lancamentos
      await Permissoes.carregar();
      window.location.href = Permissoes.somenteCampo() ? 'lancamentos.html' : 'index.html';
    } catch (e) {
      msgErro.textContent = e.message || 'Não foi possível entrar. Confira usuário e senha.';
      msgErro.style.display = 'block';
      btn.textContent = 'Entrar';
      btn.disabled = false;
    }
  });
