exigirLogin();

const $ = (id) => document.getElementById(id);

const usuario = Api.usuario();
if (usuario) {
  $('nomeUsuario').textContent = usuario.nome;
  $('perfilUsuario').textContent = usuario.perfil;
  $('avatarUsuario').textContent = usuario.nome.charAt(0).toUpperCase();
  if (usuario.perfil === 'Administrador') $('navAdministracao').style.display = '';
}
$('btnSair').addEventListener('click', () => Api.sair());

// ---------------------------------------------------------------- helpers
function escaparHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
// display inline: o atributo hidden perde para o display de .btn/.aba/.sub-abas
function exibir(el, visivel) { el.style.display = visivel ? '' : 'none'; }
function mostrarToast(msg) {
  const t = $('avisoToast');
  t.textContent = msg;
  t.classList.add('visivel');
  setTimeout(() => t.classList.remove('visivel'), 3200);
}
const fmtDataBR = (s) => { if (!s) return '—'; const [a, m, d] = String(s).slice(0, 10).split('-'); return `${d}/${m}/${a}`; };
const fmtMoeda = (n) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const fmtQtd = (n) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: 3 });
const normalizar = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

function formatarTelefone(valor) {
  const d = somenteDigitos(valor);
  if (d.length === 0 || d.length > 11 || d[0] === '0') return valor; // 0800 e afins: deixa como digitado
  if (d.length <= 2) return '(' + d;
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}
function formatarCep(valor) {
  const d = somenteDigitos(valor).slice(0, 8);
  return d.length > 5 ? d.slice(0, 5) + '-' + d.slice(5) : d;
}
const linkTel = (t) => (t ? `<a href="tel:${escaparHtml(somenteDigitos(t))}" data-sem-abrir>${escaparHtml(t)}</a>` : '');
const linkEmail = (e) => (e ? `<a href="mailto:${escaparHtml(e)}" data-sem-abrir>${escaparHtml(e)}</a>` : '');

// ---------------------------------------------------------------- lista
const TIPOS_PADRAO = ['Mecânica', 'Elétrica', 'Pneus', 'Combustível', 'Peças', 'Funilaria e pintura', 'Serviços', 'Outros'];
let pagina = 1;
const itensPorPagina = 20;
let busca = new URLSearchParams(location.search).get('busca') || '';
let filtroTipo = '';
let somenteAtivos = true;
let tiposExistentes = [];
let temporizador = null;
$('campoBusca').value = busca;

async function carregar() {
  try {
    const q = new URLSearchParams({ busca, tipo: filtroTipo, somente_ativos: somenteAtivos ? '1' : '0', pagina, itens_por_pagina: itensPorPagina });
    const r = await Api.get('/fornecedores?' + q.toString());
    tiposExistentes = r.tipos || [];
    renderTipos();
    renderTabela(r.dados);

    const inicio = r.total === 0 ? 0 : (r.pagina - 1) * r.itens_por_pagina + 1;
    const fim = Math.min(r.pagina * r.itens_por_pagina, r.total);
    $('contador').textContent = `${r.total} ${r.total === 1 ? 'fornecedor' : 'fornecedores'}`;
    $('textoPaginacao').textContent = r.total ? `Mostrando ${inicio}–${fim} de ${r.total}` : '';
    $('btnAnterior').disabled = r.pagina <= 1;
    $('btnProximo').disabled = fim >= r.total;
  } catch (e) { mostrarToast(e.message); }
}

function renderTipos() {
  const itens = [['', 'Todos'], ...tiposExistentes.map((t) => [t, t])];
  exibir($('filtroTipos'), tiposExistentes.length > 0);
  $('filtroTipos').innerHTML = itens
    .map(([v, rot]) => `<button type="button" class="pilula${v === filtroTipo ? ' ativa' : ''}" data-tipo="${escaparHtml(v)}">${escaparHtml(rot)}</button>`)
    .join('');
}
$('filtroTipos').addEventListener('click', (ev) => {
  const b = ev.target.closest('[data-tipo]');
  if (!b) return;
  filtroTipo = b.dataset.tipo;
  pagina = 1;
  carregar();
});

function renderTabela(dados) {
  const corpo = $('corpoTabela');
  corpo.innerHTML = '';
  $('estadoVazio').style.display = dados.length ? 'none' : 'block';

  dados.forEach((f) => {
    const subs = [f.nome_fantasia, f.sigla].filter(Boolean).join(' · ');
    const contato = [linkTel(f.telefone), linkEmail(f.email)].filter(Boolean).map((x) => `<div>${x}</div>`).join('');
    const extra = f.qtd_contatos ? `<div class="sub-forn">+ ${f.qtd_contatos} ${f.qtd_contatos === 1 ? 'contato' : 'contatos'}</div>` : '';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="cod">${f.id_fornecedor}</td>
      <td><div class="nome-forn">${escaparHtml(f.nome)}</div>${subs ? `<div class="sub-forn">${escaparHtml(subs)}</div>` : ''}</td>
      <td class="doc-forn">${escaparHtml(f.cnpj_cpf) || '—'}</td>
      <td>${f.tipo ? `<span class="badge badge-tipo">${escaparHtml(f.tipo)}</span>` : '—'}</td>
      <td>${escaparHtml([f.cidade, f.uf].filter(Boolean).join(' / ')) || '—'}</td>
      <td class="contato-forn">${contato || '—'}${extra}</td>
      <td><span class="badge ${f.situacao === 'A' ? 'badge-ativo' : 'badge-inativo'}">${f.situacao === 'A' ? 'Ativo' : 'Inativo'}</span></td>`;
    tr.addEventListener('click', (ev) => { if (!ev.target.closest('[data-sem-abrir]')) abrirEdicao(f.id_fornecedor); });
    corpo.appendChild(tr);
  });
}

$('campoBusca').addEventListener('input', (ev) => {
  clearTimeout(temporizador);
  temporizador = setTimeout(() => { busca = ev.target.value.trim(); pagina = 1; carregar(); }, 300);
});
$('checkSomenteAtivos').addEventListener('change', (ev) => { somenteAtivos = ev.target.checked; pagina = 1; carregar(); });
$('btnAnterior').addEventListener('click', () => { if (pagina > 1) { pagina--; carregar(); } });
$('btnProximo').addEventListener('click', () => { pagina++; carregar(); });

// ---------------------------------------------------------------- painel
const painelFundo = $('painelFundo');
const painelLateral = $('painelLateral');
let idAtual = null;

function abrirPainel(titulo) { $('tituloPainel').textContent = titulo; painelFundo.classList.add('aberto'); painelLateral.classList.add('aberto'); }
function fecharPainel() { painelFundo.classList.remove('aberto'); painelLateral.classList.remove('aberto'); }
$('btnFecharPainel').addEventListener('click', fecharPainel);
$('btnCancelarPainel').addEventListener('click', fecharPainel);
painelFundo.addEventListener('click', fecharPainel);
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') fecharPainel(); });

function mostrarAba(nome) {
  document.querySelectorAll('#abas .aba').forEach((a) => a.classList.toggle('ativa', a.dataset.aba === nome));
  document.querySelectorAll('.painel-corpo .pane').forEach((p) => p.classList.toggle('ativo', p.dataset.pane === nome));
  // o rodape (Salvar/Inativar) so faz sentido na aba de dados
  exibir($('btnSalvar'), nome === 'dados');
  exibir($('btnInativar'), nome === 'dados' && !!idAtual && $('fSituacao').value === 'A');
  if (nome === 'contatos') carregarContatos();
  if (nome === 'compras') carregarCompras();
}
$('abas').addEventListener('click', (ev) => { const a = ev.target.closest('.aba'); if (a && a.style.display !== 'none') mostrarAba(a.dataset.aba); });

const CAMPOS = {
  fCnpjCpf: 'cnpj_cpf', fTipo: 'tipo', fNome: 'nome', fNomeFantasia: 'nome_fantasia', fSigla: 'sigla',
  fInscEstadual: 'inscricao_estadual', fInscMunicipal: 'inscricao_municipal', fCep: 'cep', fEndereco: 'endereco',
  fBairro: 'bairro', fCidade: 'cidade', fUf: 'uf', fTelefone: 'telefone', fEmail: 'email', fSite: 'site', fObservacoes: 'observacoes',
};

function atualizarSugestoesDeTipo() {
  const vistos = new Set(tiposExistentes.map(normalizar));
  const todos = [...tiposExistentes, ...TIPOS_PADRAO.filter((t) => !vistos.has(normalizar(t)))];
  $('listaTipos').innerHTML = todos.map((t) => `<option value="${escaparHtml(t)}"></option>`).join('');
}

function preencher(f) {
  Object.entries(CAMPOS).forEach(([id, chave]) => { $(id).value = f ? (f[chave] || '') : ''; });
  $('idFornecedor').value = f ? f.id_fornecedor : '';
  $('fSituacao').value = f ? f.situacao || 'A' : 'A';
  limparErroDoc();
}

function configurarAbas(edicao) {
  document.querySelectorAll('#abas [data-so-edicao]').forEach((a) => exibir(a, edicao));
  $('blocoSituacao').style.display = edicao ? 'block' : 'none';
  $('contatoForm').innerHTML = '';
}

$('btnNovo').addEventListener('click', () => {
  idAtual = null;
  atualizarSugestoesDeTipo();
  preencher(null);
  configurarAbas(false);
  painelLateral.dataset.novo = '1';
  mostrarAba('dados');
  abrirPainel('Novo fornecedor');
});

async function abrirEdicao(id) {
  try {
    const f = await Api.get('/fornecedores/' + id);
    idAtual = f.id_fornecedor;
    atualizarSugestoesDeTipo();
    preencher(f);
    configurarAbas(true);
    painelLateral.dataset.novo = '0';
    mostrarAba('dados');
    abrirPainel(`${f.nome} · cód. ${f.id_fornecedor}`);
  } catch (e) { mostrarToast(e.message); }
}

// ---------------------------------------------------------------- mascaras e validacao
function mostrarErroDoc(msg) { $('erroCnpjCpf').textContent = msg; $('erroCnpjCpf').style.display = 'block'; $('fCnpjCpf').classList.add('campo-invalido'); }
function limparErroDoc() { $('erroCnpjCpf').textContent = ''; $('erroCnpjCpf').style.display = 'none'; $('fCnpjCpf').classList.remove('campo-invalido'); }

$('fCnpjCpf').addEventListener('input', (ev) => { ev.target.value = formatarCpfCnpj(ev.target.value); limparErroDoc(); });
$('fCnpjCpf').addEventListener('blur', () => {
  const d = somenteDigitos($('fCnpjCpf').value);
  if (!d) return limparErroDoc();
  if (d.length !== 11 && d.length !== 14) return mostrarErroDoc('CPF precisa ter 11 dígitos, CNPJ precisa ter 14.');
  if (!validarCpfCnpj($('fCnpjCpf').value)) return mostrarErroDoc(d.length === 11 ? 'CPF inválido.' : 'CNPJ inválido.');
  limparErroDoc();
});
$('fCep').addEventListener('input', (ev) => { ev.target.value = formatarCep(ev.target.value); });
$('fTelefone').addEventListener('input', (ev) => { ev.target.value = formatarTelefone(ev.target.value); });
$('fUf').addEventListener('input', (ev) => { ev.target.value = ev.target.value.replace(/[^a-zA-Z]/g, '').toUpperCase(); });

function coletar() {
  const d = {};
  Object.entries(CAMPOS).forEach(([id, chave]) => { d[chave] = $(id).value.trim(); });
  d.uf = d.uf.toUpperCase();
  d.sigla = d.sigla.toUpperCase();
  if (idAtual) d.situacao = $('fSituacao').value || 'A';
  return d;
}

$('btnSalvar').addEventListener('click', async () => {
  if (!$('formFornecedor').reportValidity()) return;
  const digitos = somenteDigitos($('fCnpjCpf').value);
  if (digitos && !validarCpfCnpj($('fCnpjCpf').value)) {
    mostrarErroDoc(digitos.length === 11 ? 'CPF inválido.' : digitos.length === 14 ? 'CNPJ inválido.' : 'CPF precisa ter 11 dígitos, CNPJ precisa ter 14.');
    $('fCnpjCpf').focus();
    return;
  }
  const botao = $('btnSalvar');
  botao.disabled = true;
  botao.textContent = 'Salvando...';
  try {
    const payload = coletar();
    if (idAtual) await Api.put('/fornecedores/' + idAtual, payload);
    else await Api.post('/fornecedores', payload);
    mostrarToast(idAtual ? 'Fornecedor atualizado.' : 'Fornecedor cadastrado. Para adicionar contatos, abra-o pela lista.');
    fecharPainel();
    carregar();
  } catch (e) {
    if (e.status === 409 || /CNPJ|CPF/i.test(e.message)) { mostrarErroDoc(e.message); $('fCnpjCpf').focus(); }
    mostrarToast(e.message);
  } finally { botao.disabled = false; botao.textContent = 'Salvar fornecedor'; }
});

$('btnInativar').addEventListener('click', async () => {
  if (!idAtual || !confirm('Inativar este fornecedor? O histórico de compras é mantido e você pode reativá-lo depois.')) return;
  try {
    await Api.del('/fornecedores/' + idAtual);
    mostrarToast('Fornecedor inativado.');
    fecharPainel();
    carregar();
  } catch (e) { mostrarToast(e.message); }
});

// ---------------------------------------------------------------- contatos
let contatos = [];
let contatoEditando = null;

async function carregarContatos() {
  if (!idAtual) return;
  try {
    const r = await Api.get(`/fornecedores/${idAtual}/contatos`);
    contatos = r.dados || [];
    renderContatos();
  } catch (e) { mostrarToast(e.message); }
}

function renderContatos() {
  $('contatosContagem').textContent = contatos.length ? `${contatos.length} ${contatos.length === 1 ? 'contato' : 'contatos'}` : '';
  if (!contatos.length) {
    $('contatosLista').innerHTML = '<p class="vazio-aba">Nenhum contato cadastrado. Use “+ Novo contato” para guardar quem atende, com telefone e e-mail.</p>';
    return;
  }
  $('contatosLista').innerHTML = `
    <div class="hist-lista"><table class="tabela-mini">
      <thead><tr><th>Nome</th><th>Cargo</th><th>Telefone</th><th>E-mail</th></tr></thead>
      <tbody>${contatos.map((c) => `
        <tr data-id="${c.id_contato}" class="${contatoEditando === c.id_contato ? 'editando' : ''}">
          <td><strong>${escaparHtml(c.nome)}</strong></td><td>${escaparHtml(c.cargo) || '—'}</td>
          <td>${linkTel(c.telefone) || '—'}</td><td>${linkEmail(c.email) || '—'}</td>
        </tr>`).join('')}</tbody>
    </table></div>`;
}
$('contatosLista').addEventListener('click', (ev) => {
  if (ev.target.closest('[data-sem-abrir]')) return;
  const tr = ev.target.closest('tr[data-id]');
  if (tr) abrirFormContato(contatos.find((c) => c.id_contato === Number(tr.dataset.id)));
});
$('btnNovoContato').addEventListener('click', () => abrirFormContato(null));

function abrirFormContato(c) {
  contatoEditando = c ? c.id_contato : null;
  renderContatos();
  $('contatoForm').innerHTML = `
    <div class="caixa-form-hist" data-perm-form="sub" style="margin-bottom:14px;">
      <div class="hist-form-titulo">${c ? 'Editar contato' : 'Novo contato'}</div>
      <div class="grade-2">
        <div class="campo"><label>Nome *</label><input id="cNome" value="${escaparHtml(c ? c.nome : '')}"></div>
        <div class="campo"><label>Cargo / setor</label><input id="cCargo" value="${escaparHtml(c ? c.cargo : '')}"></div>
        <div class="campo"><label>Telefone</label><input id="cTelefone" inputmode="tel" value="${escaparHtml(c ? c.telefone : '')}"></div>
        <div class="campo"><label>E-mail</label><input id="cEmail" type="email" value="${escaparHtml(c ? c.email : '')}"></div>
      </div>
      <div class="hist-form-acoes">
        <button class="btn btn-primario" id="cSalvar" type="button" data-perm="salvar-sub">Salvar contato</button>
        <button class="btn btn-secundario" id="cCancelar" type="button">Cancelar</button>
        ${c ? '<button class="btn btn-perigo" id="cExcluir" type="button" data-perm="excluir" style="margin-left:auto;">Excluir</button>' : ''}
      </div>
    </div>`;
  $('cTelefone').addEventListener('input', (ev) => { ev.target.value = formatarTelefone(ev.target.value); });
  $('cCancelar').addEventListener('click', fecharFormContato);
  $('cSalvar').addEventListener('click', salvarContato);
  if ($('cExcluir')) $('cExcluir').addEventListener('click', excluirContato);
  $('cNome').focus();
}
function fecharFormContato() { contatoEditando = null; $('contatoForm').innerHTML = ''; renderContatos(); }

async function salvarContato() {
  const payload = { nome: $('cNome').value.trim(), cargo: $('cCargo').value.trim(), telefone: $('cTelefone').value.trim(), email: $('cEmail').value.trim() };
  if (!payload.nome) { mostrarToast('Informe o nome do contato.'); $('cNome').focus(); return; }
  try {
    if (contatoEditando) await Api.put(`/fornecedores/${idAtual}/contatos/${contatoEditando}`, payload);
    else await Api.post(`/fornecedores/${idAtual}/contatos`, payload);
    mostrarToast(contatoEditando ? 'Contato atualizado.' : 'Contato adicionado.');
    fecharFormContato();
    carregarContatos();
    carregar();
  } catch (e) { mostrarToast(e.message); }
}
async function excluirContato() {
  if (!contatoEditando || !confirm('Excluir este contato?')) return;
  try {
    await Api.del(`/fornecedores/${idAtual}/contatos/${contatoEditando}`);
    mostrarToast('Contato excluído.');
    fecharFormContato();
    carregarContatos();
    carregar();
  } catch (e) { mostrarToast(e.message); }
}

// ---------------------------------------------------------------- compras (entradas de estoque)
async function carregarCompras() {
  if (!idAtual) return;
  const alvo = $('comprasConteudo');
  alvo.innerHTML = '<p class="vazio-aba">Carregando...</p>';
  try {
    const r = await Api.get(`/fornecedores/${idAtual}/compras`);
    const res = r.resumo || {};
    const itens = r.itens || [];
    alvo.innerHTML = `
      <div class="resumo-compras">
        <div class="cartao"><div class="rotulo">Entradas</div><div class="valor">${res.entradas || 0}</div></div>
        <div class="cartao"><div class="rotulo">Total comprado</div><div class="valor">${fmtMoeda(res.total)}</div></div>
        <div class="cartao"><div class="rotulo">Última compra</div><div class="valor">${res.ultima ? fmtDataBR(res.ultima) : '—'}</div></div>
      </div>
      <h3 class="secao-titulo">Itens de estoque que ele fornece</h3>
      ${itens.length
        ? `<div class="chips-itens">${itens.map((i) => `<a class="chip-item" href="estoque.html?item=${i.id_item}">${escaparHtml(i.descricao)}</a>`).join('')}</div>`
        : '<p class="vazio-aba">Nenhum item aponta este fornecedor como preferencial (campo “Fornecedor” no cadastro do item).</p>'}
      <h3 class="secao-titulo">Entradas de estoque</h3>
      ${(r.dados || []).length
        ? `<div class="hist-lista"><table class="tabela-mini"><thead><tr><th>Data</th><th>Item</th><th class="num">Qtde</th><th class="num">Vl. unit.</th><th class="num">Total</th><th>Documento</th></tr></thead><tbody>
          ${r.dados.map((m) => `<tr><td>${fmtDataBR(m.data)}</td><td>${escaparHtml(m.descricao)}</td>
            <td class="num">${fmtQtd(m.quantidade)} ${escaparHtml(m.unidade)}</td>
            <td class="num">${m.valor_unitario == null ? '—' : fmtMoeda(m.valor_unitario)}</td>
            <td class="num">${m.valor_total == null ? '—' : fmtMoeda(m.valor_total)}</td>
            <td>${escaparHtml(m.documento) || '—'}</td></tr>`).join('')}
          </tbody></table></div>`
        : '<p class="vazio-aba">Nenhuma entrada de estoque registrada com este fornecedor.</p>'}`;
  } catch (e) {
    alvo.innerHTML = `<p class="vazio-aba">${escaparHtml(e.status === 403 ? 'Seu perfil não tem acesso ao Estoque, necessário para ver as compras.' : e.message)}</p>`;
  }
}

carregar();
