const R = RelatorioBase;
document.getElementById('geradoEm').textContent = 'Gerado em ' + R.fmtGeradoEm();
document.getElementById('rodapeGerado').textContent = R.fmtGeradoEm();

const seletor = document.getElementById('seletorMes');
const params = new URLSearchParams(window.location.search);
seletor.value = params.get('mes') || (new Date().getMonth() + 1);

async function carregar() {
  exigirLogin();
  const r = await Api.get('/funcionarios/relatorios/aniversariantes?mes=' + seletor.value);
  document.getElementById('vazio').style.display = r.dados.length ? 'none' : 'block';
  document.getElementById('corpo').innerHTML = r.dados.map((p) => `
    <tr><td>${p.dia}</td><td>${R.escaparHtml(p.nome)}</td><td>${R.escaparHtml(p.telefone_celular) || '—'}</td></tr>
  `).join('');

  const url = new URL(window.location);
  url.searchParams.set('mes', seletor.value);
  window.history.replaceState({}, '', url);
}

seletor.addEventListener('change', carregar);
carregar();
