(async () => {
  const R = RelatorioBase;
  document.getElementById('geradoEm').textContent = 'Gerado em ' + R.fmtGeradoEm();
  document.getElementById('rodapeGerado').textContent = R.fmtGeradoEm();

  const f = await R.carregarFatura();
  R.preencherFicha(f);
  document.getElementById('fichaFatura').textContent = '#' + f.id_fatura + (f.duplicata ? ' · Dupl. ' + f.duplicata : '');
  document.getElementById('fichaSaida').textContent = R.fmtDataBR(f.data_saida) + (f.hora_saida ? ' às ' + f.hora_saida : '');
  document.getElementById('fichaVolta').textContent = f.data_volta ? R.fmtDataBR(f.data_volta) + (f.hora_volta ? ' às ' + f.hora_volta : '') : '—';
  document.getElementById('fichaVeiculo').textContent = f.veiculo_numero ? `Nº ${f.veiculo_numero} · ${f.veiculo_placa}` : '—';
  document.getElementById('fichaMotoristas').textContent = [f.motorista1_nome, f.motorista2_nome].filter(Boolean).join(' e ') || '—';

  const g = await R.carregarGastos();
  const num = (v) => v == null || v === '' ? '—' : v;
  document.getElementById('gKmIni').textContent = num(g.km_inicial);
  document.getElementById('gKmFim').textContent = num(g.km_final);
  document.getElementById('gComb1').textContent = `${num(g.combustivel_litros_inicial)} L / ${R.fmtMoeda(g.combustivel_valor_inicial)}`;
  document.getElementById('gComb2').textContent = `${num(g.combustivel_litros_final)} L / ${R.fmtMoeda(g.combustivel_valor_final)}`;
  document.getElementById('gPedagio').textContent = R.fmtMoeda(g.pedagio);
  document.getElementById('gHotel').textContent = R.fmtMoeda(g.hotel);
  document.getElementById('gRefeicao').textContent = R.fmtMoeda(g.refeicao);
  document.getElementById('gOutras').textContent = R.fmtMoeda(g.outras_despesas);
  document.getElementById('gTotal').textContent = R.fmtMoeda(g.total);
  document.getElementById('gAdianta').textContent = R.fmtMoeda(g.adiantamento);
  document.getElementById('gSaldo').textContent = R.fmtMoeda(g.saldo);
})();
