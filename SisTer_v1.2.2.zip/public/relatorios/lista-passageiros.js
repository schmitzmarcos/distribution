(async () => {
  const R = RelatorioBase;
  document.getElementById('geradoEm').textContent = 'Gerado em ' + R.fmtGeradoEm();
  document.getElementById('rodapeGerado').textContent = R.fmtGeradoEm();

  const f = await R.carregarFatura();
  R.preencherFicha(f);
  document.getElementById('fichaFatura').textContent = '#' + f.id_fatura + (f.duplicata ? ' · Dupl. ' + f.duplicata : '');
  document.getElementById('fichaSituacao').textContent = f.status === 'P' ? 'Pendente' : 'Confirmada';
  document.getElementById('fichaSaida').textContent = R.fmtDataBR(f.data_saida) + (f.hora_saida ? ' às ' + f.hora_saida : '');
  document.getElementById('fichaVolta').textContent = f.data_volta ? R.fmtDataBR(f.data_volta) + (f.hora_volta ? ' às ' + f.hora_volta : '') : '—';
  document.getElementById('fichaVeiculo').textContent = f.veiculo_numero ? `Nº ${f.veiculo_numero} · ${f.veiculo_placa}` : '—';
  document.getElementById('fichaMotoristas').textContent = [f.motorista1_nome, f.motorista2_nome].filter(Boolean).join(' e ') || '—';

  const pax = await R.carregarPassageiros();
  document.getElementById('vazio').style.display = pax.length ? 'none' : 'block';
  document.getElementById('corpoLista').innerHTML = pax.map((p) => `
    <tr>
      <td>${p.numero_poltrona ?? '—'}</td>
      <td>${R.escaparHtml(p.nome)}</td>
      <td>${R.escaparHtml(p.identidade || p.cpf) || '—'}</td>
      <td>${R.fmtDataBR(p.data_nascimento)}</td>
      <td>${R.escaparHtml(p.local_embarque) || '—'}</td>
    </tr>`).join('');
  document.getElementById('totalPax').textContent = pax.length + (pax.length === 1 ? ' passageiro' : ' passageiros');
})();
