const R = RelatorioBase;
document.getElementById('geradoEm').textContent = 'Gerado em ' + R.fmtGeradoEm();
document.getElementById('rodapeGerado').textContent = R.fmtGeradoEm();

const qtd = (n) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: 3 });

async function carregar() {
  exigirLogin();
  const r = await Api.get('/estoque?filtro=repor&itens_por_pagina=1000');
  document.getElementById('vazio').style.display = r.dados.length ? 'none' : 'block';

  const grupos = new Map();
  r.dados.forEach((i) => {
    const chave = i.fornecedor_nome || 'Sem fornecedor definido';
    if (!grupos.has(chave)) grupos.set(chave, []);
    grupos.get(chave).push(i);
  });
  const nomes = [...grupos.keys()].sort((a, b) => (a.startsWith('Sem ') ? 1 : b.startsWith('Sem ') ? -1 : a.localeCompare(b, 'pt-BR')));

  document.getElementById('conteudo').innerHTML = nomes.map((nome) => `
    <div class="grupo">${R.escaparHtml(nome)} <small>· ${grupos.get(nome).length} ${grupos.get(nome).length === 1 ? 'item' : 'itens'}</small></div>
    <table class="rel">
      <thead><tr><th style="width:60px;">Cód.</th><th>Item</th><th class="n">Saldo</th><th class="n">Mínimo</th><th class="n">Falta</th></tr></thead>
      <tbody>${grupos.get(nome).map((i) => {
        const falta = Math.max(0, Number(i.estoque_minimo) - Number(i.saldo));
        return `<tr><td>${i.id_item}</td><td>${R.escaparHtml(i.descricao)}${i.referencia ? ` <small>(${R.escaparHtml(i.referencia)})</small>` : ''}</td>
          <td class="n">${qtd(i.saldo)} ${R.escaparHtml(i.unidade)}</td><td class="n">${qtd(i.estoque_minimo)}</td><td class="n"><strong>${qtd(falta)}</strong></td></tr>`;
      }).join('')}</tbody>
    </table>`).join('');
}
carregar();
