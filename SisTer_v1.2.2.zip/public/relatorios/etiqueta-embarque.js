(async () => {
  const R = RelatorioBase;
  document.getElementById('geradoEm').textContent = 'Gerado em ' + R.fmtGeradoEm();

  const f = await R.carregarFatura();
  const rota = [f.origem, f.destino].filter(Boolean).join(' → ') || 'Roteiro não informado';
  const dataSaida = R.fmtDataBR(f.data_saida);

  const pax = await R.carregarPassageiros();
  document.getElementById('vazio').style.display = pax.length ? 'none' : 'block';
  document.getElementById('grade').innerHTML = pax.map((p) => `
    <div class="etiqueta">
      <div>
        <div class="cliente">${R.escaparHtml(f.cliente_nome)}</div>
        <div class="rota-et">${R.escaparHtml(rota)}</div>
      </div>
      <div>
        <div class="pax">${R.escaparHtml(p.nome)}</div>
        <div class="poltrona">${p.numero_poltrona != null ? 'Poltrona ' + p.numero_poltrona : ''}</div>
      </div>
      <div class="data-et">Saída: ${dataSaida}${f.hora_saida ? ' · ' + f.hora_saida : ''} · Fatura #${f.id_fatura}</div>
    </div>`).join('');
})();
