-- =========================================================================
-- Migracao 004 - Arla (litros) no abastecimento
--
-- O Arla (reagente que reduz as emissoes dos motores diesel) e abastecido junto com o combustivel
-- e medido em litros. Coluna nova e opcional nas duas tabelas do abastecimento:
--   frota_ocorrencias   lancamento feito pelo celular (tela de lancamentos)
--   veiculo_medias      historico de abastecimento do cadastro do veiculo (Frota)
-- Registros antigos ficam com a coluna vazia (NULL) = nao informado.
-- =========================================================================

ALTER TABLE frota_ocorrencias ADD COLUMN litros_arla REAL;

ALTER TABLE veiculo_medias ADD COLUMN litros_arla REAL;
