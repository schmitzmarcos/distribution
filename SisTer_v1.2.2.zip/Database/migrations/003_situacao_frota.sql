-- =========================================================================
-- Migracao 003 - Situacao da frota e lancamentos de campo (celular)
--
-- Livro de ocorrencias da frota: cada linha e um fato lancado por quem esta no patio
-- (limpeza concluida, abastecimento, veiculo parado para manutencao, veiculo liberado).
-- A situacao do veiculo (pronto, em viagem, com pendencia, em manutencao) NAO e gravada:
-- e calculada a partir deste livro e da Agenda de viagens (faturas), igual ao saldo do Estoque.
--
-- Lancamento errado nunca e apagado: fica cancelado (cancelado = 1) com quem cancelou e o motivo.
--
-- Modulos de permissao novos (Administracao > Perfis):
--   situacao_frota     Ver: painel da frota e lista de lancamentos · Excluir: cancelar lancamento de outra pessoa
--   lanc_limpeza       Incluir: lancar limpeza pelo celular · Excluir: desfazer lancamento de outra pessoa
--   lanc_abastecimento Incluir: lancar abastecimento pelo celular · Excluir: idem
--   lanc_manutencao    Incluir: parar/liberar veiculo para manutencao pelo celular · Excluir: idem
--
-- Perfis de partida (editaveis): Limpeza e Garagem. INSERT OR IGNORE: nunca sobrescreve o que ja existe.
-- =========================================================================

CREATE TABLE frota_ocorrencias (
    id_ocorrencia   INTEGER PRIMARY KEY AUTOINCREMENT,
    id_veiculo      INTEGER NOT NULL REFERENCES frota(id_veiculo) ON DELETE CASCADE,
    tipo            TEXT NOT NULL CHECK (tipo IN ('limpeza', 'abastecimento', 'manutencao_entrada', 'manutencao_saida')),
    data_hora       TEXT NOT NULL DEFAULT (datetime('now','localtime')),   -- quando aconteceu (AAAA-MM-DD HH:MM:SS)
    subtipo         TEXT,       -- limpeza: completa, interna ou externa. manutencao_entrada: categoria do problema
    km              REAL,       -- odometro informado
    litros          REAL,       -- abastecimento
    valor           REAL,       -- abastecimento (total pago) ou manutencao_saida (custo do servico)
    local           TEXT,       -- abastecimento: posto
    previsao_retorno TEXT,      -- manutencao_entrada: data prevista para liberar (AAAA-MM-DD)
    descricao       TEXT,       -- observacao / motivo / o que foi feito
    id_usuario      INTEGER REFERENCES usuarios(id_usuario) ON DELETE SET NULL,
    usuario_nome    TEXT,       -- nome de quem lancou, como estava na hora
    chave           TEXT UNIQUE, -- gerada pelo celular: reenviar o mesmo lancamento nao duplica
    id_media        INTEGER,    -- abastecimento: linha criada em veiculo_medias (historico do veiculo)
    id_manutencao   INTEGER,    -- manutencao_saida: linha criada em veiculo_manutencoes (historico do veiculo)
    registrado_em   TEXT NOT NULL DEFAULT (datetime('now','localtime')),  -- quando o servidor recebeu
    cancelado       INTEGER NOT NULL DEFAULT 0,
    cancelado_em    TEXT,
    cancelado_por   TEXT,
    motivo_cancelamento TEXT
);

CREATE INDEX idx_ocorr_veiculo ON frota_ocorrencias(id_veiculo, tipo, id_ocorrencia);
CREATE INDEX idx_ocorr_data    ON frota_ocorrencias(data_hora);
CREATE INDEX idx_ocorr_usuario ON frota_ocorrencias(id_usuario, data_hora);

-- Perfis de partida

INSERT OR IGNORE INTO perfis (nome, descricao, sistema) VALUES ('Limpeza', 'Lanca a limpeza concluida pelo celular', 0);
INSERT OR IGNORE INTO perfis (nome, descricao, sistema) VALUES ('Garagem', 'Lanca abastecimento e manutencao pelo celular', 0);

-- Administrador: tudo

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'situacao_frota', 1, 1, 1, 1 FROM perfis WHERE sistema = 1;

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'lanc_limpeza', 1, 1, 1, 1 FROM perfis WHERE sistema = 1;

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'lanc_abastecimento', 1, 1, 1, 1 FROM perfis WHERE sistema = 1;

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'lanc_manutencao', 1, 1, 1, 1 FROM perfis WHERE sistema = 1;

-- Operacional: ve o painel, cancela lancamentos e tambem pode lancar

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'situacao_frota', 1, 0, 0, 1 FROM perfis WHERE nome = 'Operacional';

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'lanc_limpeza', 1, 1, 0, 1 FROM perfis WHERE nome = 'Operacional';

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'lanc_abastecimento', 1, 1, 0, 1 FROM perfis WHERE nome = 'Operacional';

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'lanc_manutencao', 1, 1, 0, 1 FROM perfis WHERE nome = 'Operacional';

-- Financeiro: so consulta o painel

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'situacao_frota', 1, 0, 0, 0 FROM perfis WHERE nome = 'Financeiro';

-- Limpeza: so lanca limpeza

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'lanc_limpeza', 1, 1, 0, 0 FROM perfis WHERE nome = 'Limpeza';

-- Garagem: lanca abastecimento e manutencao

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'lanc_abastecimento', 1, 1, 0, 0 FROM perfis WHERE nome = 'Garagem';

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'lanc_manutencao', 1, 1, 0, 0 FROM perfis WHERE nome = 'Garagem';
