-- =========================================================================
-- Migracao 001 - Schema completo do SisTer (baseline)
--
-- Esta e a UNICA migracao do schema ate aqui: consolida o resultado das antigas
-- 001 a 015 (auth/clientes, funcionarios, frota, faturas, financeiro, passageiros e
-- gastos, correcoes, permissoes, limpeza de clientes, sessoes, salarios, auditoria,
-- fornecedores/estoque e equipamentos da frota).
--
-- Por que consolidar: o schema final e criado direto, sem DROP COLUMN/RENAME COLUMN
-- (que exigem SQLite 3.35). O banco novo ja nasce certo e o SQLite embutido no
-- FireDAC (3.31) consegue cria-lo.
--
-- Bancos criados com o historico antigo (001..015 separadas) NAO sao compativeis:
-- recrie o banco (o servidor avisa na partida). Novas alteracoes entram em
-- 002_*.sql, 003_*.sql ... e nunca se edita uma migracao ja aplicada.
--
-- Cada comando termina com ";" no fim da linha (o executor separa assim). Nao use
-- ";" no fim de linha dentro de comentarios ou textos.
-- =========================================================================

PRAGMA foreign_keys = ON;

-- -------------------------------------------------------------------------
-- Tabelas e indices
-- -------------------------------------------------------------------------

CREATE TABLE perfis (
    id_perfil       INTEGER PRIMARY KEY AUTOINCREMENT,
    nome            TEXT NOT NULL UNIQUE,      -- Ex: 'Administrador', 'Financeiro', 'Operacional'
    descricao       TEXT,
    criado_em       TEXT NOT NULL DEFAULT (datetime('now'))
    , sistema INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE usuarios (
    id_usuario      INTEGER PRIMARY KEY AUTOINCREMENT,
    login           TEXT NOT NULL UNIQUE,
    senha_hash      TEXT NOT NULL,             -- hash (SHA-256 + salt); ver Common/PasswordHelper.pas
    senha_salt      TEXT NOT NULL,
    nome            TEXT NOT NULL,
    email           TEXT,
    id_perfil       INTEGER NOT NULL REFERENCES perfis(id_perfil),
    ativo           INTEGER NOT NULL DEFAULT 1,
    precisa_trocar_senha INTEGER NOT NULL DEFAULT 0,
    ultimo_login    TEXT,
    criado_em       TEXT NOT NULL DEFAULT (datetime('now'))
    , token_versao INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE permissoes (
    id_permissao    INTEGER PRIMARY KEY AUTOINCREMENT,
    id_perfil       INTEGER NOT NULL REFERENCES perfis(id_perfil) ON DELETE CASCADE,
    modulo          TEXT NOT NULL,             -- Ex: 'clientes', 'funcionarios', 'frota'
    pode_ver        INTEGER NOT NULL DEFAULT 0,
    pode_incluir    INTEGER NOT NULL DEFAULT 0,
    pode_editar     INTEGER NOT NULL DEFAULT 0,
    pode_excluir    INTEGER NOT NULL DEFAULT 0,
    UNIQUE(id_perfil, modulo)
);

CREATE TABLE clientes (
    id_cliente          INTEGER PRIMARY KEY AUTOINCREMENT,   -- era clicod (autoinc)
    nome                TEXT NOT NULL,                        -- clinome
    nome_fantasia       TEXT,                                 -- clinomefantasia
    tipo_cliente        TEXT,                                 -- clitipcliente (PF/PJ)
    situacao            TEXT NOT NULL DEFAULT 'A',             -- clisit (A=Ativo / I=Inativo)
    cnpj_cpf            TEXT,                                  -- clicnpj
    inscricao_estadual  TEXT,                                  -- cliinscr
    orgao_rg            TEXT,                                  -- cliorgaoRG
    endereco            TEXT,                                  -- cliender
    bairro              TEXT,                                  -- clibairro
    cidade              TEXT,                                  -- clicidade
    uf                  TEXT,                                  -- cliuf
    cep                 TEXT,                                  -- clicep
    telefone            TEXT,                                  -- clifone
    fax                 TEXT,                                  -- clifax
    celular             TEXT,                                  -- clicelular
    email               TEXT,                                  -- cliemail
    website             TEXT,                                  -- cliweb
    data_nascimento     TEXT,                                  -- cliDtNasc
    data_fundacao       TEXT,                                  -- clifundacao
    data_cadastro       TEXT NOT NULL DEFAULT (date('now')),    -- clidtcadastro
    ramo_atividade      TEXT,                                  -- cliramo
    observacoes         TEXT,                                  -- cliobs
    empresa             TEXT NOT NULL DEFAULT 'Viaggiotur',    -- Empresa
    atualizado_em       TEXT
);

CREATE INDEX idx_clientes_nome   ON clientes(nome);
CREATE INDEX idx_clientes_sit    ON clientes(situacao);
CREATE UNIQUE INDEX idx_clientes_cnpj_unico ON clientes(cnpj_cpf) WHERE cnpj_cpf <> '';

CREATE TABLE funcionarios (
    id_funcionario      INTEGER PRIMARY KEY AUTOINCREMENT,
    cpf                 TEXT NOT NULL UNIQUE,                 -- funcpf (era a PK original)
    nome                TEXT NOT NULL,                         -- funnome
    situacao            TEXT NOT NULL DEFAULT 'A',              -- funsit (A=Ativo / I=Inativo)
    tipo                TEXT,                                    -- funtip (ex: Motorista, Administrativo)
    apelido             TEXT,                                     -- funnick
    numero_registro     INTEGER,                                  -- funnroreg
    rg                  TEXT,                                      -- funrg
    data_expedicao_rg   TEXT,                                       -- fundtexprg
    data_nascimento     TEXT,                                        -- fundtnasc
    data_admissao       TEXT,                                         -- fundtadm
    data_rescisao       TEXT,                                          -- fundtrecisao
    estado_civil        TEXT,                                          -- funestadocivil
    grau_escolaridade   TEXT,                                          -- fungrauescola
    endereco            TEXT,                                          -- funendereco
    cep                 TEXT,                                          -- funcep
    cidade              TEXT,                                          -- funcidade
    uf                  TEXT,                                          -- funuf
    telefone_residencial TEXT,                                         -- funfoneres
    telefone_celular    TEXT,                                          -- funfonecel
    nome_conjuge        TEXT,                                          -- funconjuge
    nome_mae            TEXT,                                          -- funmae
    nome_pai            TEXT,                                          -- funpai
    qtd_filhos          INTEGER,                                       -- funqtdfilhos
    contato_emergencia_nome     TEXT,                                  -- funcontato
    contato_emergencia_telefone TEXT,                                  -- funcontatofone
    contato_emergencia_endereco TEXT,                                  -- funcontatoender
    numero_cnh          TEXT,                                          -- funcarthabilita
    data_vencimento_cnh TEXT,                                          -- fundtvenccnh
    data_vencimento_exame_saude TEXT,                                  -- fundtvencsaude
    celular_plano       TEXT,                                          -- funplanocel
    celular_modelo      TEXT,                                          -- funcelmodelo
    celular_data_entrega    TEXT,                                      -- funceldtentrega
    celular_data_devolucao  TEXT,                                      -- funceldtdevolucao
    observacoes         TEXT,                                          -- funobs
    empresa             TEXT NOT NULL DEFAULT 'Viaggiotur',
    criado_em           TEXT NOT NULL DEFAULT (datetime('now')),
    atualizado_em       TEXT
    , foto TEXT
    , email TEXT
    , salario REAL
    , numero_mei TEXT
    , numero_chip TEXT
    , data_vencimento_cnh_internacional TEXT
    , data_vencimento_senac TEXT
);

CREATE INDEX idx_funcionarios_nome ON funcionarios(nome);
CREATE INDEX idx_funcionarios_cpf  ON funcionarios(cpf);
CREATE INDEX idx_funcionarios_sit  ON funcionarios(situacao);

CREATE TABLE funcionario_bonificacoes (
    id_bonificacao   INTEGER PRIMARY KEY AUTOINCREMENT,
    id_funcionario   INTEGER NOT NULL REFERENCES funcionarios(id_funcionario) ON DELETE CASCADE,
    data             TEXT,
    descricao        TEXT,
    codigo_orcamento INTEGER,  -- referência solta ao módulo de Orçamento (ainda não migrado)
    valor            REAL
);

CREATE TABLE funcionario_horas (
    id_registro      INTEGER PRIMARY KEY AUTOINCREMENT,
    id_funcionario   INTEGER NOT NULL REFERENCES funcionarios(id_funcionario) ON DELETE CASCADE,
    placa_veiculo    TEXT,      -- referência solta à Frota (ainda não migrada nesta fase)
    data_saida       TEXT,
    hora_saida       TEXT,
    km_inicial       INTEGER,
    data_volta       TEXT,
    hora_volta       TEXT,
    km_final         INTEGER,
    observacoes      TEXT
);

CREATE TABLE frota (
    id_veiculo          INTEGER PRIMARY KEY AUTOINCREMENT,
    numero              INTEGER NOT NULL UNIQUE,     -- fronro (numero do veiculo na frota)
    placa               TEXT NOT NULL UNIQUE,        -- froplaca
    placa_anterior      TEXT,                        -- froplacaant
    chassi              TEXT,                        -- frochassi
    marca               TEXT,                        -- fromarca
    modelo              TEXT,                        -- fromodelo
    ano_fabricacao      INTEGER,                     -- froano
    ano_modelo          INTEGER,                     -- froanomodelo
    lotacao             INTEGER,                     -- frolotacao (lugares)
    situacao            TEXT NOT NULL DEFAULT 'A',   -- frosit (A=Ativo / I=Inativo)
    nome_documento      TEXT,                        -- fronome (conforme documento)
    endereco_documento  TEXT,                        -- froender (conforme documento)
    empresa_proprietaria TEXT,                       -- froemp
    fretado             TEXT NOT NULL DEFAULT 'N',   -- frofretado (S/N)
    potencia            REAL,                        -- fropotencia
    especie             TEXT,                        -- froespecie
    combustivel         TEXT,                        -- frocombustivel
    media_litro         REAL,                        -- fromedialitro
    capacidade_tanque   REAL,                        -- frocaptanque
    categoria           TEXT,                        -- frocategoria
    valor_limpeza       REAL,                        -- frovllimpeza
    peso_eixo_dianteiro REAL,                        -- fropesoeixodi
    peso_eixo_traseiro  REAL,                        -- fropesoeixotra
    peso_total          REAL,                        -- fropesototal
    data_inicio         TEXT,                        -- frodtini
    data_fim            TEXT,                        -- frodtfim
    observacoes         TEXT,                        -- froobs
    certificado_verificacao TEXT,                    -- frocertver

    -- Vencimentos de documentos (antigos frodt...)
    venc_vistoria               TEXT,   -- frodtvistoria (laudo de vistoria)
    venc_lic_turismo            TEXT,   -- frodtlictur
    venc_lic_fretamento         TEXT,   -- frodtlicfre
    venc_inmetro_nacional       TEXT,   -- frodtinmnac
    venc_inmetro_internacional  TEXT,   -- frodtiminter
    venc_ipva                   TEXT,   -- frodtipva
    venc_consulado_argentina    TEXT,   -- frodtArg
    venc_consulado_uruguai      TEXT,   -- frodtUru
    venc_consulado_chile        TEXT,   -- frodtChi
    venc_embratur               TEXT,   -- frodtEmbratur
    venc_metroplan              TEXT,   -- frodtMetroplan
    venc_antt_nacional          TEXT,   -- frodtANTTNac
    venc_antt_internacional     TEXT,   -- frodtANTTInter
    venc_receftur               TEXT,   -- frodtRecefTur
    venc_apolice                TEXT,   -- frodtApolice
    venc_grade_daer             TEXT,   -- frodtGradeDaer
    venc_extintor               TEXT,   -- frodtextintor
    venc_tacografo              TEXT,   -- frodttacografo

    -- Equipamentos (antigas 16 posicoes do campo texto froobscarro)
    motor_posicao   TEXT,   -- Dianteiro / Traseiro
    tipo_poltrona   TEXT,   -- Leito, Leito turismo, Executiva...
    porta           TEXT,   -- Dianteira / Central / Traseira
    tipo_roda       TEXT,   -- Ferro / Aluminio
    tipo_tacografo  TEXT,   -- Analogico / Digital
    tipo_veiculo    TEXT,   -- 2 eixos / 3 eixos / 4 eixos / Micro / Van

    criado_em       TEXT NOT NULL DEFAULT (datetime('now')),
    atualizado_em   TEXT
);

CREATE INDEX idx_frota_placa ON frota(placa);
CREATE INDEX idx_frota_sit   ON frota(situacao);

CREATE TABLE veiculo_multas (
    id_multa        INTEGER PRIMARY KEY AUTOINCREMENT,
    id_veiculo      INTEGER NOT NULL REFERENCES frota(id_veiculo) ON DELETE CASCADE,
    data            TEXT,
    descricao       TEXT,
    id_funcionario  INTEGER REFERENCES funcionarios(id_funcionario) ON DELETE SET NULL,
    valor           REAL,
    pontos          INTEGER
);

CREATE TABLE veiculo_manutencoes (
    id_manutencao   INTEGER PRIMARY KEY AUTOINCREMENT,
    id_veiculo      INTEGER NOT NULL REFERENCES frota(id_veiculo) ON DELETE CASCADE,
    data            TEXT,
    descricao       TEXT,
    km              REAL,
    valor           REAL,
    quantidade      INTEGER,
    id_funcionario  INTEGER REFERENCES funcionarios(id_funcionario) ON DELETE SET NULL,
    id_estoque      INTEGER,   -- referencia solta ao modulo Estoque (ainda nao migrado)
    baixa_estoque   TEXT
);

CREATE TABLE veiculo_medias (
    id_media            INTEGER PRIMARY KEY AUTOINCREMENT,
    id_veiculo          INTEGER NOT NULL REFERENCES frota(id_veiculo) ON DELETE CASCADE,
    data                TEXT,
    km_inicial          REAL,
    km_final            REAL,
    litros              REAL,
    local_abastecimento TEXT
);

CREATE TABLE veiculo_acidentes (
    id_acidente     INTEGER PRIMARY KEY AUTOINCREMENT,
    id_veiculo      INTEGER NOT NULL REFERENCES frota(id_veiculo) ON DELETE CASCADE,
    data            TEXT,
    id_funcionario  INTEGER REFERENCES funcionarios(id_funcionario) ON DELETE SET NULL,
    descricao       TEXT
);

CREATE TABLE veiculo_preventivas (
    id_preventiva   INTEGER PRIMARY KEY AUTOINCREMENT,
    id_veiculo      INTEGER NOT NULL REFERENCES frota(id_veiculo) ON DELETE CASCADE,
    descricao       TEXT,
    km_troca        INTEGER,
    proxima_troca   INTEGER
);

CREATE TABLE faturas (
    id_fatura           INTEGER PRIMARY KEY AUTOINCREMENT,   -- fatcod

    -- Viagem
    data_saida          TEXT,                                -- fatdtsaida (AAAA-MM-DD)
    hora_saida          TEXT,                                -- fathrsaida (HH:MM)
    data_volta          TEXT,                                -- fatdtvolta
    hora_volta          TEXT,                                -- fathrvolta
    id_cliente          INTEGER NOT NULL REFERENCES clientes(id_cliente),   -- clicod
    contato             TEXT,                                -- fatcontato
    id_veiculo          INTEGER REFERENCES frota(id_veiculo) ON DELETE SET NULL,          -- fronro
    id_funcionario1     INTEGER REFERENCES funcionarios(id_funcionario) ON DELETE SET NULL, -- funcpf1
    id_funcionario2     INTEGER REFERENCES funcionarios(id_funcionario) ON DELETE SET NULL, -- funcpf2
    origem              TEXT,                                -- fatde
    uf_origem           TEXT,                                -- fatUFde
    destino             TEXT,                                -- fatpara
    uf_destino          TEXT,                                -- fatUFpara
    outras_cidades      TEXT,                                -- fatoutrascidades
    km                  REAL,                                -- fatKM
    tipo                TEXT NOT NULL DEFAULT 'D',           -- fattip (D=Diaria / M=Mensal)
    internacional       INTEGER NOT NULL DEFAULT 0,          -- fatnacional (0=Nacional / 1=Internacional)
    endereco_saida      TEXT,                                -- fatendersaida
    guia                TEXT,                                -- fatguia
    status              TEXT NOT NULL DEFAULT 'C',           -- fatstatus (C=Confirmado / P=Pendente)

    -- Financeiro
    valor_nota          REAL,                                -- fatvalornota
    valor_viagem        REAL,                                -- fatvalorviagem
    valor_terceiros     REAL,                                -- fatvalorterc
    valor_pedagio       REAL,                                -- fatvlpedagio
    forma_pagamento     INTEGER NOT NULL DEFAULT 0,          -- fatformapagto (0=Cash / 1=Boleto)
    qtde_boletos        INTEGER,                             -- fatqtdeboleto
    data_vencimento     TEXT,                                -- fatdatavenc (1o vencimento)
    imposto             TEXT,                                -- fatimposto: municipal_3, municipal_12, intermunicipal_12_sobre_20, intermunicipal_17
    retencao_previdenciaria INTEGER NOT NULL DEFAULT 0,      -- fatretencaoprev (11% sobre 30%)
    valor_liquido       REAL,                                -- fatliquido (calculado pelo back-end)
    duplicata           INTEGER,                             -- fatduplicata (automatica por ano)

    -- Opcionais (antigas 10 posicoes de fatcomida)
    opc_refrigerante    INTEGER NOT NULL DEFAULT 0,
    opc_agua_mineral    INTEGER NOT NULL DEFAULT 0,
    opc_chocolate_quente INTEGER NOT NULL DEFAULT 0,
    opc_sanduiche       INTEGER NOT NULL DEFAULT 0,
    opc_bombom          INTEGER NOT NULL DEFAULT 0,
    opc_balas           INTEGER NOT NULL DEFAULT 0,
    opc_tapete          INTEGER NOT NULL DEFAULT 0,
    opc_travesseiros    INTEGER NOT NULL DEFAULT 0,
    opc_cabeceiras      INTEGER NOT NULL DEFAULT 0,
    opc_salgados        INTEGER NOT NULL DEFAULT 0,

    observacoes         TEXT,                                -- fatobs
    criado_por          TEXT,                                -- fatuser
    data_emissao        TEXT NOT NULL DEFAULT (date('now')), -- fatdata
    atualizado_em       TEXT
);

CREATE INDEX idx_faturas_saida   ON faturas(data_saida);
CREATE INDEX idx_faturas_veiculo ON faturas(id_veiculo, data_saida);
CREATE INDEX idx_faturas_cliente ON faturas(id_cliente);

CREATE TABLE contas_caixa (
    id_conta        INTEGER PRIMARY KEY AUTOINCREMENT,   -- ccxcod
    descricao       TEXT NOT NULL,                       -- ccxdescr
    limite_mensal   REAL                                 -- ccxlimite (0 ou vazio = sem limite)
);

CREATE TABLE caixa_lancamentos (
    id_lancamento       INTEGER PRIMARY KEY AUTOINCREMENT,   -- caxcod
    numero_documento    INTEGER,                             -- caxnrodoc
    descricao           TEXT,                                -- caxdescr
    data_movimento      TEXT,                                -- caxdtmov (AAAA-MM-DD)
    data_pagamento      TEXT,                                -- caxdtpagto (vazio = ainda nao pago/recebido)
    valor               REAL NOT NULL DEFAULT 0,             -- caxvalor
    tipo                TEXT NOT NULL DEFAULT 'S',           -- caxope: E=Entrada, S=Saida, A=Aberto (previsto)
    id_conta            INTEGER NOT NULL REFERENCES contas_caixa(id_conta),   -- ccxcod
    codigo_orcamento    INTEGER,                             -- orccod (referencia solta ao Orcamento, ainda nao migrado)
    nome_pagador        TEXT,                                -- caxnomepag
    contabiliza         INTEGER NOT NULL DEFAULT 1,          -- caxnro (1 = entra no caixa, 2 = nao entra)
    comissao            REAL NOT NULL DEFAULT 0,             -- caxcomissao (regra legada, so p/ migracao de dados)
    em_dinheiro         INTEGER NOT NULL DEFAULT 0,          -- fatcash (regra legada, so p/ migracao de dados)
    operador            TEXT,                                -- usuario que lancou
    criado_em           TEXT NOT NULL DEFAULT (datetime('now')),
    atualizado_em       TEXT
);

CREATE INDEX idx_caixa_data  ON caixa_lancamentos(data_movimento);
CREATE INDEX idx_caixa_conta ON caixa_lancamentos(id_conta, data_movimento);

CREATE TABLE cheques (
    id_cheque       INTEGER PRIMARY KEY AUTOINCREMENT,   -- checod
    tipo            TEXT NOT NULL DEFAULT 'A',           -- chetipo
    data            TEXT,                                -- chedata
    vencimento      TEXT,                                -- chevcto
    numero          INTEGER,                             -- chenumero
    emitente        TEXT,                                -- chede (cheque de)
    praca           TEXT,                                -- chepraca
    banco           TEXT,                                -- chebanco
    recebido_de     TEXT,                                -- cherecde
    valor_entrada   REAL,                                -- chevlent
    valor_saida     REAL,                                -- chevlsai
    destino         TEXT,                                -- chedestino
    status          TEXT                                 -- chestatus
);

CREATE INDEX idx_cheques_tipo ON cheques(tipo, vencimento);

CREATE TABLE fatura_passageiros (
    id_passageiro   INTEGER PRIMARY KEY AUTOINCREMENT,   -- paxcod
    id_fatura       INTEGER NOT NULL REFERENCES faturas(id_fatura) ON DELETE CASCADE,
    nome            TEXT NOT NULL,                       -- paxnome
    identidade      TEXT,                                -- paxident (RG/passaporte)
    cpf             TEXT,                                -- paxcpf
    data_nascimento TEXT,                                -- paxdtnasc
    numero_poltrona INTEGER,                             -- paxnropolt
    ocupacao        TEXT,                                -- paxocupacao
    sexo            TEXT,                                -- paxsexo (M/F)
    tipo            TEXT,                                -- paxtipo (ex: Adulto/Crianca/Idoso)
    nacionalidade   TEXT,                                -- paxnacao
    pais            TEXT,                                -- paxpais
    local_embarque  TEXT,                                -- paxlocal
    valor           REAL                                 -- paxvalor
);

CREATE INDEX idx_pax_fatura ON fatura_passageiros(id_fatura);

CREATE TABLE fatura_gastos (
    id_fatura           INTEGER PRIMARY KEY REFERENCES faturas(id_fatura) ON DELETE CASCADE,
    km_inicial          REAL,     -- Gaskmini
    km_final            REAL,     -- Gaskmfim
    pedagio             REAL,     -- Gaspedagio
    hotel               REAL,     -- Gashotel
    refeicao            REAL,     -- Gasrefeicao
    combustivel_litros_inicial REAL,   -- Gaslitrosini
    combustivel_valor_inicial  REAL,   -- Gasvlini
    combustivel_litros_final   REAL,   -- Gaslitrosfim
    combustivel_valor_final    REAL,   -- Gasvlfim
    outras_despesas     REAL,     -- Gasoutras
    adiantamento        REAL,     -- gasadianta
    total               REAL,     -- Gastotal (recalculado pelo servidor - ver nota no README)
    saldo               REAL      -- Gassaldo (recalculado pelo servidor - ver nota no README)
);

CREATE TABLE auditoria (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    quando        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    usuario       TEXT,
    ip            TEXT,
    entidade      TEXT NOT NULL,
    id_registro   INTEGER,
    acao          TEXT NOT NULL,
    antes         TEXT,
    depois        TEXT
);

CREATE INDEX idx_auditoria_registro ON auditoria(entidade, id_registro);
CREATE INDEX idx_auditoria_quando   ON auditoria(quando);

CREATE TABLE fornecedores (
    id_fornecedor        INTEGER PRIMARY KEY AUTOINCREMENT,
    cnpj_cpf             TEXT NOT NULL DEFAULT '',
    tipo                 TEXT NOT NULL DEFAULT '',
    nome                 TEXT NOT NULL,
    nome_fantasia        TEXT NOT NULL DEFAULT '',
    sigla                TEXT NOT NULL DEFAULT '',
    inscricao_estadual   TEXT NOT NULL DEFAULT '',
    inscricao_municipal  TEXT NOT NULL DEFAULT '',
    cep                  TEXT NOT NULL DEFAULT '',
    endereco             TEXT NOT NULL DEFAULT '',
    bairro               TEXT NOT NULL DEFAULT '',
    cidade               TEXT NOT NULL DEFAULT '',
    uf                   TEXT NOT NULL DEFAULT '',
    telefone             TEXT NOT NULL DEFAULT '',
    email                TEXT NOT NULL DEFAULT '',
    site                 TEXT NOT NULL DEFAULT '',
    observacoes          TEXT NOT NULL DEFAULT '',
    situacao             TEXT NOT NULL DEFAULT 'A',
    criado_em            TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    atualizado_em        TEXT
);

CREATE UNIQUE INDEX idx_fornecedores_doc_unico ON fornecedores(cnpj_cpf) WHERE cnpj_cpf <> '';
CREATE INDEX idx_fornecedores_nome ON fornecedores(nome);

CREATE TABLE fornecedor_contatos (
    id_contato      INTEGER PRIMARY KEY AUTOINCREMENT,
    id_fornecedor   INTEGER NOT NULL REFERENCES fornecedores(id_fornecedor) ON DELETE CASCADE,
    nome            TEXT NOT NULL DEFAULT '',
    cargo           TEXT NOT NULL DEFAULT '',
    telefone        TEXT NOT NULL DEFAULT '',
    email           TEXT NOT NULL DEFAULT ''
);

CREATE INDEX idx_fornecedor_contatos ON fornecedor_contatos(id_fornecedor);

CREATE TABLE estoque_itens (
    id_item         INTEGER PRIMARY KEY AUTOINCREMENT,
    descricao       TEXT NOT NULL,
    referencia      TEXT NOT NULL DEFAULT '',
    unidade         TEXT NOT NULL DEFAULT 'UN',
    categoria       TEXT NOT NULL DEFAULT '',
    localizacao     TEXT NOT NULL DEFAULT '',
    estoque_minimo  REAL NOT NULL DEFAULT 0,
    id_fornecedor   INTEGER REFERENCES fornecedores(id_fornecedor) ON DELETE SET NULL,
    observacoes     TEXT NOT NULL DEFAULT '',
    situacao        TEXT NOT NULL DEFAULT 'A',
    criado_em       TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    atualizado_em   TEXT
);

CREATE INDEX idx_estoque_itens_desc ON estoque_itens(descricao);

CREATE TABLE estoque_movimentos (
    id_movimento    INTEGER PRIMARY KEY AUTOINCREMENT,
    id_item         INTEGER NOT NULL REFERENCES estoque_itens(id_item) ON DELETE CASCADE,
    tipo            TEXT NOT NULL CHECK (tipo IN ('E', 'S', 'A')),
    data            TEXT NOT NULL,
    quantidade      REAL NOT NULL,
    valor_unitario  REAL,
    id_fornecedor   INTEGER REFERENCES fornecedores(id_fornecedor) ON DELETE SET NULL,
    id_veiculo      INTEGER REFERENCES frota(id_veiculo) ON DELETE SET NULL,
    documento       TEXT NOT NULL DEFAULT '',
    observacao      TEXT NOT NULL DEFAULT '',
    usuario         TEXT NOT NULL DEFAULT '',
    criado_em       TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE INDEX idx_estoque_mov_item ON estoque_movimentos(id_item, data);
CREATE INDEX idx_estoque_mov_fornecedor ON estoque_movimentos(id_fornecedor);
CREATE INDEX idx_estoque_mov_veiculo ON estoque_movimentos(id_veiculo);

CREATE TABLE equipamentos (
    id_equipamento  INTEGER PRIMARY KEY AUTOINCREMENT,
    nome            TEXT NOT NULL,
    situacao        TEXT NOT NULL DEFAULT 'A',
    criado_em       TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    atualizado_em   TEXT
);

CREATE UNIQUE INDEX idx_equipamentos_nome ON equipamentos(nome COLLATE NOCASE);

CREATE TABLE frota_equipamentos (
    id_veiculo      INTEGER NOT NULL REFERENCES frota(id_veiculo) ON DELETE CASCADE,
    id_equipamento  INTEGER NOT NULL REFERENCES equipamentos(id_equipamento) ON DELETE CASCADE,
    PRIMARY KEY (id_veiculo, id_equipamento)
);

CREATE INDEX idx_frota_equipamentos_eq ON frota_equipamentos(id_equipamento);

-- View de saldo do estoque
CREATE VIEW v_estoque_saldo AS
SELECT t.id_item,
       t.entradas,
       t.saidas,
       ROUND(t.entradas - t.saidas, 3) AS saldo,
       t.custo_medio,
       t.ultima_movimentacao
FROM (
    SELECT i.id_item,
           ROUND(COALESCE(SUM(CASE WHEN m.tipo <> 'S' AND m.quantidade > 0 THEN m.quantidade ELSE 0 END), 0), 3) AS entradas,
           ROUND(COALESCE(SUM(CASE WHEN m.tipo = 'S' THEN m.quantidade WHEN m.tipo = 'A' AND m.quantidade < 0 THEN -m.quantidade ELSE 0 END), 0), 3) AS saidas,
           SUM(CASE WHEN m.tipo = 'E' AND m.valor_unitario > 0 THEN m.quantidade * m.valor_unitario END)
             / NULLIF(SUM(CASE WHEN m.tipo = 'E' AND m.valor_unitario > 0 THEN m.quantidade END), 0) AS custo_medio,
           MAX(m.data) AS ultima_movimentacao
    FROM estoque_itens i
    LEFT JOIN estoque_movimentos m ON m.id_item = i.id_item
    GROUP BY i.id_item
) t;

-- -------------------------------------------------------------------------
-- Dados iniciais
-- -------------------------------------------------------------------------

-- perfis
INSERT INTO perfis (id_perfil, nome, descricao, sistema) VALUES (1, 'Administrador', 'Acesso total ao sistema', 1);
INSERT INTO perfis (id_perfil, nome, descricao, sistema) VALUES (2, 'Operacional', 'Cadastros e consultas do dia a dia', 0);
INSERT INTO perfis (id_perfil, nome, descricao, sistema) VALUES (3, 'Financeiro', 'Módulos financeiros e relatórios', 0);

-- permissoes
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (1, 1, 'clientes', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (2, 2, 'clientes', 1, 1, 1, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (3, 3, 'clientes', 1, 0, 0, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (4, 1, 'funcionarios', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (5, 2, 'funcionarios', 1, 1, 1, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (6, 3, 'funcionarios', 1, 0, 0, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (7, 1, 'frota', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (8, 2, 'frota', 1, 1, 1, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (9, 3, 'frota', 1, 0, 0, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (10, 1, 'faturas', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (11, 2, 'faturas', 1, 1, 1, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (12, 3, 'faturas', 1, 0, 0, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (13, 1, 'caixa', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (14, 3, 'caixa', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (15, 1, 'cheques', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (16, 3, 'cheques', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (17, 1, 'usuarios', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (18, 1, 'salarios', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (19, 1, 'estoque', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (20, 1, 'fornecedores', 1, 1, 1, 1);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (21, 2, 'estoque', 1, 1, 1, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (22, 2, 'fornecedores', 1, 1, 1, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (23, 3, 'estoque', 1, 0, 0, 0);
INSERT INTO permissoes (id_permissao, id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir) VALUES (24, 3, 'fornecedores', 1, 1, 1, 0);

-- contas_caixa
INSERT INTO contas_caixa (id_conta, descricao, limite_mensal) VALUES (1, 'Caixa geral', NULL);

-- equipamentos
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (1, 'WC', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (2, 'Geladeira elétrica', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (3, 'Frigobar', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (4, 'Cafeteira elétrica', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (5, 'Mesa de jogos', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (6, 'Ar-condicionado', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (7, 'Calefação', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (8, 'Vidros lacrados', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (9, 'Suspensão a ar', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (10, 'Cabine', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (11, 'Monitores de vídeo', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (12, 'Monitores LCD', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (13, 'Rádio AM/FM', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (14, 'CD', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (15, 'DVD', 'A');
INSERT INTO equipamentos (id_equipamento, nome, situacao) VALUES (16, 'Vídeo K7', 'A');
