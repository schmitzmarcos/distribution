-- =========================================================================
-- Migracao 002 - Permissoes dos modulos novos: auditoria, atualizacao, rentabilidade e vencimentos
--
-- Ate aqui estas telas eram fixas (Auditoria e Atualizacao so para o Administrador; Rentabilidade
-- seguia o Financeiro; Vencimentos seguia Frota/Funcionarios). Agora cada uma e um modulo da matriz
-- de permissoes (Administracao > Perfis). Modulo sem linha = sem nenhuma permissao, entao esta
-- migracao cria as linhas de partida para NAO tirar o acesso de ninguem:
--   auditoria      Administrador (perfil de sistema): ver
--   atualizacao    Administrador: ver a tela, editar (origem e download) e incluir (instalar)
--   rentabilidade  todo perfil que ja via o Financeiro (caixa): ver
--   vencimentos    todo perfil que ja via Frota ou Funcionarios: ver
-- INSERT OR IGNORE: nunca sobrescreve uma linha que o administrador ja tenha configurado.
-- =========================================================================

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'auditoria', 1, 0, 0, 0 FROM perfis WHERE sistema = 1;

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'atualizacao', 1, 1, 1, 0 FROM perfis WHERE sistema = 1;

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT id_perfil, 'rentabilidade', 1, 0, 0, 0 FROM permissoes WHERE modulo = 'caixa' AND pode_ver = 1;

INSERT OR IGNORE INTO permissoes (id_perfil, modulo, pode_ver, pode_incluir, pode_editar, pode_excluir)
SELECT p.id_perfil, 'vencimentos', 1, 0, 0, 0 FROM perfis p
WHERE EXISTS (SELECT 1 FROM permissoes x WHERE x.id_perfil = p.id_perfil AND x.modulo IN ('frota', 'funcionarios') AND x.pode_ver = 1);
